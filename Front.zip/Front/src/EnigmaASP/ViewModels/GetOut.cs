﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace EmptyMVC6.ViewModels
//{
//    public class MarketingPanelGetOut
//    {
//        public MarketingChanelStatistics //All,            //Итого
//                                    Yandex,         //Всего по Яндексу
//                                    YandexContext,  //Контекст - он же РСЯ
//                                    YandexSearch;   //Поиск в Яндексе

//        public DateTime MonthOfPlan;
//    }

//    public class PhraseMarketingStatGetOut
//    {
//        public List<PhraseMarketingStatistics> StatList;
//    }

//    public class CampaignMarketingStatGetOut
//    {
//        public List<CampaignMarketingStatistics> StatList;
//    }

//    public struct PhraseMarketingStatistics
//    {
//        public LeadSourceMarketingStatistics Stat;
//        public string Name;
//    }

//    public struct CampaignMarketingStatistics
//    {
//        public LeadSourceMarketingStatistics Stat;
//        public string Name;
//    }

//    public struct LeadSourceMarketingStatistics
//    {
//        public int Shows;                 //Показы
//        public double CvVisits;           //Конверсия в клики
//        public int Clicks;                //Визиты (они же клики)
//        public double CvRequests;         //Конверсия в заявки
//        public int Requests;              //Заявки
//        public double CvSales;            //Конверсия в продажи
//        public int Sales;                 //Продажи (в штуках)
//        public decimal Revenue;            //Доход (продажи в рублях)
//        public double AverageDealPrice;   //Средний чек
//        public double Costs;              //Затраты
//        public double Marge;              //Маржа
//        public double Profit;             //Прибыль
//        public double ROMI;               //ROMI
//    }

//    public struct MarketingChanelStatistics
//    {
//        public PlanFact<int> Shows;                 //Показы
//        public PlanFact<double> CvVisits;           //Конверсия в клики
//        public PlanFact<int> Clicks;                //Визиты (они же клики)
//        public PlanFact<double> CvRequests;         //Конверсия в заявки
//        public PlanFact<int> Requests;              //Заявки
//        public PlanFact<double> CvSales;            //Конверсия в продажи
//        public PlanFact<int> Sales;                 //Продажи (в штуках)
//        public PlanFact<double> Revenue;            //Доход (продажи в рублях)
//        public PlanFact<double> AverageDealPrice;   //Средний чек
//        public PlanFact<double> Costs;              //Затраты
//        public PlanFact<double> Marge;              //Маржа
//        public PlanFact<double> Profit;             //Прибыль
//        public PlanFact<double> ROMI;               //ROMI
//    }

//    public struct PlanFact<T> where T:struct
//    {
//        public T Plan;
//        public T Fact;
//    }  
//}
