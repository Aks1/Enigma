﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.ViewModels
{
  
    public class MarketingMainPanel
    {
        public Marketing All, InternetTraffic, Context, Search, SocialNetworks, Email, Other;
        public DateTime MonthOfPlan;
        //public Dictionary<Tuple<string,DateTime>, double> CVbyDay;
        public object GetCopy()
        {
            return this.MemberwiseClone();
        }
    }
    public class MarketingPlanningOnlyPlanPanel
    {
        public string Name { get; set; }
        public int Shows { get; set; }               //Показы
        public double CvVisits { get; set; }           //Конверсия в клики
        public int Clicks { get; set; }               //Визиты (они же клики)
        public double CvRequests { get; set; }
        public int Requests { get; set; }
        public double CvSales { get; set; }
        public int Sales { get; set; }
        public double CashFlow { get; set; }
        public double AverageDealPrice { get; set; }
        public double Charge { get; set; }
        public double Marge { get; set; }
        public double Profit { get; set; }
        public double ROMI { get; set; }
        public DateTime MonthOfPlan { get; set; }
        //public Dictionary<Tuple<string,DateTime>, double> CVbyDay;

    }

    public struct Marketing
    {
		public string Name;
		public IntPlanFact Shows;                 //Показы
        public DoublePlanFact CvVisits;           //Конверсия в клики
        public IntPlanFact Clicks;                //Визиты (они же клики)
        public DoublePlanFact CvRequests;
        public IntPlanFact Requests;
        public DoublePlanFact CvSales;
        public IntPlanFact Sales;
        public DoublePlanFact CashFlow;
        public DoublePlanFact AverageDealPrice;
        public DoublePlanFact Charge;
        public DoublePlanFact Marge;
        public DoublePlanFact Profit;
        public DoublePlanFact ROMI;
    }

    public struct IntPlanFact
    {
        public int Plan;
        public int Fact;
        //public bool ManuallyDefined;

    }

    public struct DoublePlanFact
    {
        public double Plan;
        public double Fact;
        //public bool ManuallyDefined;
    }

}
