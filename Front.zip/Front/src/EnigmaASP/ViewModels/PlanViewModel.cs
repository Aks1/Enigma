﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.ViewModels
{
  
    public class PlanViewModel
    {
        public Marketing All, InternetTraffic, Context, Search, SocialNetworks, Email, Other;

        //public Dictionary<Tuple<string,DateTime>, double> CVbyDay;

    }

    public struct PlanForActivity
    {
        public int Visits;
        public Double CVRequests;
        public int Requests;
        public Double CVSales;
        public int Sales;
        public Double CashFlow;
        public Double Profit;
        public Double AverageDealPrice;
        public Double Costs;
        public Double ROMI;
    }

}
