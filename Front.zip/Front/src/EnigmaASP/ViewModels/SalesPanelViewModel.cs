﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.ViewModels
{
    public class SalesPanelViewModel
    {
        // Данные о работе View
        public Models.SessionSettings PageInfo { get; set; }

        //Список статусов (их названий) в порядке согласно воронке
        //В воронке всегда есть минимум 3 этапа: "Первичный контакт" (название может быть другое, все названия статусов могут
        // менять пользователи, суть - первый этап воронки), "Успешно реализовано" (суть - последний этап воронки,
        // сделка оплачена) и "Закрыто и не реализовано" (последний этап воронки - сделка не оплачена)
        //
        // В списке последним элементов должен быть "Закрыто и не реализовано", предпоследним - "Успешно реализовано"
        // Остальные статусы передаются по порядку
        public List<string> Statuses { get; set; }

        //Список менеджеров (их ФИО) по алфавиту
        public List<string> Managers { get; set; }

        //Словарь по <менеджеру> возвращает всю стату по менеджеру
        public Dictionary<string, ManagerStats> ManagerStatsDict { get; set; }

        //Словарь по <статусу_из, статусу_в> выдает конверсию для воронки
        // Ключем является пара: название первого статуса, название второго статуса
        //      (названия такие же как в List<string> Statuses)
        // Словарь содержит все пары статусов, в порядке воронки
        //      Например, если в воронке есть 4 статуса: 1,2,3,4 -, то в словаре будет double (т.е. конверсия в долях единицы)
        //      для следующих пар: (1,2); (1,3); (1,4); (2,3); (2,4); (3,4)
        public List<StatusConversion> CVByStatusList { get; set; }

        //Итого - как написано в интерфейсе
        public string AllName { get; set; }
        //Суммарная информация по всему аккаунту
        // а не по конкретному менеджеру (например, конверсия по всему аккаунту, т.е. для всех менеджеров)
        public ManagerStats AllManagerStats { get; set; }

        public SalesPanelViewModel()
        {
            Statuses = new List<string>();
            Managers = new List<string>();
            ManagerStatsDict = new Dictionary<string, ManagerStats>();
            CVByStatusList = new List<StatusConversion>();
            AllName = "Итого";
            AllManagerStats = new ManagerStats
            {
                SalesByStatus = new Dictionary<string, DealsSummary>()
            };
        }
    }

    // Суммы сделок
    public struct DealsSummary
    {
        // Суммарное число (в штуках) сделок
        public int Quantity;
        // Суммарный объем сделок (в рублях)
        public decimal Value;
    }

    //Переход состояния
    public struct StatusConversion
    {
        //Название начального состояния
        public string First;
        //Название конечного состояния
        public string Second;
        //Конверсия
        public double Convertion;
    }

    // Структура показывает статистику по данному менеджеру (или по всему аккаунту АМО)
    // Общее условие: дата посл изменения входит в заданный период,
    // ответственный = данный менеджер (или все менеджеры для "all")
    public struct ManagerStats
    {
        // Суммы сделок для каждого статуса
        // Доп. условие: (статус сделки = СТ)
        //      словарь по всем СТ (названиям статусов) в воронке
        //      суммируем число и сумму всех сделок, подходящих под условие
        public Dictionary<string, DealsSummary> SalesByStatus;

        // Конверсия из лида в продажу
        // Делим число сделок со статусом "Успешно реализовано" на число сделок со статусом "Первичный контакт" 
        public double CVFirstToLast;

        // Сумма всех оплаченных сделок (в рублях)
        // Доп. условие: (статус сделки = "Успешно реализовано")
        // (или по всему аккаунту) за данный период 
        public decimal SalesFactual; // Факт

        // План (в рублях)
        // План имеется для каждого менеджера и по всему аккаунту на каждый день, задается пользователем
        // (пока можно выставить в 0)
        public decimal SalesPlan; // План

        // % выполнения плана: SalesFactual / SalesPlan
        public double FactualByPlan; // 

        // пока заполняем рэндомом, будем считать потом
        public double CPO;

        // средний чек
        // SalesFactual / число сделок с этим статусом ("Успешно реализовано")
        public decimal AverageDealPrice;
    }


//    // TODO: добавить конструктор, число статусов, возможность вернуть все
//    public struct Statuses
//    {
//        public string First;

//        public List<string> Intermediate;

//        public string LastPositive;
//        public string LastNegative;
//    }


}
