﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.ViewModels
{
    public class Yandex_AmoCRMViewModel
    {
        public MarketingMainPanel MarketingMainPanel { get; set; }
        public SalesPanelViewModel SalesPanelViewModel { get; set; }
        public Models.SessionSettings PageInfo { get; set; }
    }
}
