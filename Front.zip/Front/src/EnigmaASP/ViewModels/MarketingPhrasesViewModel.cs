﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.ViewModels
{
  
    public class MarketingPhrasesPanel
    {
        public List<LeadSourceMarketingStatistics> MarketingPhrases = new List<LeadSourceMarketingStatistics>();
        readonly Random _rand = new Random();

        //public Dictionary<Tuple<string,DateTime>, double> CVbyDay;
        public void CreateTestMarketingPhrasesPanel()  //MarketingPhrasesPanel
        {
			for (int i = 0; i < 100; i++)
			{
				string name = "Йа фразо № "+i;
				int shows = _rand.Next(300, 3000);                                               //Показы
				int clicks = _rand.Next(30, 300);
				double cvVisits = (double)clicks / shows;                            //Конверсия в клики
				int requests = _rand.Next(20, 160);
				double cvRequests = (double)requests / clicks;
				int sales = _rand.Next(10, 40);
				double cvSales = (double)sales / requests;
				double averageDealPrice = (double)_rand.Next(10, 30) / _rand.Next(2, 3);
				decimal cashFlow = sales * (decimal)averageDealPrice;
				double charge = _rand.Next(10, 200);
				double marge = (double)_rand.Next(10, 20) / _rand.Next(2, 3);
				double profit = marge - charge;
				double romi = profit / charge;

                var banners = new List<Banner> { };
                for (int j = 0; j < 2; j++)
                {
                    banners.Add(new Banner
                    {
                        ID = _rand.Next(30, 300) * _rand.Next(30, 300),
                        Description = "найти поиск баннер яндекс директ " + (i + _rand.Next(30, 300))
                    });
                }


                var marketPhrases = new LeadSourceMarketingStatistics
                {
                    Name = name,
                    Shows = shows,
                    Clicks = clicks,
                    CvVisits = cvVisits,
                    Requests = requests,
                    CvRequests = cvRequests,
                    CvSales = cvSales,
                    Sales = sales,
                    CashFlow = cashFlow,
                    AverageDealPrice = averageDealPrice,
                    Charge = charge,
                    Marge = marge,
                    Profit = profit,
                    ROMI = romi,
                    //Banners = banners
                };

				MarketingPhrases.Add(marketPhrases);
			}

            return;
        }
    }

    public struct LeadSourceMarketingStatistics
    {
		public string Name;
        public string NameShort;
        public int Shows;                 //Показы
        public double CvVisits;           //Конверсия в клики
        public int Clicks;                //Визиты (они же клики)
        public double CvRequests;
        public int Requests;
        public double CvSales;
        public int Sales;
        public decimal CashFlow;
        public double AverageDealPrice;
        public double Charge;
        public double Marge;
        public double Profit;
        public double ROMI;
        //public List<Banner> Banners;
    }
    public struct Banner
    {
        public int ID;
        public string Description;
    }


    }
