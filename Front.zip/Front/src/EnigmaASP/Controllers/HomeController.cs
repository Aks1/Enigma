﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using EmptyMVC6.ViewModels;
using EmptyMVC6.Services;
using Microsoft.AspNet.Http;
using EmptyMVC6.Helpers;
using EmptyMVC6.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Authorization;

namespace EmptyMVC6.Controllers
{
	[Authorize]
	public class HomeController : Controller
	{
        bool _dataSourcesAdded;
        bool _getDataResult, _getMarketDataResult;
        private readonly UserManager<ApplicationUser> _userManager;
		private readonly SignInManager<ApplicationUser> _signInManager;
		private readonly IBackEndRequestService _backEndRequestService;
		private readonly ITestService _testEndResult;
		ApplicationUser _user;

        public HomeController(
			UserManager<ApplicationUser> userManager,
			SignInManager<ApplicationUser> signInManager,
            IBackEndRequestService backEndRequestService, ITestService testEndResult)
		{
			_userManager = userManager;
			_signInManager = signInManager;
			_backEndRequestService = backEndRequestService;
			_testEndResult = testEndResult;

            //pageInfo = new Models.PageInfo();
            //{
            //    CalendarState = "",
            //    StartDate = new DateTime(),
            //    EndDate = new DateTime(),
            //    QuantValSwitcher = true
            //};
        }

		private async Task<ApplicationUser> GetCurrentUserAsync()
		{

			return await _userManager.FindByNameAsync(HttpContext.User.Identity.Name);
		}

        private bool BackEndInitializer()
        {
            //Initializing
            if (HttpContext != null)
            {
                _user = GetCurrentUserAsync().Result;
                var cookieContainer = HttpContext.Session.GetObjectFromJson<System.Net.CookieContainer>("CookieContainer");
                if (cookieContainer != null && cookieContainer.Count != 0)
                {
                    _backEndRequestService.InitializeBackEndRequestService(_user.UserName, _user.Password, cookieContainer);
                }

                else
                {
                    _backEndRequestService.InitializeBackEndRequestService(_user.UserName, _user.Password);
                    HttpContext.Session.SetObjectAsJson("CookieContainer", 
                        _backEndRequestService.СurrentCookieContainer);
                }
            }
            else // TESTING/DEVELOPMENT ONLY
            {
                _backEndRequestService.InitializeBackEndRequestService();
                //
                return false;
            }

            //         user.cookieContainerContainer. = _backEndRequestService.СurrentCookieContainer;
            return true;
        }

		private bool CheckBackEndWorks()
		{
		    BackEndInitializer();

			// Если в бэкэнде к Enigma акку не привязан акк AmoCRM и Яндекс, отправляем в настройки для привязки
			var result = _backEndRequestService.CheckAmoCRMAccessAdded(_user.UserName, _user.Password)
			              && _backEndRequestService.CheckYandexAccessAdded(_user.UserName, _user.Password);

            // TODO check if data is cool
            //if ()
            SetFlagsAmoCRMYandexIntegration();
            return result;
        }

        private bool ValidateAmoCRMBackEndData(SalesPanelViewModel modelToCheck)
        {
            var result = modelToCheck?.Managers != null && modelToCheck.Managers.Count > 0;
            return result;
        }

        public IActionResult Index()
		{
            _user = GetCurrentUserAsync().Result;
            var userSessionInfo = _user.currentSessionInfo;

            bool validModel;
            DTO.AmoCRM.SalesPanel.V1.GetOut dto;
            SalesPanelViewModel model;
            SalesPanelViewModel mainResultsModel;
            //if (HttpContext?.User?.Identity?.Name == null) return View("~/Views/Account/Login");
            //var user = GetCurrentUserAsync().Result;

            // Добавлены ли доступы Амо и Яндекса?
            _dataSourcesAdded = CheckBackEndWorks();
            if (!_dataSourcesAdded)
                //Если нет, перенаправляем на настройки
                return RedirectToRoute(new { controller = "Settings", action = "IntegrationAuth" });

            // Вадиму: Зачем эта строчка? Для повышения производительности в будущем
            HttpContext.Session.SetObjectAsJson("CookieContainer", _backEndRequestService.СurrentCookieContainer);

            // SessionSettings from User code block WHICH_GETS_DTO
            // Если у юзера инфа по его периоду аналитики
            if (userSessionInfo?.StartDate != null && userSessionInfo?.EndDate != null)
            {
                dto = _backEndRequestService.GetSalesPanelData(out _getDataResult,
                    userSessionInfo.StartDate, userSessionInfo.EndDate);
            }
            else
            {
                // TODO: Use current month
                var pageInfo = new SessionSettings { EndDate = DateTime.Now };
                _user.currentSessionInfo = pageInfo;
                dto = _backEndRequestService.GetSalesPanelData(out _getDataResult,
                    pageInfo.StartDate, pageInfo.EndDate);
            }

            // If BackEnd gave some data, validate model from BackEnd
            if (dto != null)
            {
                // MODEL from DTO
                model = CreateSalesPanelViewModel(dto);
                validModel = ValidateAmoCRMBackEndData(model);
            }
            else
            {
                validModel = false;
                // TEST MODEL
                model = CreateSalesPanelViewModel(_testEndResult.GetSalesPanelData(out _getDataResult));
            }
            if (!validModel)
            {
                model = CreateSalesPanelViewModel(_testEndResult.GetSalesPanelData(out _getDataResult));
            }

            //
            mainResultsModel = model;


            // Вторая часть панели
            //mainResultsModel.Statuses = new List<string> { "Визиты", model.Statuses[1], model.Statuses[14] };//model.AllManagerStats.SalesByStatus[model.Statuses.FirstOrDefault()];
            var statuses = new List<string> { "Визиты", "Заявки", "Продажи" }; //"Визиты", model.Statuses[0], "Продажи" 

            //
            DTO.Marketing.Panel.V1.MarketingPanelGetOut dtoMarketYandex;
            var currentPlan = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");
            //var marketingMainPanel = createTestMarketingMainPanel();
            MarketingMainPanel marketingMainPanel = new MarketingMainPanel();

            if (currentPlan == null)
            {
                dtoMarketYandex = _backEndRequestService.GetMarketPanelData(out _getMarketDataResult);

                marketingMainPanel.All.Shows.Plan = dtoMarketYandex.Yandex.Shows.Plan;
                marketingMainPanel.All.Shows.Fact = dtoMarketYandex.Yandex.Shows.Fact;
                marketingMainPanel.All.CvVisits.Plan = dtoMarketYandex.Yandex.CvVisits.Plan * 100;
                marketingMainPanel.All.CvVisits.Fact = dtoMarketYandex.Yandex.CvVisits.Fact * 100;
                marketingMainPanel.All.Clicks.Plan = dtoMarketYandex.Yandex.Clicks.Plan;
                marketingMainPanel.All.Clicks.Fact = dtoMarketYandex.Yandex.Clicks.Fact;
                marketingMainPanel.All.CvRequests.Plan = dtoMarketYandex.Yandex.CvRequests.Plan * 100;
                marketingMainPanel.All.CvRequests.Fact = dtoMarketYandex.Yandex.CvRequests.Fact * 100;
                marketingMainPanel.All.Requests.Plan = dtoMarketYandex.Yandex.Requests.Plan;
                marketingMainPanel.All.Requests.Fact = dtoMarketYandex.Yandex.Requests.Fact;
            }
            else
            {
                marketingMainPanel = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");

            }
            //var marketingMainPanel = createTestMarketingMainPanel();

            var allStats1 = new DealsSummary { Quantity = marketingMainPanel.All.Clicks.Fact, Value = marketingMainPanel.All.Clicks.Fact };
            var allStats2 = model.AllManagerStats.SalesByStatus[model.Statuses[0]];
            var allStats3 = model.AllManagerStats.SalesByStatus[model.Statuses[(model.Statuses.Count()-1)]];
            //newModel.AllManagerStats.SalesByStatus = new Dictionary<string, ManagerStats> { };
            var salesByStatus = new Dictionary<string, DealsSummary>
                    {
                        {statuses[0], allStats1 },
                        {statuses[1], allStats2 },
                        {statuses[2], allStats3 }
                    };
            mainResultsModel.ManagerStatsDict.Clear();
            mainResultsModel.AllManagerStats = new ManagerStats()
            {
                SalesByStatus = salesByStatus,
                CVFirstToLast = model.AllManagerStats.CVFirstToLast,
                SalesFactual = model.AllManagerStats.SalesFactual,
                SalesPlan = model.AllManagerStats.SalesPlan,
                FactualByPlan = model.AllManagerStats.FactualByPlan,
                CPO = model.AllManagerStats.CPO,
                AverageDealPrice = model.AllManagerStats.AverageDealPrice
            };
            mainResultsModel.Statuses = statuses;
            //mainResultsModel.AllManagerStats.SalesByStatus = salesByStatus;

            //   HttpContext.Session.SetString("Test", "Statzilla Rules!");
            //if (HttpContext.Session.GetString("Test")=="")
            //HttpContext.Session.SetString("Test", "Statzilla Rules!");
            //ViewBag.UserName = HttpContext.User.Identity.Name;
            //ViewBag.SimpleString = HttpContext.Session.GetString("Test");

            // Use SessionSettings
            //HttpContext.Session.SetObjectAsJson("PageInfo", new SessionSettings());
            //var pageInfo = HttpContext.Session.GetObjectFromJson<Models.SessionSettings>("PageInfo");
            mainResultsModel.PageInfo = _user.currentSessionInfo;
            var indexModel = new Yandex_AmoCRMViewModel
            {
                SalesPanelViewModel = mainResultsModel,
                MarketingMainPanel = null
            };

            return View(indexModel);
		}

		public IActionResult About()
		{
			ViewBag.SimpleString = HttpContext.Session.GetString("Test");
			ViewData["Message"] = "Your application description page.";

			return View();
		}
		public IActionResult Market()
		{
            DTO.Marketing.Panel.V1.MarketingPanelGetOut dtoMarketYandex;
            // 
            _dataSourcesAdded = CheckBackEndWorks();
			if (!_dataSourcesAdded)
                return View("~/Views/Settings/IntegrationAuth");

            var currentPlan = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");

            //var marketingMainPanel = createTestMarketingMainPanel();
            MarketingMainPanel marketingMainPanel = new MarketingMainPanel();

            if (currentPlan == null) { 
            //var currentPlan = HttpContext.Session.GetObjectFromJson<SessionSettings>("PageInfo");
            //try
            //{
            //    dtoMarketYandex = _backEndRequestService.GetMarketPanelData(out getMarketDataResult, currentPlan.StartDate, currentPlan.EndDate);
            //}
            //catch (Exception)
            //{
            //    dtoMarketYandex = _backEndRequestService.GetMarketPanelData(out getMarketDataResult);
            //}
            dtoMarketYandex = _backEndRequestService.GetMarketPanelData(out _getMarketDataResult);

            marketingMainPanel.All.Shows.Plan = dtoMarketYandex.Yandex.Shows.Plan;
            marketingMainPanel.All.Shows.Fact = dtoMarketYandex.Yandex.Shows.Fact;
            marketingMainPanel.All.CvVisits.Plan = dtoMarketYandex.Yandex.CvVisits.Plan*100;
            marketingMainPanel.All.CvVisits.Fact = dtoMarketYandex.Yandex.CvVisits.Fact*100;
            marketingMainPanel.All.Clicks.Plan = dtoMarketYandex.Yandex.Clicks.Plan;
            marketingMainPanel.All.Clicks.Fact = dtoMarketYandex.Yandex.Clicks.Fact;
            marketingMainPanel.All.CvRequests.Plan = dtoMarketYandex.Yandex.CvRequests.Plan*100;
            marketingMainPanel.All.CvRequests.Fact = dtoMarketYandex.Yandex.CvRequests.Fact*100;
            marketingMainPanel.All.Requests.Plan = dtoMarketYandex.Yandex.Requests.Plan;
            marketingMainPanel.All.Requests.Fact = dtoMarketYandex.Yandex.Requests.Fact;
            marketingMainPanel.All.CvSales.Plan = dtoMarketYandex.Yandex.CvSales.Plan*100;
            marketingMainPanel.All.CvSales.Fact = dtoMarketYandex.Yandex.CvSales.Fact*100;
            marketingMainPanel.All.Sales.Plan = dtoMarketYandex.Yandex.Sales.Plan;
            marketingMainPanel.All.Sales.Fact = dtoMarketYandex.Yandex.Sales.Fact;
            marketingMainPanel.All.CashFlow.Plan = Math.Round(dtoMarketYandex.Yandex.Revenue.Plan*30, 1);
            marketingMainPanel.All.CashFlow.Fact = Math.Round(dtoMarketYandex.Yandex.Revenue.Fact*30, 1);
            marketingMainPanel.All.AverageDealPrice.Plan = Math.Round(dtoMarketYandex.Yandex.AverageDealPrice.Plan*30, 1);
            marketingMainPanel.All.AverageDealPrice.Fact = Math.Round(dtoMarketYandex.Yandex.AverageDealPrice.Fact*30, 1);
            marketingMainPanel.All.Charge.Plan = Math.Round(dtoMarketYandex.Yandex.Costs.Plan*30, 1);
            marketingMainPanel.All.Charge.Fact = Math.Round(dtoMarketYandex.Yandex.Costs.Fact*30, 1);
            marketingMainPanel.All.Marge.Plan = dtoMarketYandex.Yandex.Marge.Plan;
            marketingMainPanel.All.Marge.Fact = dtoMarketYandex.Yandex.Marge.Fact;
            marketingMainPanel.All.Profit.Plan = Math.Round(dtoMarketYandex.Yandex.Profit.Plan*30, 1);
            marketingMainPanel.All.Profit.Fact = Math.Round(dtoMarketYandex.Yandex.Profit.Fact*30, 1);
            marketingMainPanel.All.ROMI.Plan = dtoMarketYandex.Yandex.ROMI.Plan*100;
            marketingMainPanel.All.ROMI.Fact = dtoMarketYandex.Yandex.ROMI.Fact*100;

            marketingMainPanel.InternetTraffic = marketingMainPanel.All;

            //var computedMarketingMainPanel = computeMarketingMainPanel(marketingMainPanel, marketingMainPanel);
            HttpContext.Session.SetObjectAsJson("PlanCurrent", marketingMainPanel);
            }
            else
            {
                marketingMainPanel = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");

            }
            var marketModel = new Yandex_AmoCRMViewModel
                { SalesPanelViewModel = null, MarketingMainPanel = marketingMainPanel };
            return View(marketModel);
        }

        [HttpPost]
        public IActionResult GetYandexAmoDataDuringPeriod([FromBody] StartEndDateModel data)
        {
            _dataSourcesAdded = CheckBackEndWorks();
            if (!_dataSourcesAdded)
                return View("~/Views/Settings/IntegrationAuth");

            var startDate = DateTime.Parse(data.StartDate);
            var endDate = DateTime.Parse(data.EndDate);
            var pageInfo = new Models.SessionSettings()
            {
                StartDate = startDate,
                EndDate = endDate
            };

            HttpContext.Session.SetObjectAsJson("PageInfo", pageInfo);
            //var userSessionInfo = GetCurrentUserAsync().Result.currentSessionInfo;
            //user.currentSessionInfo = pageInfo;

            //MarketingMainPanel marketingMainPanel = createTestMarketingMainPanel();
            MarketingMainPanel marketingMainPanel = new MarketingMainPanel();

            var dtoMarketYandex = _backEndRequestService.GetMarketPanelData
                (out _getMarketDataResult, DateTime.Parse(data.StartDate),
                DateTime.Parse(data.EndDate)); //DateTime.Parse(data.StartDate);

            marketingMainPanel.All.Shows.Plan = dtoMarketYandex.Yandex.Shows.Plan;
            marketingMainPanel.All.Shows.Fact = dtoMarketYandex.Yandex.Shows.Fact;
            marketingMainPanel.All.CvVisits.Plan = dtoMarketYandex.Yandex.Shows.Plan;
            marketingMainPanel.All.CvVisits.Fact = dtoMarketYandex.Yandex.Shows.Fact;
            marketingMainPanel.All.Clicks.Plan = dtoMarketYandex.Yandex.Clicks.Plan;
            marketingMainPanel.All.Clicks.Fact = dtoMarketYandex.Yandex.Clicks.Fact;
            marketingMainPanel.All.CvRequests.Plan = dtoMarketYandex.Yandex.CvRequests.Plan;
            marketingMainPanel.All.CvRequests.Fact = dtoMarketYandex.Yandex.CvRequests.Fact;
            marketingMainPanel.All.Requests.Plan = dtoMarketYandex.Yandex.Requests.Plan;
            marketingMainPanel.All.Requests.Fact = dtoMarketYandex.Yandex.Requests.Fact;
            marketingMainPanel.All.CvSales.Plan = dtoMarketYandex.Yandex.CvSales.Plan;
            marketingMainPanel.All.CvSales.Fact = dtoMarketYandex.Yandex.CvSales.Fact;
            marketingMainPanel.All.Sales.Plan = dtoMarketYandex.Yandex.Sales.Plan;
            marketingMainPanel.All.Sales.Fact = dtoMarketYandex.Yandex.Sales.Fact;
            marketingMainPanel.All.CashFlow.Plan = dtoMarketYandex.Yandex.Revenue.Plan;
            marketingMainPanel.All.CashFlow.Fact = dtoMarketYandex.Yandex.Revenue.Fact;
            marketingMainPanel.All.AverageDealPrice.Plan = dtoMarketYandex.Yandex.AverageDealPrice.Plan;
            marketingMainPanel.All.AverageDealPrice.Fact = dtoMarketYandex.Yandex.AverageDealPrice.Fact;
            marketingMainPanel.All.Charge.Plan = dtoMarketYandex.Yandex.Costs.Plan;
            marketingMainPanel.All.Charge.Fact = dtoMarketYandex.Yandex.Costs.Fact;
            marketingMainPanel.All.Marge.Plan = dtoMarketYandex.Yandex.Marge.Plan;
            marketingMainPanel.All.Marge.Fact = dtoMarketYandex.Yandex.Marge.Fact;
            marketingMainPanel.All.Profit.Plan = dtoMarketYandex.Yandex.Profit.Plan;
            marketingMainPanel.All.Profit.Fact = dtoMarketYandex.Yandex.Profit.Fact;
            marketingMainPanel.All.ROMI.Plan = dtoMarketYandex.Yandex.ROMI.Plan;
            marketingMainPanel.All.ROMI.Fact = dtoMarketYandex.Yandex.ROMI.Fact;

            marketingMainPanel.InternetTraffic = marketingMainPanel.All;

            HttpContext.Session.SetObjectAsJson("PlanCurrent", marketingMainPanel);

            var dto = _backEndRequestService.GetSalesPanelData(out _getDataResult,
            startDate, endDate);
            var model = CreateSalesPanelViewModel(dto);

            model.PageInfo = pageInfo;

            //return RedirectToAction(“Index”);   // After that you can redirect to some pages…
            // Or you can get that data back after inserting into database.. This json displays all the details to our view as well.
            //return Json(true, JsonRequestBehavior.AllowGet); 

            //actionName = data.PanelView.Substring(str.LastIndexOf("/") + 1);
            List<string> actionName = data.PanelView.Split('/').ToList();
            var yandexAmoCRMModel = new Yandex_AmoCRMViewModel
            {
                SalesPanelViewModel = model,
                MarketingMainPanel = marketingMainPanel
            };
            return View(actionName.LastOrDefault(), yandexAmoCRMModel);
        }

        private MarketingMainPanel createTestMarketingMainPanel()
        {
            Random _rand = new Random();

            IntPlanFact clicks = new IntPlanFact { Fact = _rand.Next(300, 900), Plan = _rand.Next(300, 900) };
            IntPlanFact requests = new IntPlanFact { Fact = _rand.Next(200, 460), Plan = _rand.Next(200, 460) };
            DoublePlanFact cvRequests = new DoublePlanFact { Fact = (double)requests.Fact / (double)clicks.Fact, Plan = (double)requests.Plan / (double)clicks.Plan };
            IntPlanFact sales = new IntPlanFact { Fact = _rand.Next(100, 180), Plan = _rand.Next(100, 180) };
            DoublePlanFact cvSales = new DoublePlanFact { Fact = (double)sales.Fact / (double)requests.Fact, Plan = (double)sales.Plan / (double)requests.Plan };
            DoublePlanFact averageDealPrice = new DoublePlanFact { Fact = _rand.Next(10, 30)/ _rand.Next(2, 3), Plan = _rand.Next(10, 30) / _rand.Next(2, 3) };
            DoublePlanFact cashFlow = new DoublePlanFact { Fact = sales.Fact * averageDealPrice.Fact, Plan = sales.Plan * averageDealPrice.Plan };
            DoublePlanFact charge = new DoublePlanFact { Fact = _rand.Next(1200, 1700), Plan = _rand.Next(1200, 1700) };
            DoublePlanFact marge = new DoublePlanFact { Fact = _rand.Next(3, 5) / _rand.Next(2, 3), Plan = _rand.Next(3, 5) / _rand.Next(2, 3) };
            DoublePlanFact profit = new DoublePlanFact { Fact = (cashFlow.Fact * marge.Fact) - charge.Fact, Plan = (cashFlow.Plan * marge.Plan) - charge.Plan };
            DoublePlanFact romi = new DoublePlanFact { Fact = profit.Fact / charge.Fact, Plan = profit.Plan / charge.Plan };

            var internetTraffic = new Marketing
            {
                Clicks = clicks,
                CvRequests = cvRequests,
                Requests = requests,
                CvSales = cvSales,
                Sales = sales,
                CashFlow = cashFlow,
                AverageDealPrice = averageDealPrice,
                Charge = charge,
                Marge = marge,
                Profit = profit,
                ROMI = romi
            };

            var testMarketingMainPanel = new MarketingMainPanel {
                InternetTraffic = internetTraffic,
                All = internetTraffic
            };

            return testMarketingMainPanel;
        }
        // Метод пересчета плана
        private MarketingMainPanel computeMarketingMainPanel(MarketingMainPanel oldMarketingMainPanel, MarketingMainPanel newMarketingMainPanel)
        {
			MarketingMainPanel computedMarketingMainPanel = oldMarketingMainPanel;
			//double CVRequests;
			//double CVSales;
			if ((newMarketingMainPanel.All.CvRequests.Plan != oldMarketingMainPanel.All.CvRequests.Plan) && newMarketingMainPanel.All.CvRequests.Plan != 0)
			{
				computedMarketingMainPanel.All.CvRequests.Plan = newMarketingMainPanel.All.CvRequests.Plan;
			}

			if (newMarketingMainPanel.All.CvSales.Plan != oldMarketingMainPanel.All.CvSales.Plan && newMarketingMainPanel.All.CvSales.Plan != 0)
            {
				computedMarketingMainPanel.All.CvSales.Plan = newMarketingMainPanel.All.CvSales.Plan;
			}

			// Если выручка, средний чек заполнены
			if ((oldMarketingMainPanel.All.CashFlow.Plan != newMarketingMainPanel.All.CashFlow.Plan) && (oldMarketingMainPanel.All.AverageDealPrice.Plan != newMarketingMainPanel.All.AverageDealPrice.Plan) && newMarketingMainPanel.All.CashFlow.Plan != 0 && newMarketingMainPanel.All.AverageDealPrice.Plan != 0)
			{
				computedMarketingMainPanel.All.Sales.Plan = (int)(newMarketingMainPanel.All.CashFlow.Plan / newMarketingMainPanel.All.AverageDealPrice.Plan);
				computedMarketingMainPanel.All.Requests.Plan = (int)(computedMarketingMainPanel.All.Sales.Plan / computedMarketingMainPanel.All.CvSales.Plan * 100);
				computedMarketingMainPanel.All.Clicks.Plan = (int)(computedMarketingMainPanel.All.Requests.Plan / computedMarketingMainPanel.All.CvRequests.Plan * 100);

				//newMarketingMainPanel.All.CashFlow.Plan - newMarketingMainPanel.All.Charge.Plan;
			}
			else if (newMarketingMainPanel.All.AverageDealPrice.Plan != oldMarketingMainPanel.All.AverageDealPrice.Plan && newMarketingMainPanel.All.AverageDealPrice.Plan != 0)
			{
                if (oldMarketingMainPanel.All.CashFlow.Plan == 0)
                {
                    oldMarketingMainPanel.All.CashFlow.Plan = oldMarketingMainPanel.All.CashFlow.Fact;
                }
				computedMarketingMainPanel.All.Sales.Plan = (int)(oldMarketingMainPanel.All.CashFlow.Plan / newMarketingMainPanel.All.AverageDealPrice.Plan);
				computedMarketingMainPanel.All.Requests.Plan = (int)(computedMarketingMainPanel.All.Sales.Plan / computedMarketingMainPanel.All.CvSales.Plan * 100);
				computedMarketingMainPanel.All.Clicks.Plan = (int)(computedMarketingMainPanel.All.Requests.Plan / computedMarketingMainPanel.All.CvRequests.Plan * 100);
			}
			else if (newMarketingMainPanel.All.CashFlow.Plan != oldMarketingMainPanel.All.CashFlow.Plan && newMarketingMainPanel.All.CashFlow.Plan != 0)
			{
                if (newMarketingMainPanel.All.AverageDealPrice.Plan == 0)
                {
                    newMarketingMainPanel.All.AverageDealPrice.Plan = newMarketingMainPanel.All.AverageDealPrice.Fact;
                }
                if (computedMarketingMainPanel.All.Sales.Plan == 0)
                {
                    newMarketingMainPanel.All.Sales.Plan = newMarketingMainPanel.All.Sales.Fact;
                }
                else
                {
                    computedMarketingMainPanel.All.Sales.Plan = (int)(newMarketingMainPanel.All.CashFlow.Plan / newMarketingMainPanel.All.AverageDealPrice.Plan);
                }

				computedMarketingMainPanel.All.Requests.Plan = (int)(computedMarketingMainPanel.All.Sales.Plan / computedMarketingMainPanel.All.CvSales.Plan * 100);
				computedMarketingMainPanel.All.Clicks.Plan = (int)(computedMarketingMainPanel.All.Requests.Plan / computedMarketingMainPanel.All.CvRequests.Plan * 100);
			}


			// МАРЖА ЗАПОЛНЕНа
			if (oldMarketingMainPanel.All.Marge.Plan != newMarketingMainPanel.All.Marge.Plan && newMarketingMainPanel.All.Marge.Plan != 0)
			{
				computedMarketingMainPanel.All.Profit.Plan = newMarketingMainPanel.All.CashFlow.Plan * newMarketingMainPanel.All.Marge.Plan / 100 - oldMarketingMainPanel.All.Charge.Plan;
				computedMarketingMainPanel.All.ROMI.Plan = newMarketingMainPanel.All.CashFlow.Plan * newMarketingMainPanel.All.Marge.Plan / 100 / oldMarketingMainPanel.All.Charge.Plan;
			}
			else
			{
				computedMarketingMainPanel.All.Profit.Plan = 0;
				computedMarketingMainPanel.All.ROMI.Plan = 0;
			}

            //computedMarketingMainPanel = distributeMarketingMainPanel(oldMarketingMainPanel, newMarketingMainPanel);
            computedMarketingMainPanel.InternetTraffic = computedMarketingMainPanel.All;

            return computedMarketingMainPanel;
		}
        private MarketingMainPanel distributeMarketingMainPanel(MarketingMainPanel oldMarketingMainPanel, MarketingMainPanel newMarketingMainPanel)
        {
            MarketingMainPanel computedMarketingMainPanel = newMarketingMainPanel;
            //foreach

            return computedMarketingMainPanel;
        }
        public IActionResult MarketPlanning()
        {
            var currentPlan = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");

            MarketingPlanningOnlyPlanPanel planCurrentPlan = new MarketingPlanningOnlyPlanPanel()
            {
                Name = currentPlan.All.Name,
                Shows = currentPlan.All.Shows.Plan,
                CvVisits = currentPlan.All.CvVisits.Plan,
                Clicks = currentPlan.All.Clicks.Plan,
                CvRequests = currentPlan.All.CvRequests.Plan,
                Requests = currentPlan.All.Requests.Plan,
                CvSales = currentPlan.All.CvSales.Plan,
                Sales = currentPlan.All.Sales.Plan,
                CashFlow = currentPlan.All.CashFlow.Plan,
                AverageDealPrice = currentPlan.All.AverageDealPrice.Plan,
                Charge = currentPlan.All.Charge.Plan,
                Marge = currentPlan.All.Marge.Plan,
                Profit = currentPlan.All.Profit.Plan,
                ROMI = currentPlan.All.ROMI.Plan,
                MonthOfPlan = currentPlan.MonthOfPlan
            };
            return PartialView(planCurrentPlan);
        }
        [HttpPost]
        public IActionResult MarketPlanning(MarketingPlanningOnlyPlanPanel marketingPlanningOnlyPlanPanel)
        {
            // Читаем прежний план, актуальный до ввода данных в модальном окне
            var notCurrentAnymorePlan = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");

            // Перевод плана
            MarketingMainPanel newMarketingMainPanel = (MarketingMainPanel)notCurrentAnymorePlan.GetCopy();

            newMarketingMainPanel.All.Shows.Plan = marketingPlanningOnlyPlanPanel.Shows;
            newMarketingMainPanel.All.CvVisits.Plan = marketingPlanningOnlyPlanPanel.CvVisits;
            newMarketingMainPanel.All.Clicks.Plan = marketingPlanningOnlyPlanPanel.Clicks;
            newMarketingMainPanel.All.CvRequests.Plan = marketingPlanningOnlyPlanPanel.CvRequests;
            newMarketingMainPanel.All.Requests.Plan = marketingPlanningOnlyPlanPanel.Requests;
            newMarketingMainPanel.All.CvSales.Plan = marketingPlanningOnlyPlanPanel.CvSales;
            newMarketingMainPanel.All.Sales.Plan = marketingPlanningOnlyPlanPanel.Sales;
            newMarketingMainPanel.All.CashFlow.Plan = marketingPlanningOnlyPlanPanel.CashFlow;
            newMarketingMainPanel.All.AverageDealPrice.Plan = marketingPlanningOnlyPlanPanel.AverageDealPrice;
            newMarketingMainPanel.All.Charge.Plan = marketingPlanningOnlyPlanPanel.Charge;
            newMarketingMainPanel.All.Marge.Plan = marketingPlanningOnlyPlanPanel.Marge;
            newMarketingMainPanel.All.Profit.Plan = marketingPlanningOnlyPlanPanel.Profit;
            newMarketingMainPanel.All.ROMI.Plan = marketingPlanningOnlyPlanPanel.ROMI;
            newMarketingMainPanel.MonthOfPlan = marketingPlanningOnlyPlanPanel.MonthOfPlan;

            // Рекурсивный метод пересчета плана
            newMarketingMainPanel = computeMarketingMainPanel(notCurrentAnymorePlan, newMarketingMainPanel);

            // TODO: Fix
            HttpContext.Session.SetObjectAsJson("PlanCurrent", newMarketingMainPanel);
            Yandex_AmoCRMViewModel temp = new Yandex_AmoCRMViewModel { MarketingMainPanel = newMarketingMainPanel };

            SetFlagsAmoCRMYandexIntegration();
            return View("Market", temp);//
        }

        public IActionResult MarketCampaigns()
        {
            // Добавлены ли доступы Амо и Яндекса?
            _dataSourcesAdded = CheckBackEndWorks();
            if (!_dataSourcesAdded)
                //Если нет, перенаправляем на настройки
                return RedirectToRoute(new { controller = "Settings", action = "IntegrationAuth" });

   //         MarketingCampaignsPanel marketingCampaignsPanel = new MarketingCampaignsPanel();
			//marketingCampaignsPanel.createTestMarketingCampaignsPanel();

            bool success;
            DTO.Marketing.Panel.V1.CampaignMarketingStatGetOut campaigns = _backEndRequestService.GetCampaignStatTest(out success);

            if (campaigns != null)
            {
                //var newCampaigns = campaigns.StatList.Select(p => new LeadSourceMarketingStatistics
                //{
                //    Name = p.Name.Replace(@"""", @"\"""),
                //    NameShort = (p.Name.Length > 30
                //                ? new string(p.Name.Take(30).ToArray()) + "..."
                //                : p.Name).Replace(@"""", @"\"""),
                //    Shows = p.Stat.Shows,
                //    CvVisits = p.Stat.CvVisits * 100,
                //    Clicks = p.Stat.Clicks,
                //    CvRequests = p.Stat.CvRequests * 100,
                //    Requests = p.Stat.Requests,
                //    CvSales = p.Stat.CvSales * 100,
                //    Sales = p.Stat.Sales,
                //    CashFlow = Math.Round(p.Stat.Revenue * 30, 1),
                //    AverageDealPrice = Math.Round(p.Stat.AverageDealPrice * 30, 1),
                //    Charge = Math.Round(p.Stat.Costs * 30, 1),
                //    Marge = p.Stat.Marge,
                //    Profit = Math.Round(p.Stat.Profit * 30, 1),
                //    ROMI = p.Stat.ROMI * 100
                //});

                //campaigns.StatList[1].Stat = newCampaigns.ToList(); //new DTO.Marketing.Panel.V1.CampaignMarketingStatGetOut { MarketingPhrases = newCampaings.ToList() };
            }
            else
            {
                //marketingPhrasesPanel = null;
                return RedirectToRoute(new { controller = "Settings", action = "IntegrationAuth" });
            }

            return View(campaigns);
		}
		public IActionResult MarketPhrases()
		{
            bool success;
            // Добавлены ли доступы Амо и Яндекса?
            _dataSourcesAdded = CheckBackEndWorks();
            if (!_dataSourcesAdded)
                //Если нет, перенаправляем на настройки
                return RedirectToRoute(new { controller = "Settings", action = "IntegrationAuth" });

            //BackEndInitializer(); свят добавил, наверное удалить
            //_backEndRequestService.AuthorizeEnigmaAcc(_user.UserName, _user.Password);

            var phrases = _backEndRequestService.GetPhraseStatTest(_user.UserName, _user.Password, out success);
			var marketingPhrasesPanel = new MarketingPhrasesPanel();

			if (phrases != null)
			{
				var newPhrases = phrases.StatList.Select(p => new LeadSourceMarketingStatistics
				{
					Name = p.Name.Replace(@"""", @"\"""),
					NameShort = (p.Name.Length > 30
								? new string(p.Name.Take(30).ToArray()) + "..."
								: p.Name).Replace(@"""", @"\"""),
					Shows = p.Stat.Shows,
					CvVisits = p.Stat.CvVisits * 100,
					Clicks = p.Stat.Clicks,
					CvRequests = p.Stat.CvRequests * 100,
					Requests = p.Stat.Requests,
					CvSales = p.Stat.CvSales * 100,
					Sales = p.Stat.Sales,
                    CashFlow = Math.Round(p.Stat.Revenue * 30, 1),
                    AverageDealPrice = Math.Round(p.Stat.AverageDealPrice * 30, 1),
                    Charge = Math.Round(p.Stat.Costs * 30, 1),
                    Marge = p.Stat.Marge,
                    Profit = Math.Round(p.Stat.Profit * 30, 1),
                    ROMI = p.Stat.ROMI * 100
				});

				marketingPhrasesPanel = new MarketingPhrasesPanel { MarketingPhrases = newPhrases.ToList() };
			}
			else
			{
				//marketingPhrasesPanel = null;
				marketingPhrasesPanel.CreateTestMarketingPhrasesPanel();
			}
            //marketingPhrasesPanel.createTestMarketingPhrasesPanel();
            //marketingPhrasesPanel.MarketingPhrases = phrases.StatList.;

            return View(marketingPhrasesPanel);
		}

		public IActionResult Sales()
		{
            _user = GetCurrentUserAsync().Result;
            var userSessionInfo = _user.currentSessionInfo;

            bool validModel;
            DTO.AmoCRM.SalesPanel.V1.GetOut dto;
            SalesPanelViewModel model;

            // 
            _dataSourcesAdded = CheckBackEndWorks();
            if (_dataSourcesAdded == false)
                return RedirectToRoute(new { controller = "Settings", action = "IntegrationAuth" });

            // RedirectToAction("IntegrationAuth"); //return View("~/Views/Settings/IntegrationAuth");
            HttpContext.Session.SetObjectAsJson("CookieContainer", _backEndRequestService.СurrentCookieContainer);

		    DateTime startDate, endDate;
            // SessionSettings from User code block WHICH_GETS_DTO
            // Если у юзера инфа по его периоду аналитики
			if (userSessionInfo?.StartDate != null && userSessionInfo?.EndDate != null)
			{
                startDate = userSessionInfo.StartDate;
                endDate = userSessionInfo.EndDate;
            }
			else
			{
                // TODO Use current month
                var pageInfo = new SessionSettings();
                _user.currentSessionInfo = pageInfo;

			    startDate = pageInfo.StartDate;
			    endDate = pageInfo.EndDate;
			}
            dto = _backEndRequestService.GetSalesPanelData(out _getDataResult, startDate, endDate);

            // If BackEnd gave some data, validate model from BackEnd
            if (dto != null)
            {
                // MODEL from DTO
                model = CreateSalesPanelViewModel(dto);
                validModel = ValidateAmoCRMBackEndData(model);
            }
            else
            {
                validModel = false;
                // TEST MODEL
                model = CreateSalesPanelViewModel(_testEndResult.GetSalesPanelData(out _getDataResult));
            }

            // Use SessionSettings
            model.PageInfo = _user.currentSessionInfo;

            Yandex_AmoCRMViewModel salesModel = new Yandex_AmoCRMViewModel { SalesPanelViewModel = model, MarketingMainPanel = null };
            return View(salesModel);
		}

		public class StartEndDateModel
		{
            public string PanelView { get; set; }
            public string StartDate { get; set; }

			public string EndDate { get; set; }
		}

        [HttpPost]
        public IActionResult GetDataDuringPeriod([FromBody] StartEndDateModel data) //, string enddate
        {
            DateTime startDate = DateTime.Parse(data.StartDate);
            DateTime endDate = DateTime.Parse(data.EndDate);
            var pageInfo = new Models.SessionSettings()
            {
                StartDate = startDate,
                EndDate = endDate
            };
            HttpContext.Session.SetObjectAsJson("PageInfo", pageInfo);
            //var userSessionInfo = GetCurrentUserAsync().Result.currentSessionInfo;
            //user.currentSessionInfo = pageInfo;

            // FOR DEBUG/TEST PURPOSES
            var dto = _backEndRequestService.GetSalesPanelData(out _getDataResult,
                startDate, endDate);
            var model = CreateSalesPanelViewModel(dto);

            model.PageInfo = pageInfo;

            //return RedirectToAction(“Index”);   // After that you can redirect to some pages…
            // Or you can get that data back after inserting into database.. This json displays all the details to our view as well.
            //return Json(true, JsonRequestBehavior.AllowGet); 
            return View("Sales", model);
        }
        public IActionResult Plan()
        {
            // 
            _dataSourcesAdded = CheckBackEndWorks();
            if (!_dataSourcesAdded)
                return View("~/Views/Settings/IntegrationAuth");

            var currentPlan = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");

            //var marketingMainPanel = createTestMarketingMainPanel();
            MarketingMainPanel marketingMainPanel = new MarketingMainPanel();

            if (currentPlan == null)
            {

                var dtoMarketYandex = _backEndRequestService.GetMarketPanelData(out _getMarketDataResult);

                marketingMainPanel.All.Shows.Plan = dtoMarketYandex.Yandex.Shows.Plan;
                marketingMainPanel.All.Shows.Fact = dtoMarketYandex.Yandex.Shows.Fact;
                marketingMainPanel.All.CvVisits.Plan = dtoMarketYandex.Yandex.CvVisits.Plan;
                marketingMainPanel.All.CvVisits.Fact = dtoMarketYandex.Yandex.CvVisits.Fact;
                marketingMainPanel.All.Clicks.Plan = dtoMarketYandex.Yandex.Clicks.Plan;
                marketingMainPanel.All.Clicks.Fact = dtoMarketYandex.Yandex.Clicks.Fact;
                marketingMainPanel.All.CvRequests.Plan = dtoMarketYandex.Yandex.CvRequests.Plan;
                marketingMainPanel.All.CvRequests.Fact = dtoMarketYandex.Yandex.CvRequests.Fact;
                marketingMainPanel.All.Requests.Plan = dtoMarketYandex.Yandex.Requests.Plan;
                marketingMainPanel.All.Requests.Fact = dtoMarketYandex.Yandex.Requests.Fact;
                marketingMainPanel.All.CvSales.Plan = dtoMarketYandex.Yandex.CvSales.Plan;
                marketingMainPanel.All.CvSales.Fact = dtoMarketYandex.Yandex.CvSales.Fact;
                marketingMainPanel.All.Sales.Plan = dtoMarketYandex.Yandex.Sales.Plan;
                marketingMainPanel.All.Sales.Fact = dtoMarketYandex.Yandex.Sales.Fact;
                marketingMainPanel.All.CashFlow.Plan = dtoMarketYandex.Yandex.Revenue.Plan;
                marketingMainPanel.All.CashFlow.Fact = dtoMarketYandex.Yandex.Revenue.Fact;
                marketingMainPanel.All.AverageDealPrice.Plan = dtoMarketYandex.Yandex.AverageDealPrice.Plan;
                marketingMainPanel.All.AverageDealPrice.Fact = dtoMarketYandex.Yandex.AverageDealPrice.Fact;
                marketingMainPanel.All.Charge.Plan = dtoMarketYandex.Yandex.Costs.Plan;
                marketingMainPanel.All.Charge.Fact = dtoMarketYandex.Yandex.Costs.Fact;
                marketingMainPanel.All.Marge.Plan = dtoMarketYandex.Yandex.Marge.Plan;
                marketingMainPanel.All.Marge.Fact = dtoMarketYandex.Yandex.Marge.Fact;
                marketingMainPanel.All.Profit.Plan = dtoMarketYandex.Yandex.Profit.Plan;
                marketingMainPanel.All.Profit.Fact = dtoMarketYandex.Yandex.Profit.Fact;
                marketingMainPanel.All.ROMI.Plan = dtoMarketYandex.Yandex.ROMI.Plan;
                marketingMainPanel.All.ROMI.Fact = dtoMarketYandex.Yandex.ROMI.Fact;

                marketingMainPanel.InternetTraffic = marketingMainPanel.All;
            }
            else
            {
                marketingMainPanel = HttpContext.Session.GetObjectFromJson<MarketingMainPanel>("PlanCurrent");
            }

            return View(marketingMainPanel);
        }
        private void SetFlagsAmoCRMYandexIntegration()
        {
            _user = GetCurrentUserAsync().Result;
            // Проверяем, какие сервисы подключены
            var amoAdded = _backEndRequestService.CheckAmoCRMAccessAdded(_user.UserName, _user.Password);
            ViewData["amoAdded"] = amoAdded;

            var yandexAdded = _backEndRequestService.CheckYandexAccessAdded(_user.UserName, _user.Password);
            ViewData["yandexAdded"] = yandexAdded;

            // Если аккаунты AmoCRM и Yandex подключены, в сессии сохраняется 
            ViewBag.HaveDataServicesAdded = amoAdded && yandexAdded;
        }

        #region Создание ViewModel из DTO

        // Метод создает VM для передачи во View из DTO
        // Считает Итого
        // Выбирает менеджеров и статусы на основе настроек?? пока не реализовано
        public SalesPanelViewModel CreateSalesPanelViewModel(DTO.AmoCRM.SalesPanel.V1.GetOut dto)
		{
            if (dto == null)
                return  new SalesPanelViewModel();

			var vm = ConvertToSalesPanelViewModel(dto);

			vm.AllName = "Итого";

			var allStat = new ManagerStats();

			var allQuantity = 0M;
			foreach (var stat in vm.ManagerStatsDict.Values)
			{
				allStat.SalesPlan += stat.SalesPlan;
				allStat.SalesFactual += stat.SalesFactual;

				allQuantity += stat.AverageDealPrice == 0 ? 0 : stat.SalesFactual / stat.AverageDealPrice;
				allStat.CPO = 0;
			}

			allStat.FactualByPlan = allStat.SalesPlan == 0 ? 0 : (double)(allStat.SalesFactual / allStat.SalesPlan);
			allStat.AverageDealPrice = allQuantity == 0 ? 0 : allStat.SalesFactual / allQuantity;

			allStat.SalesByStatus = new Dictionary<string, DealsSummary>();
			foreach (var status in vm.Statuses)
			{
				var allByStatus = new DealsSummary();
				foreach (var stat in vm.ManagerStatsDict.Values)
				{
					var deal = stat.SalesByStatus[status];
					allByStatus.Value += deal.Value;
					allByStatus.Quantity += deal.Quantity;
				}
				allStat.SalesByStatus[status] = allByStatus;
			}

			var firstStatus = vm.Statuses[0];
			var lastStatus = vm.Statuses[vm.Statuses.Count - 2];
			allStat.CVFirstToLast = allStat.SalesByStatus[firstStatus].Quantity == 0 ?
				0 :
				(double) allStat.SalesByStatus[lastStatus].Quantity/
									allStat.SalesByStatus[firstStatus].Quantity;

			vm.AllManagerStats = allStat;
			return vm;
		}

		private SalesPanelViewModel ConvertToSalesPanelViewModel(DTO.AmoCRM.SalesPanel.V1.GetOut dto)
		{
			var model = new SalesPanelViewModel
			{
				Statuses = dto.Statuses,
				Managers = dto.Managers,
				ManagerStatsDict = new Dictionary<string, ManagerStats>(),
				CVByStatusList = dto.CVByStatusList.Select(e => new StatusConversion()
				{
					Convertion = e.Convertion,
					First = e.First,
					Second = e.Second
				}).ToList()
			};

			foreach (var managerStats in dto.ManagerStatsDict)
			{
				model.ManagerStatsDict.Add(managerStats.Key, new ManagerStats
				{
					SalesByStatus = ConvertSalesByStatus(managerStats.Value.SalesByStatus),
					AverageDealPrice = managerStats.Value.AverageDealPrice,
					CPO = managerStats.Value.CPO,
					CVFirstToLast = managerStats.Value.CVFirstToLast,
					FactualByPlan = managerStats.Value.PlanByFactual,
					SalesFactual = managerStats.Value.SalesFactual,
					SalesPlan = managerStats.Value.SalesPlan
				});
			}

			return model;
		}

		private Dictionary<string, DealsSummary> ConvertSalesByStatus
			(Dictionary<string, DTO.AmoCRM.SalesPanel.V1.DealsSummary> dictIn)
		{
			return dictIn.Keys.ToDictionary(key => key, key => new DealsSummary
			{
				Quantity = dictIn[key].Quantity,
				Value = dictIn[key].Value
			});
		}

		#endregion
	}

}
