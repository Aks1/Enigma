﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using EmptyMVC6.ViewModels;
using EmptyMVC6.Services;
using Microsoft.AspNet.Authorization;

namespace EmptyMVC6.Controllers
{
	[Authorize]
	public class MarketController : Controller
	{
		bool getDataResult;
		private readonly IBackEndRequestService _backEndRequestService;

		public MarketController(IBackEndRequestService backEndRequestService)
		{
			_backEndRequestService = backEndRequestService;
		}

		public IActionResult Market()
		{
			var dto = _backEndRequestService.GetSalesPanelData(out getDataResult);
			var model = CreateSalesPanelViewModel(dto);

			return View(model);
		}

		public IActionResult Sales()
		{
			List<object> salesObjectModel = new List<object>();
			salesObjectModel.Add(_backEndRequestService.GetSalesPanelData(out getDataResult)); //CreateDummy()

			return View(salesObjectModel);
		}

		public IActionResult Error()
		{
			return View();
		}
		#region Создание ViewModel из DTO

		// Метод создает VM для передачи во View из DTO
		// Считает Итого
		// Выбирает менеджеров и статусы на основе настроек?? пока не реализовано
		public SalesPanelViewModel CreateSalesPanelViewModel(DTO.AmoCRM.SalesPanel.V1.GetOut dto)
		{
			var vm = ConvertToSalesPanelViewModel(dto);

			vm.AllName = "Итого";

			var allStat = new ManagerStats();

			var allQuantity = 0M;
			foreach (var stat in vm.ManagerStatsDict.Values)
			{
				allStat.SalesPlan += stat.SalesPlan;
				allStat.SalesFactual += stat.SalesFactual;

				allQuantity += stat.AverageDealPrice == 0 ? 0 : stat.SalesFactual / stat.AverageDealPrice;
				allStat.CPO = 0;
			}

			allStat.FactualByPlan = allStat.SalesPlan == 0 ? 0 : (double)(allStat.SalesFactual / allStat.SalesPlan);
			allStat.AverageDealPrice = allQuantity == 0 ? 0 : allStat.SalesFactual / allQuantity;

			allStat.SalesByStatus = new Dictionary<string, DealsSummary>();
			foreach (var status in vm.Statuses)
			{
				var allByStatus = new DealsSummary();
				foreach (var stat in vm.ManagerStatsDict.Values)
				{
					var deal = stat.SalesByStatus[status];
					allByStatus.Value += deal.Value;
					allByStatus.Quantity += deal.Quantity;
				}
				allStat.SalesByStatus[status] = allByStatus;
			}

			var firstStatus = vm.Statuses[0];
			var lastStatus = vm.Statuses[vm.Statuses.Count - 2];
			allStat.CVFirstToLast = allStat.SalesByStatus[firstStatus].Quantity == 0 ?
				0 :
				(double)allStat.SalesByStatus[lastStatus].Quantity /
									allStat.SalesByStatus[firstStatus].Quantity;

			vm.AllManagerStats = allStat;
			return vm;
		}

		private SalesPanelViewModel ConvertToSalesPanelViewModel(DTO.AmoCRM.SalesPanel.V1.GetOut dto)
		{
			var model = new SalesPanelViewModel
			{
				Statuses = dto.Statuses,
				Managers = dto.Managers,
				ManagerStatsDict = new Dictionary<string, ManagerStats>(),
				CVByStatusList = dto.CVByStatusList.Select(e => new StatusConversion()
				{
					Convertion = e.Convertion,
					First = e.First,
					Second = e.Second
				}).ToList()
			};

			foreach (var managerStats in dto.ManagerStatsDict)
			{
				model.ManagerStatsDict.Add(managerStats.Key, new ManagerStats
				{
					SalesByStatus = ConvertSalesByStatus(managerStats.Value.SalesByStatus),
					AverageDealPrice = managerStats.Value.AverageDealPrice,
					CPO = managerStats.Value.CPO,
					CVFirstToLast = managerStats.Value.CVFirstToLast,
					FactualByPlan = managerStats.Value.PlanByFactual,
					SalesFactual = managerStats.Value.SalesFactual,
					SalesPlan = managerStats.Value.SalesPlan
				});
			}

			return model;
		}

		private Dictionary<string, DealsSummary> ConvertSalesByStatus
			(Dictionary<string, DTO.AmoCRM.SalesPanel.V1.DealsSummary> dictIn)
		{
			return dictIn.Keys.ToDictionary(key => key, key => new DealsSummary
			{
				Quantity = dictIn[key].Quantity,
				Value = dictIn[key].Value
			});
		}

		#endregion
	}

}
