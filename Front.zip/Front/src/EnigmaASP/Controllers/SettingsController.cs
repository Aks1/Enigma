﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using EmptyMVC6.ViewModels;
using EmptyMVC6.Services;
using EmptyMVC6.Models;
using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Identity;
using EmptyMVC6.Helpers;
using Microsoft.AspNet.Http;

namespace EmptyMVC6.Controllers
{
	[Authorize]
	public class SettingsController : Controller
	{
		private readonly UserManager<ApplicationUser> _userManager;
		private readonly SignInManager<ApplicationUser> _signInManager;
		private readonly IBackEndRequestService _backEndRequestService;
		ApplicationUser _user;

		public SettingsController(
			UserManager<ApplicationUser> userManager,
			SignInManager<ApplicationUser> signInManager, IBackEndRequestService backEndRequestService)
		{
			_backEndRequestService = backEndRequestService;
			_userManager = userManager;
			_signInManager = signInManager;
			_backEndRequestService = backEndRequestService;
		}
		private async Task<ApplicationUser> GetCurrentUserAsync()
		{

			return await _userManager.FindByNameAsync(HttpContext.User.Identity.Name);
		}
		private bool BackEndInitializer()
		{
			//Initializing
			if (HttpContext != null)
			{
                _user = GetCurrentUserAsync().Result;
				var cookieContainer = HttpContext.Session.GetObjectFromJson<System.Net.CookieContainer>("CookieContainer");
				if (cookieContainer != null && cookieContainer.Count != 0)
				{
					_backEndRequestService.InitializeBackEndRequestService(_user.UserName, _user.Password, cookieContainer);
				}

				else
				{
					_backEndRequestService.InitializeBackEndRequestService(_user.UserName, _user.Password);
					HttpContext.Session.SetObjectAsJson("CookieContainer", 
                                                        _backEndRequestService.СurrentCookieContainer);
				}
			}
			else // TESTING/DEVELOPMENT ONLY
			{
				_backEndRequestService.InitializeBackEndRequestService();
				//
				return false;
			}

			//         user.cookieContainerContainer. = _backEndRequestService.СurrentCookieContainer;
			return true;
		}

		public IActionResult IntegrationAuth()
		{
			ViewData["Calendar"] = "off";
			ViewBag.UserName = HttpContext.User.Identity.Name;

			BackEndInitializer();

			// Если свежезарегистрированный аккаунт
			ViewBag.IsNewAccount = (HttpContext.Session.GetString("NewAcc") == "NewAcc");
			if (ViewBag.IsNewAccount)
                HttpContext.Session.SetString("NewAcc", "NotNewAcc");

            SetFlagsAmoCRMYandexIntegration();

		    return View("IntegrationAuth");
		}
        private void SetFlagsAmoCRMYandexIntegration()
        {
            // Проверяем, какие сервисы подключены
            var amoAdded = _backEndRequestService.CheckAmoCRMAccessAdded(_user.UserName, _user.Password);
            ViewData["amoAdded"] = amoAdded;

            var yandexAdded = _backEndRequestService.CheckYandexAccessAdded(_user.UserName, _user.Password);
            ViewData["yandexAdded"] = yandexAdded;

            // Если аккаунты AmoCRM и Yandex подключены, в сессии сохраняется 
            ViewBag.HaveDataServicesAdded = amoAdded && yandexAdded;
        }

		public IActionResult YandexGetToken(string code)
		{
			var view = IntegrationAuth();

			if (string.IsNullOrEmpty(code))
				return view;

            var yandexAdded = false;

            var token = _backEndRequestService.AuthYandex(code);
		    if (!string.IsNullOrEmpty(token))
                yandexAdded = _backEndRequestService.AddYandexAccess(token);			

			ViewData["yandexAdded"] = yandexAdded;
			ViewData["token"] = token;

			return view;
		}

        //
        public IActionResult YandexDisintegrate()
        {
            ViewData["Calendar"] = "off";
            ViewBag.UserName = HttpContext.User.Identity.Name;
            var success = _backEndRequestService.DeleteYandexAccounts(_user.UserName, _user.Password);

            if (success)
                ViewData["yandexAdded"] = false;
            return View("AmoCRMIntegrate");
        }

        //
        public IActionResult AmoCRMDisintegrate()
        {
            ViewData["Calendar"] = "off";
            ViewBag.UserName = HttpContext.User.Identity.Name;

            var success = _backEndRequestService.DeleteAmoCRMAccounts(_user.UserName, _user.Password);
            if(success) 
                ViewData["amoAdded"] = false;
            return View("AmoCRMIntegrate");
        }
        //
        public IActionResult AmoCRMIntegrate()
		{
			ViewData["Calendar"] = "off";
			ViewBag.UserName = HttpContext.User.Identity.Name;

            ViewData["amoAdded"] = false;
            return View();
		}

		[HttpPost]
		public IActionResult AmoCRMIntegrate(AmoCRMReg amoCRMRegModel)
		{
			ViewData["Calendar"] = "off";
			ViewBag.UserName = HttpContext.User.Identity.Name;

            // На всякий случай удаляем уже подключенные аккаунты
            // TODO: В будущем - несколько акков? Что тогда?
            _backEndRequestService.DeleteAmoCRMAccounts(_user.UserName, _user.Password);

            if (!ModelState.IsValid) return View();

			// Если данные корректны, пробуем интегрировать аккаунт
			var success = _backEndRequestService.AddAccountAmoCRM(amoCRMRegModel);

			//
			if (success)
			{
				ViewData["amoAdded"] = true;
				return RedirectToLocal("IntegrationAuth");
			}
			// TODO green bad alarm
			ViewData["amoAdded"] = false;
			return View(amoCRMRegModel);
		}

		private IActionResult RedirectToLocal(string returnUrl)
		{
			if (Url.IsLocalUrl(returnUrl))
			{
				return Redirect(returnUrl);
			}
			else
			{
				return RedirectToAction(nameof(SettingsController.IntegrationAuth), "Settings");
			}
		}

		public IActionResult Error()
		{
			return View();
		}

		#region Создание ViewModel из DTO

		// Метод создает VM для передачи во View из DTO
		// Считает Итого
		// Выбирает менеджеров и статусы на основе настроек?? пока не реализовано
		public SalesPanelViewModel CreateSalesPanelViewModel(DTO.AmoCRM.SalesPanel.V1.GetOut dto)
		{
			var vm = ConvertToSalesPanelViewModel(dto);

			vm.AllName = "Итого";

			var allStat = new ManagerStats();

			var allQuantity = 0M;
			foreach (var stat in vm.ManagerStatsDict.Values)
			{
				allStat.SalesPlan += stat.SalesPlan;
				allStat.SalesFactual += stat.SalesFactual;

				allQuantity += stat.AverageDealPrice == 0 ? 0 : stat.SalesFactual / stat.AverageDealPrice;
				allStat.CPO = 0;
			}

			allStat.FactualByPlan = allStat.SalesPlan == 0 ? 0 : (double)(allStat.SalesFactual / allStat.SalesPlan);
			allStat.AverageDealPrice = allQuantity == 0 ? 0 : allStat.SalesFactual / allQuantity;

			allStat.SalesByStatus = new Dictionary<string, DealsSummary>();
			foreach (var status in vm.Statuses)
			{
				var allByStatus = new DealsSummary();
				foreach (var stat in vm.ManagerStatsDict.Values)
				{
					var deal = stat.SalesByStatus[status];
					allByStatus.Value += deal.Value;
					allByStatus.Quantity += deal.Quantity;
				}
				allStat.SalesByStatus[status] = allByStatus;
			}

			var firstStatus = vm.Statuses[0];
			var lastStatus = vm.Statuses[vm.Statuses.Count - 2];
			allStat.CVFirstToLast = allStat.SalesByStatus[firstStatus].Quantity == 0 ?
				0 :
				(double)allStat.SalesByStatus[lastStatus].Quantity /
									allStat.SalesByStatus[firstStatus].Quantity;

			vm.AllManagerStats = allStat;
			return vm;
		}

		private SalesPanelViewModel ConvertToSalesPanelViewModel(DTO.AmoCRM.SalesPanel.V1.GetOut dto)
		{
			var model = new SalesPanelViewModel
			{
				Statuses = dto.Statuses,
				Managers = dto.Managers,
				ManagerStatsDict = new Dictionary<string, ManagerStats>(),
				CVByStatusList = dto.CVByStatusList.Select(e => new StatusConversion()
				{
					Convertion = e.Convertion,
					First = e.First,
					Second = e.Second
				}).ToList()
			};

			foreach (var managerStats in dto.ManagerStatsDict)
			{
				model.ManagerStatsDict.Add(managerStats.Key, new ManagerStats
				{
					SalesByStatus = ConvertSalesByStatus(managerStats.Value.SalesByStatus),
					AverageDealPrice = managerStats.Value.AverageDealPrice,
					CPO = managerStats.Value.CPO,
					CVFirstToLast = managerStats.Value.CVFirstToLast,
					FactualByPlan = managerStats.Value.PlanByFactual,
					SalesFactual = managerStats.Value.SalesFactual,
					SalesPlan = managerStats.Value.SalesPlan
				});
			}

			return model;
		}

		private Dictionary<string, DealsSummary> ConvertSalesByStatus
			(Dictionary<string, DTO.AmoCRM.SalesPanel.V1.DealsSummary> dictIn)
		{
			return dictIn.Keys.ToDictionary(key => key, key => new DealsSummary
			{
				Quantity = dictIn[key].Quantity,
				Value = dictIn[key].Value
			});
		}

		#endregion
	}

}
