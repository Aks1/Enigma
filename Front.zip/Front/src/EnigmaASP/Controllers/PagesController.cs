﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Mvc;
using EmptyMVC6.ViewModels;
using EmptyMVC6.Services;

namespace EmptyMVC6.Controllers
{
    public class PagesController : Controller
    {
        private readonly IBackEndRequestService _backEndRequestService;

        public PagesController(IBackEndRequestService backEndRequestService)
        {
            _backEndRequestService = backEndRequestService;
        }

        public IActionResult Market()
        {
            //var dto = _backEndRequestService.GetSalesPanelData();
            //var model = CreateSalesPanelViewModel(dto);

            ViewData["Calendar"] = "calendar";
            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult NotFoundError()
        {
            return View();
        }

        public IActionResult InternalServerError()
        {
            return View();
        }

        public IActionResult EmptyPage()
        {
            return View();
        }

        public IActionResult ForgotPassword()
        {
            return View();
        }

        
    }

}
