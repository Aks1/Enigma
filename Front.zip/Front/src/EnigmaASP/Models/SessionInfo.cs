﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace EmptyMVC6.Models
{
	// Add data for page
	public class SessionSettings
	{
		[Key]
		public string SessionSettingsID
		{
			get; set;
		}

		// _off - нет календаря. Если Top - сверху
		string calendarState = "CalendarOn_Top";
		public string CalendarState
		{
			get
			{
				return calendarState;
			}
			set
			{
				calendarState = value;
			}
		}
		//
		DateTime startDate = DateTime.Now.AddDays(-30);
		public DateTime StartDate
		{
			get
			{
				return startDate;
			}
			set
			{
				startDate = value;
			}
		}
		DateTime endDate = DateTime.Now;
		public DateTime EndDate
		{
			get
			{
				return endDate;
			}
			set
			{
				endDate = value;
			}
		}
		bool quantValSwitcher = true;
		public bool QuantValSwitcher
		{
			get
			{
				return quantValSwitcher;
			}
			set
			{
				quantValSwitcher = value;
			}
		}
		string reference = "Уважаемый клиент";
		public string Reference
		{
			get
			{
				return reference;
			}
			set
			{
				reference = value;
			}
		}
		string lastUrl = "Home/Index";
		public string LastUrl
		{
			get
			{
				return lastUrl;
			}
			set
			{
				lastUrl = value;
			}
		}
	}
}
