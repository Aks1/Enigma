﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations.Schema;
using System.Net;

namespace EmptyMVC6.Models
{
	// Add profile data for application users by adding properties to the ApplicationUser class
	public class ApplicationUser : IdentityUser
	{
		//
		public string YandexDirectLogin { get; set; }
		public string YandexDirectToken { get; set; }
		//
		public List<AmoCRMReg> AmoCRM { get; set; }
		//public class cookieContainerContainer
		//{
		//    // Суммарное число (в штуках) сделок
		//    public int CookieContainerID;
		//    // Суммарный объем сделок (в рублях)
		//    public CookieContainer cookieContainer { get; set; }
		//}
		public string Password { get; set; }
		public SessionSettings currentSessionInfo { get; set; }
		public List<UserPlan>  UserPlan { get; set; }
		public List<UserExpenses>  UserExpenses { get; set; }

	}
}

