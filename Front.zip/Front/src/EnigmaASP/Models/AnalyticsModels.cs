﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;

namespace EmptyMVC6.Models
{
	// Add data for page
	public class UserPlan
    {
        //
        [Key]
        public string UserPlanID
        {
            get; set;
        }
        //
        public float PlanValue
		{
			get; set;
		}

        //
        public float PlanAmount
        {
            get; set;
        }
        public float AverageSaleValue
        {
            get; set;
        }
    }
	public class UserExpenses
    {
        //
        [Key]
        public string UserExpensesID
        {
            get; set;
        }
        //
        public float ExpensesValue
        {
			get; set;
		}

		//
		public float MarketExpenses
        {
			get; set;
		}
		//
		public float KeyExpenses
        {
			get; set;
		}
	}

}
