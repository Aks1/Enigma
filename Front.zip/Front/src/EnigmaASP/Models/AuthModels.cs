﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;

namespace EmptyMVC6.Models
{
	// Add data for page
	public class AmoCRMReg
	{
		//
		[Required]
		public string Address
		{
			get; set;
		}

		//
		[Required]
		public string Login
		{
			get; set;
		}
		//
		[Key]
		[Required]
		public string APIKey
		{
			get; set;
		}
	}
	//public class AmoCRMAcc
	//{
	//	//
	//	public string Address
	//	{
	//		get; set;
	//	}

	//	//
	//	public string Login
	//	{
	//		get; set;
	//	}
	//	//
	//	public string APIKey
	//	{
	//		get; set;
	//	}
	//}
	public struct BodyBuildingRules
	{
		public string grant_type;
		public string code;
		public string client_id;
		public string client_secret;
	}

}
