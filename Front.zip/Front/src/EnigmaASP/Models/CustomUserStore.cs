﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Builder;
using Microsoft.AspNet.Http;

namespace EmptyMVC6.Models
{
    // You may need to install the Microsoft.AspNet.Http.Abstractions package into your project
    public class CustomUserStore
    {
        private readonly RequestDelegate _next;

        public CustomUserStore(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {

            return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class CustomUserStoreExtensions
    {
        public static IApplicationBuilder UseCustomUserStore(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CustomUserStore>();
        }
    }
}
