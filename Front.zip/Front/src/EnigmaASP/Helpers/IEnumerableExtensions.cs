﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.Helpers
{
    public static class EnumerableExtensions
    {
        /// <summary>
        /// Determines whether the collection is null or contains no elements.
        /// </summary>
        /// <typeparam name="T">The IList type.</typeparam>
        /// <param name="list">The IList, which may be null or empty.</param>
        /// <returns>
        ///     <c>true</c> if the IList is null or empty; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNullOrEmpty<T>(this IList<T> list)
        {
            return list == null || list.Count == 0;
        }

        //public static bool IsNullOrEmpty<T>(this IEnumerable<T> enumerable)
        //{
        //    if (enumerable == null)
        //    {
        //        return true;
        //    }
        //    /* If this is a list, use the Count property for efficiency. 
        //     * The Count property is O(1) while IEnumerable.Count() is O(N). */
        //    var collection = enumerable as ICollection<T>;
        //    if (collection != null)
        //    {
        //        return collection.Count < 1;
        //    }
        //    return !enumerable.Any();
        //}
    }
}
