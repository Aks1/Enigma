﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

//using EmptyMVC6.Models;
//using Microsoft.AspNet.Http;
//using Microsoft.AspNet.Http.Features;
//using Microsoft.AspNet.Identity;
//using Microsoft.AspNet.Mvc.Rendering;
//using Microsoft.AspNet.Mvc.ViewFeatures;
//using Newtonsoft.Json;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using System.Threading;
//using Microsoft.Extensions.OptionsModel;
//using Microsoft.Extensions.Logging;
//using Microsoft.AspNet.Identity.EntityFramework;
////using System.Web;
////using System.Web.Mvc;

//namespace EmptyMVC6
//{
//    // ReSharper disable once InconsistentNaming
//    public class EnigmaUserManager : UserManager<ApplicationUser>
//    {

//        public class ApplicationRole : IdentityRole
//        {
//        }
//        public class ApplicationUserLogin : IdentityUserLogin<Guid>
//        {
//        }
//        public class ApplicationUserClaim : IdentityUserClaim<Guid>
//        {
//        }
//        public class ApplicationRoleClaim : IdentityRoleClaim<Guid>
//        {
//        }

//        //public EnigmaUserManager(Microsoft.AspNet.Identity.EntityFramework.UserStore<ApplicationUser> store)
//        //    : base(store)
//        //{
//        //}
//        public EnigmaUserManager(IUserStore<ApplicationUser> store, IOptions<IdentityOptions> optionsAccessor,
//        IPasswordHasher<ApplicationUser> passwordHasher, IEnumerable<IUserValidator<ApplicationUser>> userValidators,
//        IEnumerable<IPasswordValidator<ApplicationUser>> passwordValidators, ILookupNormalizer keyNormalizer,
//        IdentityErrorDescriber errors, IServiceProvider services,
//        ILogger<UserManager<ApplicationUser>> logger, IHttpContextAccessor contextAccessor)
//        : base(
//            store, optionsAccessor, passwordHasher, userValidators, passwordValidators, keyNormalizer, errors,
//            services, logger, contextAccessor)
//        {
//        }
//        //public override Task<ApplicationUser> FindAsync(string userName, string password)
//        //{
//        //    Task<ApplicationUser> taskInvoke = Task<ApplicationUser>.Factory.StartNew(() =>
//        //    {
//        //        PasswordVerificationResult result = this.PasswordHasher.VerifyHashedPassword(userName, password);
//        //        if (result == PasswordVerificationResult.SuccessRehashNeeded)
//        //        {
//        //            return Store.FindByNameAsync(userName).Result;
//        //        }
//        //        return null;
//        //    });
//        //    return taskInvoke;
//        //}
//    }

//    public class MyContext : IdentityDbContext<ApplicationUser, EnigmaUserManager.ApplicationRole, string>
//    {
//        protected override void OnModelCreating(Microsoft.Data.Entity.ModelBuilder builder)
//        {
//            base.OnModelCreating(builder);
//        }
//    }
//    //
//    public class EnigmaUserStore : UserStore<ApplicationUser, EnigmaUserManager.ApplicationRole, MyContext, string>
//    {
//        private bool _disposed { get; set; }
//        public EnigmaUserStore(MyContext context, IdentityErrorDescriber describer = null)
//        : base(context, describer)
//        {

//        }
//        private void ThrowIfDisposed()
//        {
//            if (_disposed)
//            {
//                throw new ObjectDisposedException(GetType().Name);
//            }
//        }
//        /// <summary>
//        /// Gets or sets the persistence store the manager operates over.
//        /// </summary>
//        /// <value>The persistence store the manager operates over.</value>
//        protected internal IUserStore<ApplicationUser> Store { get; set; }
//        //public override Task<ApplicationUser> FindByIdAsync(string userId, CancellationToken cancellationToken = default(CancellationToken))
//        //{

//        //   return base.FindByIdAsync(userId, cancellationToken);
//        //}
//        /// <summary>
//        /// Finds and returns a user, if any, who has the specified <paramref name="userId"/>.
//        /// </summary>
//        /// <param name="userId">The user ID to search for.</param>
//        /// <returns>
//        /// The <see cref="Task"/> that represents the asynchronous operation, containing the user matching the specified <paramref name="userId"/> if it exists.
//        /// </returns>
//        public override Task<ApplicationUser> FindByIdAsync(string userId, CancellationToken cancellationToken = default(CancellationToken))
//        {
//            ThrowIfDisposed();
//            return Store.FindByIdAsync(userId, cancellationToken);
//        }
//    }
//}
