﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using Microsoft.AspNet.Http;
using Microsoft.AspNet.Http.Features;
using Microsoft.AspNet.Mvc.Rendering;
using Microsoft.AspNet.Mvc.ViewFeatures;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
//using System.Web;
//using System.Web.Mvc;

namespace EmptyMVC6.Helpers
{
    // ReSharper disable once InconsistentNaming
    public static class SessionExtensions
    {
        //private static readonly IHttpContextAccessor _httpContextAccessor;
        //private static ISession _session => _httpContextAccessor.HttpContext.Session;
        //IHttpContextAccessor httpContextAccessor,

        public static void SetObjectAsJson(this ISession session, string key, object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }

        public static T GetObjectFromJson<T>(this ISession session, string key)
        {
            var value = session.GetString(key);

            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
        }

        public static byte[] ToBytes(this DateTime dt)
        {
            long utcNowAsLong = dt.ToBinary();
            return BitConverter.GetBytes(utcNowAsLong);
        }


        public static DateTime FromBytes(this byte[] bytes)
        {
            long utcNowLongBack = BitConverter.ToInt64(bytes, 0);
            return DateTime.FromBinary(utcNowLongBack);
        }
    }

    //
    public class SessionProxy
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private ISession _session => _httpContextAccessor.HttpContext.Session;
        public SessionProxy(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor; //might need to throw an exception here if session is null
        }


        //http://stackoverflow.com/questions/10480110/how-to-check-whether-session-is-expired-or-not-in-asp-net
        //if(Session["Userid"]==null)
        //{
        //  //session expire redirect to login page 
        //}
        //
        public DateTime LastUpdate
        {
            get
            {
                return this._session.Get("LastUpdate") != null
                            ? this._session.Get("LastUpdate").FromBytes()
                            : DateTime.MinValue;
            }
            set { _session.Set("LastUpdate", value.ToBytes()); }
        }

        public string UserLastName
        {
            get { return _session.GetString("UserLastName"); }
            set { _session.SetString("UserLastName", value); }
        }


    }
}
