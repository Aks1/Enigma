﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EmptyMVC6.ViewModels;
using System.Text;
using EmptyMVC6.Helpers;
using Newtonsoft.Json.Linq;

using RestSharp;
using RestSharp.Authenticators;
using EmptyMVC6.Models;

namespace EmptyMVC6.Services
{
	public class BackEndRequestService : IBackEndRequestService
	{
		//REST клиент, используемый для запросов
		private readonly RestClient _client = null;
        private RestRequest request;

        private const string EnigmaAuthStr = "API/App/Account/V1/Authorize";
        private const string EnigmaRegStr = "API/App/Account/V1/Register";

        private const string YandexAccListStr = "API/Yandex/Account/V1/List";
        private const string YandexAccAddStr = "API/Yandex/Account/V1/Add";
        private const string YandexAccDelStr = "API/Yandex/Account/V1/Delete";

        private const string AmoAccListStr = "API/Yandex/Account/V1/List";
        private const string AmoAccAddStr = "API/AmoCRM/Account/V1/Add";
        private const string AmoAccDelStr = "API/Yandex/Account/V1/Delete";

        private const string Url = "http://enigmaapp.azurewebsites.net"; // ConfigurationManager.AppSettings["applicationUrl"];
		//
	    private string CurrentUserName { get; set; }
	    private string CurrentPassword { get; set; }
		public CookieContainer СurrentCookieContainer { get; set; }

		public BackEndRequestService()
		{

			//Создаём объект REST клиента
			_client = new RestClient();
			//Формируем строку URL сервера
			_client.BaseUrl = new Uri(Url);
			//_client.BaseUrl = new Uri("http://localhost:5123");
			//_client.BaseUrl = new Uri("http://localhost:8888");


			//Добавляем в клиент контейнер для сохранения cookies
			_client.CookieContainer = new CookieContainer();

			//Тест создания учётных записей
			//CreateAccountsTest();​

			//Тест получения данных панели продаж
			//SalesPanelTest();
		}

		public void InitializeBackEndRequestService(string currentUserName = "test2@test.ru",
                                                    string currentPassword = "testtest",
                                                    CookieContainer cookieContainer = null)
		{
			CurrentUserName = currentUserName;
			CurrentPassword = currentPassword;
			СurrentCookieContainer = cookieContainer;
		}

        #region Яндекс

        #region Объекты для запроса "GetCampaign" для проверки токена

        public struct GetCampaignsRequestRoot
        {
            public string token;
            public string method;
        }

        public class GetCampaignRoot
        {
            public List<Campaign> data { get; set; }
        }

        public class Campaign
        {
            public string Login { get; set; }
            //public double Sum { get; set; }
            //public string StatusModerate { get; set; }
            //public int CampaignID { get; set; }
            //public string Status { get; set; }
            //public string StartDate { get; set; }
            //public string IsActive { get; set; }
            //public double SumAvailableForTransfer { get; set; }
            //public string ContextStrategyName { get; set; }
            //public object AgencyName { get; set; }
            //public string StrategyName { get; set; }
            //public string EnableRelatedKeywords { get; set; }
            //public string CampaignCurrency { get; set; }
            //public string ManagerName { get; set; }
            //public double Rest { get; set; }
            //public string DayBudgetEnabled { get; set; }
            //public string StatusArchive { get; set; }
            //public int Clicks { get; set; }
            //public string StatusActivating { get; set; }
            //public int Shows { get; set; }
            //public string Name { get; set; }
            //public string ExtendedAdTitleEnabled { get; set; }
            //public string StatusShow { get; set; }
        }
        #endregion

        ///<summary>
        /// Проверка токена Яндекса на валидность
        ///</summary>
        private string YandexGetLogin(string token)
        {
            string retlogin = null;

            _client.BaseUrl = new Uri("https://api.direct.yandex.ru");

            //Создаём запрос
            var request = new RestRequest {Resource = "/live/v4/json/"};

            // TODO: логин нужно получать не через список кампаний, а через ClientInfo
            //Заполняем входные данные запроса
            var getCampaignsRequestBody = new GetCampaignsRequestRoot { token = token, method = "GetCampaignsList" };

            var responseBody = Execute<GetCampaignRoot>(request, getCampaignsRequestBody);
            if (!(responseBody?.data == null || responseBody.data.Count == 0))
                retlogin = responseBody.data.First().Login;

            //Возвращаем результат
            return retlogin;
		}

		//public struct BodyBuildingRules
		//{
		//    public string grant_type;
		//    public string code;
		//    public string client_id;
		//    public string client_secret;
		//}

		public struct BodyBuildingRules1
		{
			public string token_type;
			public string access_token;
			public string expires_in;
		}

		//Приложение с доступом к Директу
	    private const string ClientId = "0c5409c121914b16b5ee42d18923508d";
	    private const string ClientSecret = "f68df41578f446c393e4fdaa2f0369cd";

	    public string AuthYandex(string code)
		{
			_client.BaseUrl = new Uri(@"https://oauth.yandex.ru");

			//Результат запросов
			//BodyBuildingRules1 resultStatus;

			//Создаём запрос
	        request = new RestRequest {Resource = "token"};

	        //Заполняем входные данные запроса
			var bodyBuildingRules = new BodyBuildingRules
			{
				grant_type = "authorization_code",
				code = code,
				client_id = ClientId,
				client_secret = ClientSecret
			};

			//Выполняем запрос
			//resultStatus = Execute<BodyBuildingRules1>(request, bodyBuildingRules);

			request.Method = Method.POST;
			request.RequestFormat = DataFormat.Json;
			//request.AddBody(bodyBuildingRules);

			//request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
			//request.AddHeader("Accept", "application/json");
			request.AddParameter("grant_type", "authorization_code");
			request.AddParameter("code", code);
			request.AddParameter("client_id", ClientId);
			request.AddParameter("client_secret", ClientSecret);

			//var auth = new HttpBasicAuthenticator(_clientId, _clientSecret);
			//_client.Authenticator = auth;

			var response = _client.Execute<BodyBuildingRules1>(request);
			if (response.StatusCode != System.Net.HttpStatusCode.OK)
                return null;

			//Десериализуем объект
			var deserialized = JsonConvert.DeserializeObject<BodyBuildingRules1>(response.Content);

			//Возвращаем результат
			return deserialized.access_token;
		}

        public bool CheckYandexAccessAdded(string enigmaLogin, string enigmaPass)
        {
            // TODO: в этой точке разве может не быть аккаунта Энигмы? Тогда удалить эту проверку
            var enigmaAccValid = AuthorizeEnigmaAcc(enigmaLogin, enigmaPass);
            if (!enigmaAccValid)
                return false;

            // Пустой список
            DTO.Yandex.Account.V1.ListOut listOut;  //Execute<DTO.Yandex.Account.V1.ListOut>(request, null);

            // Проверяем налчие Yandex аккаунта, получаем список аккаунтов
            bool result = GetYandexAccList(out request, out listOut);

            return result;
        }
        private bool GetYandexAccList(out RestRequest request, out DTO.Yandex.Account.V1.ListOut listOut)
        {
            bool result = true;
            //Создаём запрос получения списка учётных записей AmoCRM
            request = new RestRequest { Resource = YandexAccListStr };
            //Получаем список 
            listOut = Execute<DTO.Yandex.Account.V1.ListOut>(request, null);

            //Если список пустой
            if (listOut?.YandexAccesses == null || listOut.YandexAccesses.Count == 0)
            {
                //Выходим с ошибкой
                return false;
            }

            return result;
        }

        public bool AddYandexAccess(string yandexToken)
        {
            var yandexLogin = YandexGetLogin(yandexToken);
            if (string.IsNullOrWhiteSpace(yandexLogin))
                return false;

            //Создаём запрос
            request = new RestRequest { Resource = YandexAccAddStr };

            //Заполняем входные данные запроса
            var addIn = new DTO.Yandex.Account.V1.AddIn
            {
                Login = yandexLogin,
                Token = yandexToken
            };

            //Выполняем запрос
            var resultStatus = Execute(request, addIn);

            //Возвращаем результат
            return resultStatus;
        }

        public bool DeleteYandexAccounts(string enigmaLogin, string enigmaPass)
        {
            bool success;
            DTO.Yandex.Account.V1.ListOut accountsToDelete;
            success = GetYandexAccList(out request, out accountsToDelete);

            //Если список пустой
            if (!success) return false;

            //Выбираем список учётных записей
            var yandexAccesses = accountsToDelete?.YandexAccesses;

            // Создаем запрос на удаление
            request = new RestRequest { Resource = YandexAccDelStr };

            foreach (var item in yandexAccesses)
            {
                var deleteIn = new DTO.Yandex.Account.V1.DeleteIn { YandexAccountId = item.Id };

                //Удаляем данный аккаунт
                var getOut = Execute<DTO.Yandex.Account.V1.DeleteIn>(request, deleteIn);
            }

            return success;
        }
        #endregion

        #region Регистрация и авторизация в Энигме
        public bool RegisterEnigmaAcc(string login, string password)
		{
			//Результат запросов
			bool resultStatus;

            var request = new RestRequest { Resource = EnigmaRegStr };

			//Заполняем входные данные запроса
			var registerIn = new DTO.App.Account.V1.RegisterIn
			{
				Login = login,
				Password = password
			};

			//Выполняем запрос
			resultStatus = Execute(request, registerIn);
			//Возвращаем результат
			return resultStatus;
		}

		public bool AuthorizeEnigmaAcc(string login, string password)
		{
			//Результат запросов
			bool resultStatus;

            var request = new RestRequest { Resource = EnigmaAuthStr };

			//Заполняем входные данные запроса
			var authorizeIn = new DTO.App.Account.V1.AuthorizeIn
			{
				Login = login,
				Password = password
			};

			//Выполняем запрос
			resultStatus = Execute(request, authorizeIn);
			//Возвращаем результат
			return resultStatus;
		}

        #endregion

        #region АmoCRM
        //public bool AddAccountAmoCRM()
        //{
        //    return AddAccountAmoCRM("krdat", "krd001@alfa-bz.ru", "f3a678b57624d4aba77978a880ffe4cc");
        //}
        // amo@rlaz.ru 9f5121681771b189886e798f88843bff rlaz

        public bool AddAccountAmoCRM(AmoCRMReg amoCrmRegModel)
		{
			return AddAccountAmoCRM(amoCrmRegModel.Address, amoCrmRegModel.Login, amoCrmRegModel.APIKey);
		}

		public bool AddAccountAmoCRM(string address, string login, string apiKey)
		{
            //Создаём запрос
            request.Resource = ;
            
		    //Заполняем входные данные запроса
			var addIn = new DTO.AmoCRM.Account.V1.AddIn
			{
				Login = login,
				Hash = apiKey,
				SubDomain = address
			};

			//Выполняем запрос
			var resultStatus = Execute(request, addIn);

			//Возвращаем результат
			return resultStatus;
		}

        private bool GetAmoCRMAccList(ref RestRequest request, out DTO.AmoCRM.Account.V1.ListOut listOut)
        {
            bool result = true;
            //Создаём запрос получения списка учётных записей AmoCRM
            request.Resource = AmoAccListStr;

            //Получаем список 
            listOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

            //Если список пустой
            if (listOut?.AmoCRMAccesses == null || listOut.AmoCRMAccesses.Count == 0)
            {
                //Выходим с ошибкой
                return false;
            }

            return result;
        }

        public bool CheckAmoCRMAccessAdded(string enigmaLogin, string enigmaPass)
        {
            // TODO: в этой точке разве может не быть аккаунта Энигмы? ...
            // ANSWER: Может не быть чего угодно! ^_^ Но вообще мы должны авторизоваться каждый раз, так что пока это должно быть тут
            var enigmaAccValid = AuthorizeEnigmaAcc(enigmaLogin, enigmaPass);
            if (!enigmaAccValid)
                return false;

            //Создаём запрос получения списка учётных записей AmoCRM
            request = new RestRequest { Resource = "API/AmoCRM/Account/V1/List" };

            //Получаем список 
            var listOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

            //Если список пустой
            if (listOut?.AmoCRMAccesses == null || listOut.AmoCRMAccesses.Count == 0)
            {
                //Выходим с ошибкой
                return false;
            }

            return true;
        }

        public bool DeleteAmoCRMAccounts(string enigmaLogin, string enigmaPass)
        {
            bool success;
            DTO.AmoCRM.Account.V1.ListOut accountsToDelete;
            success = GetAmoCRMAccList(ref request, out accountsToDelete);

            //Если список пустой
            if (!success) return false;

            //Выбираем список учётных записей
            var amoCrmAccesses = accountsToDelete?.AmoCRMAccesses;
            ////Если список пустой
            //if (amoCrmAccesses.IsNullOrEmpty())
            //{
            //    //Выходим с ошибкой
            //    success = false;
            //    return success;
            //}
            //var amoCrmAccessId = amoCrmAccesses.First().Id;

            // Создаем запрос на удаление
            request = new RestRequest { Resource = AmoAccDelStr };

            foreach (var item in amoCrmAccesses)
            {

                var deleteIn = new DTO.AmoCRM.Account.V1.DeleteIn
                {
                    AmoCRMAccountId = item.Id
                };

                //Удаляем данный аккаунт
                var getOut = Execute<DTO.AmoCRM.Account.V1.DeleteIn>(request, deleteIn);
            }

            return success;
        }
        #endregion AmoCRM

        #region CampaignsPanel
        public DTO.Marketing.Panel.V1.CampaignMarketingStatGetOut GetCampaignStatTest(out bool success) //, defaultStartDate, defaultEndDate
        {
            //Результат запросов
            var startDate = new DateTime(2016, 1, 1);
            var endDate = new DateTime(2016, 3, 31);

            //Создаём запрос получения списка учётных записей AmoCRM
            request = new RestRequest { Resource = "API/AmoCRM/Account/V1/List" };
            var listOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

            //Выбираем первую учётную запись
            var amoCrmAccesses = listOut?.AmoCRMAccesses;
            //Если список пустой
            if (amoCrmAccesses.IsNullOrEmpty())
            {
                //Выходим с ошибкой
                success = false;
                return null;
            }
            var amoCrmAccessId = amoCrmAccesses.First().Id;

            //Создаём запрос получения списка учётных записей Яндекса
            //request = new RestRequest { Resource = "API/Yandex/Account/V1/List" };

            // Пустой список
            DTO.Yandex.Account.V1.ListOut listOut2; //= Execute<DTO.Yandex.Account.V1.ListOut>(request, null);

            // Проверяем налчие Yandex аккаунта, получаем список аккаунтов
            bool result = GetYandexAccList(out request, out listOut2);

            // Список аккаунтов
            List<DTO.Yandex.Account.V1.ListOut.Access> yandexAccesses; // = listOut2?.YandexAccesses;
            ////Если список пустой
            //if (yandexAccesses.IsNullOrEmpty())
            //{
            //    //Выходим с ошибкой
            //    success = false;
            //    return null;
            //}

            if (result)
            {
                //Выбираем первую учётную запись
                yandexAccesses = listOut2?.YandexAccesses;
            }
            //Если список пустой
            else
            {
                success = false;
                return null;
            };

            var yandexAccessLogin = yandexAccesses.First().Login;

            //Создаём запрос получения данных панели продаж
            request = new RestRequest { Resource = "API/Marketing/Panel/V1/GetCampaignStat" };

            var marketingPanelGetIn = new DTO.Marketing.Panel.V1.MarketingPanelGetIn
            {
                YandexAccessLogin = yandexAccessLogin,
                AmoCRMAccessId = amoCrmAccessId,
                DateStart = startDate.ToUniversalTime(),
                DateEnd = endDate.ToUniversalTime()
            };

            //Получаем данные 
            var getOut = Execute<DTO.Marketing.Panel.V1.CampaignMarketingStatGetOut>(request, marketingPanelGetIn);

            success = getOut != null;

            return getOut;
        }

        # endregion CampaignsPanel

        #region PhrasesPanel
        public DTO.Marketing.Panel.V1.PhraseMarketingStatGetOut GetPhraseStatTest(string username, string password, out bool success) //, defaultStartDate, defaultEndDate
        {
            //Результат запросов
            var startDate = new DateTime(2016, 1, 1);
            var endDate = new DateTime(2016, 3, 31);

            AuthorizeEnigmaAcc(username, password);

            //Создаём запрос получения списка учётных записей AmoCRM
            request = new RestRequest {Resource = "API/AmoCRM/Account/V1/List"};
            var listOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

            //Выбираем первую учётную запись
            var amoCrmAccesses = listOut?.AmoCRMAccesses;
            //Если список пустой
            if (amoCrmAccesses.IsNullOrEmpty())
            {
                //Выходим с ошибкой
                success = false;
                return null;
            }
            var amoCrmAccessId = amoCrmAccesses.First().Id;

            //Создаём запрос получения списка учётных записей Яндекса
            //request = new RestRequest { Resource = "API/Yandex/Account/V1/List" };

            // Пустой список
            DTO.Yandex.Account.V1.ListOut listOut2; //= Execute<DTO.Yandex.Account.V1.ListOut>(request, null);

            // Проверяем налчие Yandex аккаунта, получаем список аккаунтов
            bool result = GetYandexAccList(out request, out listOut2);

            // Список аккаунтов
            List<DTO.Yandex.Account.V1.ListOut.Access> yandexAccesses; // = listOut2?.YandexAccesses;
            ////Если список пустой
            //if (yandexAccesses.IsNullOrEmpty())
            //{
            //    //Выходим с ошибкой
            //    success = false;
            //    return null;
            //}

            if (result)
            {
                //Выбираем первую учётную запись
                yandexAccesses = listOut2?.YandexAccesses;
            }
            //Если список пустой
            else
            {
                success = false;
                return null;
            };

            var yandexAccessLogin = yandexAccesses.First().Login;

            //Создаём запрос получения данных панели продаж
            request = new RestRequest {Resource = "API/Marketing/Panel/V1/GetPhraseStat"};

            var marketingPanelGetIn = new DTO.Marketing.Panel.V1.MarketingPanelGetIn
            {
                YandexAccessLogin = yandexAccessLogin,
                AmoCRMAccessId = amoCrmAccessId,
                DateStart = startDate.ToUniversalTime(),
                DateEnd = endDate.ToUniversalTime()
            };

            //Получаем данные 
            var getOut = Execute<DTO.Marketing.Panel.V1.PhraseMarketingStatGetOut>(request, marketingPanelGetIn);

            success = getOut != null;

            return getOut;
        }

        # endregion PhrasesPanel

        #region MarketPanel
        public DTO.Marketing.Panel.V1.MarketingPanelGetOut GetMarketPanelData(out bool success)
        {
            success = false;
            var defaultStartDate = new DateTime(2016, 1, 1);
            var defaultEndDate = new DateTime(2016, 3, 31);

            var result = GetMarketPanelData(out success, defaultStartDate, defaultEndDate);
            return result;
        }
        public DTO.Marketing.Panel.V1.MarketingPanelGetOut GetMarketPanelData
            (out bool success, DateTime startDate, DateTime endDate)
        {
            AuthorizeEnigmaAcc(CurrentUserName, CurrentPassword);

            //Создаём запрос получения списка учётных записей AmoCRM
            request = new RestRequest { Resource = "API/AmoCRM/Account/V1/List" };
            var listOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

            //Выбираем первую учётную запись
            var amoCrmAccesses = listOut?.AmoCRMAccesses;
            //Если список пустой
            if (amoCrmAccesses.IsNullOrEmpty())
            {
                //Выходим с ошибкой
                success = false;
                return null;
            }
            var amoCrmAccessId = amoCrmAccesses.First().Id;

            //Создаём запрос получения списка учётных записей Яндекса
            //request = new RestRequest { Resource = "API/Yandex/Account/V1/List" };
            //var listOut2 = Execute<DTO.Yandex.Account.V1.ListOut>(request, null);

            // Пустой список
            DTO.Yandex.Account.V1.ListOut listOut2;  //Execute<DTO.Yandex.Account.V1.ListOut>(request, null);

            // Проверяем налчие Yandex аккаунта, получаем список аккаунтов
            bool result = GetYandexAccList(out request, out listOut2);

            ////Выбираем первую учётную запись
            List<DTO.Yandex.Account.V1.ListOut.Access> yandexAccesses;  // = listOut2?.YandexAccesses;
            ////Если список пустой
            //if (yandexAccesses.IsNullOrEmpty())
            //{
            //    //Выходим с ошибкой
            //    success = false;
            //    return null;
            //}
            if (result)
            {
                //Выбираем первую учётную запись
                yandexAccesses = listOut2?.YandexAccesses;
            }
            //Если список пустой
            else
            {
                success = false;
                return null; 
            };
            var yandexAccessLogin = yandexAccesses.First().Login;

            //Создаём запрос получения данных панели маркетинга
            request = new RestRequest { Resource = "API/Marketing/Panel/V1/GetAllStat" };

            //Заполняем входные данные запроса
            var getIn = new DTO.Marketing.Panel.V1.MarketingPanelGetIn
            {
                YandexAccessLogin = yandexAccessLogin,
                AmoCRMAccessId = amoCrmAccessId,
                DateStart = startDate.ToUniversalTime(),
                DateEnd = endDate.ToUniversalTime()
            };

            //Получаем данные 
            var getOut = Execute<DTO.Marketing.Panel.V1.MarketingPanelGetOut>(request, getIn);

            success = true;
            return getOut;
        }
        #endregion MarketPanel

        #region SalesPanel
        public DTO.AmoCRM.SalesPanel.V1.GetOut GetSalesPanelData(out bool success)
		{
			success = false;
			var defaultStartDate = new DateTime(2016, 1, 1);
			var defaultEndDate = new DateTime(2016, 1, 31);

			var result = GetSalesPanelData(out success, defaultStartDate, defaultEndDate);
			return result;
		}

        public DTO.AmoCRM.SalesPanel.V1.GetOut GetSalesPanelData(out bool success,
			DateTime startDate, DateTime endDate)
		{

			//Результат запросов
			success = false;

			//Создаём запрос
			request = new RestRequest { Resource = "API/App/Account/V1/Authorize" };

			//Заполняем входные данные запроса
			var authorizeIn = new DTO.App.Account.V1.AuthorizeIn { Login = CurrentUserName, Password = CurrentPassword };

			//Выполняем запрос
			var resultStatus = Execute(request, authorizeIn);

			//Создаём запрос получения списка учётных записей AmoCRM
			request = new RestRequest {Resource = "API/AmoCRM/Account/V1/List"};

			//Получаем список 
			var listOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

			//Если список пустой
			if (listOut == null || listOut.AmoCRMAccesses.Count == 0)
			{
				//Выходим с ошибкой
				return null;
			}

			//Выбираем первую учётную запись
			var amoCRMAccountId = listOut.AmoCRMAccesses.First().Id;

			//Создаём запрос получения данных панели продаж
			request = new RestRequest {Resource = "API/AmoCRM/SalesPanel/V1/Get"};

			//Заполняем входные данные запроса
			var getIn = new DTO.AmoCRM.SalesPanel.V1.GetIn
			{
				AmoCRMAccessId = amoCRMAccountId,
				DateStart = startDate.ToUniversalTime(),
				DateEnd = endDate.ToUniversalTime()
			};

			//Получаем данные 
			var getOut = Execute<DTO.AmoCRM.SalesPanel.V1.GetOut>(request, getIn);

			success = true;
			return getOut;
		}

        //Тест получения данных о продажах
        //bool SalesPanelTest()
        //{
        //	//Результат запросов
        //	bool resultStatus;

        //	//Создаём запрос
        //	request = new RestRequest();
        //	request.Resource = "API/App/Account/V1/Authorize";

        //	//Заполняем входные данные запроса
        //	DTO.App.Account.V1.AuthorizeIn authorizeIn = new DTO.App.Account.V1.AuthorizeIn()
        //	{
        //		Login = "test@test.ru",
        //		Password = "testtest"
        //	};

        //	//Выполняем запрос
        //	resultStatus = Execute(request, authorizeIn);

        //	//Создаём запрос получения списка учётных записей AmoCRM
        //	request = new RestRequest();
        //	request.Resource = "API/AmoCRM/Account/V1/List";

        //	//Получаем список 
        //	DTO.AmoCRM.Account.V1.ListOut ListOut = Execute<DTO.AmoCRM.Account.V1.ListOut>(request, null);

        //	//Если список пустой
        //	if (ListOut == null || ListOut.AmoCRMAccesses.DefaultIfEmpty() == null)
        //	{
        //		//Выходим с ошибкой
        //		return false;
        //	}

        //	//Выбираем первую учётную запись
        //	Int64 amoCRMAccountId = ListOut.AmoCRMAccesses.First().Id;

        //	//Создаём запрос получения данных панели продаж
        //	request = new RestRequest();
        //	request.Resource = "API/AmoCRM/SalesPanel/V1/Get";

        //	//Заполняем входные данные запроса
        //	DTO.AmoCRM.SalesPanel.V1.GetIn getIn = new DTO.AmoCRM.SalesPanel.V1.GetIn()
        //	{
        //		AmoCRMAccessId = amoCRMAccountId,
        //		DateStart = new DateTime(2016, 1, 1).ToUniversalTime(),
        //		DateEnd = new DateTime(2016, 1, 31).ToUniversalTime()
        //	};

        //	//Получаем данные 
        //	DTO.AmoCRM.SalesPanel.V1.GetOut getOut = Execute<DTO.AmoCRM.SalesPanel.V1.GetOut>(request, getIn);

        //	//Если данных нет
        //	if (getOut == null)
        //	{
        //		//Выходим с ошибкой
        //		return false;
        //	}

        //	//Возвращаем результат
        //	return resultStatus;
        //}
        #endregion

        // Метод-обертка, когда не нужен статус запроса
        private bool Execute(RestRequest request, object dataIn)
		{
			HttpStatusCode statusCode = HttpStatusCode.Accepted;
			return Execute(request, dataIn, out statusCode);
		}

		//Метод отправки запроса без получения объекта
	    private bool Execute(RestRequest request, object dataIn, out HttpStatusCode statusCode)
		{
			//Заполняем параметры запроса
			request.Method = Method.POST;
			request.RequestFormat = DataFormat.Json;
			if (dataIn != null)
			{
				request.AddBody(dataIn);
			}

			var r = _client.Execute(request);
			if (r.StatusCode == HttpStatusCode.OK)
			{
				//if (r.ErrorException != null)
				//{
				//    const string message = "Error retrieving response.  Check inner details for more info.";
				//    var exception = new ApplicationException(message, r.ErrorException);
				//    throw exception;
				//}
				statusCode = r.StatusCode;
				if (_client.CookieContainer != null) СurrentCookieContainer = _client.CookieContainer;
				return true;
			}
			statusCode = r.StatusCode;
			// Пробуем еще раз
			if (r.StatusCode == HttpStatusCode.Unauthorized && (AuthorizeEnigmaAcc(CurrentUserName, CurrentPassword)))
			{
				if (_client.CookieContainer != null) СurrentCookieContainer = _client.CookieContainer;
				var r2 = _client.Execute(request);
			}
			return false;
		}

		//Метод получения объекта по API
	    private T Execute<T>(RestRequest request, object dataIn) where T : new()
		{
			request.Method = Method.POST;
			request.RequestFormat = DataFormat.Json;
			if (dataIn != null)
			{
				request.AddBody(dataIn);
			}

			var r = _client.Execute<T>(request);
			if (r.StatusCode != HttpStatusCode.OK) return default(T);   // TODO: Make saving CookieContainer before metod ends?

            if (_client.CookieContainer != null) СurrentCookieContainer = _client.CookieContainer;

            //Десериализуем объект
            var deserialized = JsonConvert.DeserializeObject<T>(r.Content);

			//Возвращаем объект
			return deserialized;
		}
	}
}
