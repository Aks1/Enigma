﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmptyMVC6.Services
{
    public interface IBackEndRequestService
    {
        void InitializeBackEndRequestService(string currentUserName = "test@test.ru",
                                             string currentPassword = "testtest",
                                             System.Net.CookieContainer cookieContainer = null);
        DTO.AmoCRM.SalesPanel.V1.GetOut GetSalesPanelData(out bool success);
        DTO.AmoCRM.SalesPanel.V1.GetOut GetSalesPanelData(out bool success, DateTime startDate, DateTime endDate);

        DTO.Marketing.Panel.V1.PhraseMarketingStatGetOut GetPhraseStatTest(string userName, string password, out bool success);
        DTO.Marketing.Panel.V1.CampaignMarketingStatGetOut GetCampaignStatTest(out bool success);

        DTO.Marketing.Panel.V1.MarketingPanelGetOut GetMarketPanelData(out bool success);
        DTO.Marketing.Panel.V1.MarketingPanelGetOut GetMarketPanelData(out bool success,
                                                                        DateTime startDate,
                                                                        DateTime endDate);
        bool RegisterEnigmaAcc(string login, string password);
        bool AuthorizeEnigmaAcc(string login, string password);
        
        bool CheckAmoCRMAccessAdded(string enigmaLogin, string enigmaPass);
        bool AddAccountAmoCRM(Models.AmoCRMReg amoCrmRegModel); 
        bool AddAccountAmoCRM(string address, string login, string apiKey);
        bool DeleteAmoCRMAccounts(string enigmaLogin, string enigmaPass);

        System.Net.CookieContainer СurrentCookieContainer { get; set; }

        bool DeleteYandexAccounts(string enigmaLogin, string enigmaPass);
        bool CheckYandexAccessAdded(string enigmaLogin, string enigmaPass);
        string AuthYandex(string code);
        bool AddYandexAccess(string yandexToken);
    }
}
