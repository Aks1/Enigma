﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EmptyMVC6.ViewModels;
using System.Text;
using Newtonsoft.Json.Linq;

using RestSharp;
using RestSharp.Authenticators;
using EmptyMVC6.Models;

namespace EmptyMVC6.Services
{
    public class UserAuthService //: IUserAuthService
    {
        public UserAuthService()
        {

        }
    }
}
