﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using EmptyMVC6.ViewModels;
using DTO.AmoCRM.SalesPanel.V1;
using MarketingMainPanel = EmptyMVC6.ViewModels.MarketingMainPanel;
using Marketing = EmptyMVC6.ViewModels.Marketing;


namespace EmptyMVC6.Services
{
	public interface ITestService
	{
		DTO.AmoCRM.SalesPanel.V1.GetOut GetSalesPanelData(out bool success);
	}

	public class TestService : ITestService
	{
		private readonly Random _rand = new Random();

		private Dictionary<string, ManagerStats> _manageDict;

		private readonly double[] _cv = { 0.1f, 0.2f, 0.3f, 0.4f };
		private readonly decimal[] _salesFactual = { 573000, 259000, 190000, 124000 };
		private readonly decimal[] _salesPlan = { 830000, 310000, 300000, 220000 };
		private readonly double[] _planByFactual = { 69, 84, 63, 56 };
		private readonly double[] _cpo = { 3450, 3950, 2900, 3500 };
		private readonly decimal[] _averageDealPrice = { 11460, 12950, 10555.56M, 10333.33M };

		private readonly GetOut _salesPanelData = new GetOut();

		public TestService()
		{
			visits_plan = new int[] { 10000, 10000, 3000, 1000, 6000, 0, 0 };
			visits_fact = new int[] { 13780, 3782, 1965, 7959, 0, 74 };
			cv_req_plan = new double[] { 10, 10, 10, 1, 11.50, 0, 0 };
			cv_req_fact = new double[] { 17.02, 17.02, 10.44, 4.33, 23.43, 0, 0 };
			requests_plan = new int[] { 1000, 1000, 300, 10, 690, 0, 0 };
			requests_fact = new int[] { 2345, 2345, 395, 85, 1865, 0, 0 };
			cv_sales_plan = new double[] { 50.0, 50.00, 66.67, 10.00, 43.33, 0, 0 };
			cv_sales_fact = new double[] { 40.30, 40.30, 82.53, 82.35, 29.44, 0, 0 };
			sales_plan = new int[] { 500, 500, 200, 1, 299, 0, 0 };
			sales_fact = new int[] { 945, 945, 326, 70, 549, 0, 0 };
			cash_plan = new double[] { 750000, 750000, 300000, 1500, 448500, 0, 0 };
			cash_fact = new double[] { 1393720, 1393720, 589000, 81568, 723152, 0, 0 };
			profit_plan = new double[] { 500000, 500000, 200000, 1000, 299000, 0, 0 };
			profit_fact = new double[] { 871322, 871322, 356278, 26042, 489002, 0, 0 };
			averageDealPrice_plan = new double[] { 1500, 1500, 1500, 1500, 1500, 1500, 1500 };
			averageDealPrice_fact = new double[] { 1474.84, 1474.84, 1806.75, 1165.26, 1317.22, 0, 0 };
			charge_plan = new double[] { 250000, 250000, 90000, 3000, 157000, 0, 0 };
			charge_fact = new double[] { 424739, 424739, 97560, 300, 326879, 0, 0 };
			romi_plan = new double[] { 200, 200, 222, 33, 190, 0, 0 };
			romi_fact = new double[] { 205, 205, 365, 8681, 150, 0, 0 };
		}
		public TestService(string test = "test_for_debug")
		{
			visits_plan = new int[] { 10000, 10000, 3000, 1000, 6000, 0, 0 };
			visits_fact = new int[] { 13780, 3782, 1965, 7959, 0, 74 };
			cv_req_plan = new double[] { 10, 10, 10, 1, 11.50, 0, 0 };
			cv_req_fact = new double[] { 17.02, 17.02, 10.44, 4.33, 23.43, 0, 0 };
			requests_plan = new int[] { 1000, 1000, 300, 10, 690, 0, 0 };
			requests_fact = new int[] { 2345, 2345, 395, 85, 1865, 0, 0 };
			cv_sales_plan = new double[] { 50.0, 50.00, 66.67, 10.00, 43.33, 0, 0 };
			cv_sales_fact = new double[] { 40.30, 40.30, 82.53, 82.35, 29.44, 0, 0 };
			sales_plan = new int[] { 500, 500, 200, 1, 299, 0, 0 };
			sales_fact = new int[] { 945, 945, 326, 70, 549, 0, 0 };
			cash_plan = new double[] { 750000, 750000, 300000, 1500, 448500, 0, 0 };
			cash_fact = new double[] { 1393720, 1393720, 589000, 81568, 723152, 0, 0 };
			profit_plan = new double[] { 500000, 500000, 200000, 1000, 299000, 0, 0 };
			profit_fact = new double[] { 871322, 871322, 356278, 26042, 489002, 0, 0 };
			averageDealPrice_plan = new double[] { 1500, 1500, 1500, 1500, 1500, 1500, 1500 };
			averageDealPrice_fact = new double[] { 1474.84, 1474.84, 1806.75, 1165.26, 1317.22, 0, 0 };
			charge_plan = new double[] { 250000, 250000, 90000, 3000, 157000, 0, 0 };
			charge_fact = new double[] { 424739, 424739, 97560, 300, 326879, 0, 0 };
			romi_plan = new double[] { 200, 200, 222, 33, 190, 0, 0 };
			romi_fact = new double[] { 205, 205, 365, 8681, 150, 0, 0 };
		}
		public GetOut GetSalesPanelData(out bool result)
		{
			result = true;
             _manageDict = new Dictionary<string, ManagerStats>();
            _salesPanelData.Statuses = new List<string>
				{"Первичный контакт", "Отправил договор", "Успешно реализовано", "Закрыто и не реализовано"};
			_salesPanelData.Managers = new List<string>
				{"Иванов Иван", "Петр Петров", "Сергей Сидоров", "Иннокентий Шниперсон"};

			_salesPanelData.CVByStatusList = new List<StatusConversion>
			{
				new StatusConversion {First = "Первичный контакт", Second = "Отправил договор", Convertion = 0.5f},
				new StatusConversion {First = "Первичный контакт", Second = "Успешно реализован", Convertion = 0.3f},
				new StatusConversion {First = "Отправил договор", Second = "Успешно реализован", Convertion = 0.7f}
			};

			for (int i = 0; i < 4; i++)
			{
				var manStat = new ManagerStats
				{
					SalesByStatus = new Dictionary<string, DealsSummary>
					{
						{_salesPanelData.Statuses[0], NewRandomDeal() },
						{_salesPanelData.Statuses[1], NewRandomDeal() },
						{_salesPanelData.Statuses[2], NewRandomDeal() },
                        {_salesPanelData.Statuses[3], NewRandomDeal() }
                    },
					CVFirstToLast = _cv[i],
					SalesFactual = _salesFactual[i],
					SalesPlan = _salesPlan[i],
					PlanByFactual = _planByFactual[i],
					CPO = _cpo[i],
					AverageDealPrice = _averageDealPrice[i]
				};

				_manageDict.Add(_salesPanelData.Managers[i], manStat);
			}
			_salesPanelData.ManagerStatsDict = _manageDict;

			return _salesPanelData;
		}

		private DealsSummary NewRandomDeal()
		{
			return new DealsSummary
			{
				Quantity = _rand.Next(10, 200),
				Value = _rand.Next(10, 200)
			};
		}



		//public SalesPanelViewModel CreateDummy()
		//{
		//    SalesPanelViewModel dummy = new SalesPanelViewModel();
		//    dummy.Managers = new List<string>() { "Итого", "Jo", "Ja" };
		//    dummy.Statuses = new List<string>() { "Первичный контакт", "Отправил договор", "Успешно реализован" };

		//    List<ManagerStats> managerStats = new List<ManagerStats>();
		//    for (int i = 0; i < 3; i++)
		//    {
		//        DealsSum deal = new DealsSum();
		//        deal.Quantity = rand.Next(10, 200);
		//        deal.Currency = rand.Next(10, 200);
		//        DealsSum deal2 = new DealsSum();
		//        deal2.Quantity = rand.Next(10, 200);
		//        deal2.Currency = rand.Next(10, 200);
		//        DealsSum deal3 = new DealsSum();
		//        deal3.Quantity = rand.Next(10, 200);
		//        deal3.Currency = rand.Next(10, 200);

		//        ManagerStats manStat = new ManagerStats();
		//        manStat.CVFirstToLast = i + rand.Next(10, 20);
		//        manStat.FactualByPlan = i + rand.Next(10, 20);
		//        manStat.SalesFactual = i + rand.Next(10, 20);
		//        manStat.SalesPlan = i + rand.Next(10, 20);

		//        manStat.SalesByStatus = new Dictionary<string, DealsSum>();
		//        manStat.SalesByStatus.Add(dummy.Statuses[0], deal);
		//        manStat.SalesByStatus.Add(dummy.Statuses[1], deal2);
		//        manStat.SalesByStatus.Add(dummy.Statuses[2], deal3);

		//        managerStats.Add(manStat);
		//    }

		//    dummy.ManagerStatsDict = new Dictionary<string, ManagerStats>();
		//    dummy.ManagerStatsDict.Add(dummy.Managers[0], managerStats[0]);
		//    dummy.ManagerStatsDict.Add(dummy.Managers[1], managerStats[1]);
		//    dummy.ManagerStatsDict.Add(dummy.Managers[2], managerStats[2]);
		//    return dummy;
		//}


		// MARKETING
		MarketingMainPanel marketingMainPanel = new MarketingMainPanel();
		List<Marketing> marketing = new List<Marketing>();

		private int[] visits_plan;
		private int[] visits_fact;
		private double[] cv_req_plan;
		private double[] cv_req_fact;
		private int[] requests_plan;
		private int[] requests_fact;
		private double[] cv_sales_plan;
		private double[] cv_sales_fact;
		private int[] sales_plan;
		private int[] sales_fact;
		private double[] cash_plan;
		private double[] cash_fact;
		private double[] profit_plan;
		private double[] profit_fact;
		private double[] averageDealPrice_plan;
		private double[] averageDealPrice_fact;
		private double[] charge_plan;
		private double[] charge_fact;
		private double[] romi_plan;
		private double[] romi_fact;

		public MarketingMainPanel GetMarketingInf()
		{
			for (int i = 0; i < 7; i++)
			{
				Marketing mark = new Marketing();

				mark.Clicks.Plan = visits_plan[i];
				mark.Clicks.Fact = visits_fact[i];
				mark.CvRequests.Plan = cv_req_plan[i];
				mark.CvRequests.Fact = cv_req_fact[i];
				mark.Requests.Plan = requests_plan[i];
				mark.Requests.Fact = requests_fact[i];
				mark.CvSales.Plan = cv_sales_plan[i];
				mark.CvSales.Fact = cv_sales_fact[i];
				mark.Sales.Plan = sales_plan[i];
				mark.Sales.Fact = sales_fact[i];
				mark.CashFlow.Plan = cash_plan[i];
				mark.CashFlow.Fact = cash_fact[i];
				mark.Profit.Plan = profit_plan[i];
				mark.Profit.Fact = profit_fact[i];
				mark.AverageDealPrice.Plan = averageDealPrice_plan[i];
				mark.AverageDealPrice.Fact = averageDealPrice_fact[i];
				mark.Charge.Plan = charge_plan[i];
				mark.Charge.Fact = charge_fact[i];
				mark.ROMI.Plan = romi_plan[i];
				mark.ROMI.Fact = romi_fact[i];

				marketing.Add(mark);
			}

			marketingMainPanel.All = marketing[0];
			marketingMainPanel.InternetTraffic = marketing[1];
			marketingMainPanel.Context = marketing[2];
			marketingMainPanel.Search = marketing[3];
			marketingMainPanel.SocialNetworks = marketing[4];
			marketingMainPanel.Email = marketing[5];
			marketingMainPanel.Other = marketing[6];

			return marketingMainPanel;
		}


	}
}
