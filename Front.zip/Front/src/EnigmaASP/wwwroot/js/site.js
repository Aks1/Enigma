﻿//$(function () {
//    //moment.locale('ru');
//    function cb(start, end) {
//        $('#reportrange span').html(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
//    }
//    cb(moment().subtract(29, 'days'), moment());
//    $('#reportrange').daterangepicker({
//        "locale": {
//            "format": "DD/MM/YYYY",
//            "separator": " - ",
//            "applyLabel": "Применить",
//            "cancelLabel": "Отмена",
//            "fromLabel": "От",
//            "toLabel": "До",
//            "customRangeLabel": "Выбор",
//            "daysOfWeek": [
//                "Вс",
//                "Пн",
//                "Вт",
//                "Ср",
//                "Чт",
//                "Пт",
//                "Сб"
//            ],
//            "monthNames": [
//                "Январь",
//                "Февраль",
//                "Март",
//                "Апрель",
//                "Май",
//                "Июнь",
//                "Июль",
//                "Август",
//                "Сентябрь",
//                "Октябрь",
//                "Ноябрь",
//                "Декабрь"
//            ],
//            "firstDay": 1,
//            "weekLabel": "kd"
//        }//,
//        //ranges: {
//        //    'Today': [moment(), moment()],
//        //    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
//        //    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
//        //    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
//        //    'This Month': [moment().startOf('month'), moment().endOf('month')],
//        //    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
//        //}
//    }, cb);
//});