﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
namespace DTO.Yandex.Account.V1
{

    public class ListOut
    {

        public List<Access> YandexAccesses { get; set; }

        public class Access
        {

            public long Id { get; set; }

            public string Login { get; set; }

            public string Token { get; set; }
        }
    }
}
