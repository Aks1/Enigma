﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

namespace DTO.Yandex.Account.V1
{

    public class AddIn
    {

        public string Login { get; set; }

        public string Token { get; set; }
    }
}
