﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO.Marketing.Panel.V1
{
    public class MarketingPanelGetOut
    {
        public MarketingChanelStatistics 
                                    Yandex,         
                                    YandexContext,  
                                    YandexSearch;   

        public DateTime MonthOfPlan;
    }

    public class PhraseMarketingStatGetOut
    {
        public List<PhraseMarketingStatistics> StatList;
    }

    public class CampaignMarketingStatGetOut
    {
        public List<CampaignMarketingStatistics> StatList;
    }

    public struct PhraseMarketingStatistics : IHaveLeadSourceMarketingStatistics
    {
        public LeadSourceMarketingStatistics Stat { get; set; }
        public string Name;
    }

    public struct CampaignMarketingStatistics : IHaveLeadSourceMarketingStatistics
    {
        public LeadSourceMarketingStatistics Stat { get; set; }
        public string Name;
    }

    public interface IHaveLeadSourceMarketingStatistics
    {
        LeadSourceMarketingStatistics Stat { get; set; }
    }
    
    public struct LeadSourceMarketingStatistics
    {
        public int Shows;                 
        public double CvVisits;           
        public int Clicks;                
        public double CvRequests;         
        public int Requests;              
        public double CvSales;            
        public int Sales;                 
        public decimal Revenue;           
        public double AverageDealPrice;   
        public double Costs;              
        public double Marge;              
        public double Profit;             
        public double ROMI;               
    }

    public struct MarketingChanelStatistics
    {
        public PlanFact<int> Shows;                 
        public PlanFact<double> CvVisits;           
        public PlanFact<int> Clicks;                
        public PlanFact<double> CvRequests;         
        public PlanFact<int> Requests;              
        public PlanFact<double> CvSales;            
        public PlanFact<int> Sales;                 
        public PlanFact<decimal> Revenue;           
        public PlanFact<double> AverageDealPrice;   
        public PlanFact<double> Costs;              
        public PlanFact<double> Marge;              
        public PlanFact<double> Profit;             
        public PlanFact<double> ROMI;               
    }

    public struct PlanFact<T> where T:struct
    {
        public T Plan;
        public T Fact;
    }  
}
