﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DTO.AmoCRM.LeadStatus.V1
{

    public class ListIn
    {

        public Int64 AmoCRMAccessId { get; set; }
    }
}
