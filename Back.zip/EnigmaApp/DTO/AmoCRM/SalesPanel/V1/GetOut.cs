﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DTO.AmoCRM.SalesPanel.V1
{

    public class GetOut
    {

        public List<string> Statuses { get; set; }
        
        public List<string> Managers { get; set; }

        public Dictionary<string, ManagerStats> ManagerStatsDict { get; set; }

        public List<StatusConversion> CVByStatusList { get; set; }
    }
    
    public struct DealsSummary
    {
        
        public int Quantity;
        
        public decimal Value; 
    }
    
    public struct StatusConversion
    {
        
        public string First;
        
        public string Second;
        
        public double Convertion;
    }

    public struct ManagerStats
    {

        public Dictionary<string, DealsSummary> SalesByStatus;

        public double CVFirstToLast;

        public decimal SalesFactual; 

        public decimal SalesPlan; 
        
        public double PlanByFactual; 
        
        public double CPO;

        public decimal AverageDealPrice;
    }
}
