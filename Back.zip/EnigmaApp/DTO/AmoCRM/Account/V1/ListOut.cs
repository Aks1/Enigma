﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DTO.AmoCRM.Account.V1
{

    public class ListOut
    {

        public List<Access> AmoCRMAccesses { get; set; }

        public class Access
        {

            public Int64 Id { get; set; }

            public string Login { get; set; }

            public string Hash { get; set; }

            public string SubDomain { get; set; }

            public string TimeZone { get; set; }
        }
    }
}
