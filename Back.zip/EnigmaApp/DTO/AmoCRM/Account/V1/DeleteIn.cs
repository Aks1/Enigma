﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

namespace DTO.AmoCRM.Account.V1
{

    public class DeleteIn
    {

        public long AmoCRMAccountId { get; set; }
    }
}
