﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>
/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

namespace DTO.AmoCRM.Account.V1
{

    public class AddIn
    {

        public string Login { get; set; }

        public string SubDomain { get; set; }

        public string Hash { get; set; }
    }
}
