﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DTO.App.Account.V1
{

    public class AuthorizeIn
    {

        public string Login { get; set; }

        public string Password { get; set; }
    }
}
