﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using EnigmaApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnigmaApp.Model.Entities.App;
namespace CalculateSignificativesWebJob
{
    class Program
    {
        
        static DateTime _internalLastTime;
        
        static Context _context = null;
        static void Main(string[] args)
        {
            return;
            
            Context.SetConnectionStringName("EnigmaAzureConnection");
            
            using (_context = new Context())
            {
                
                UpdateFromAmoCRM fromAmoCRM = new UpdateFromAmoCRM(_context);
                
                foreach (Account currentAccount in _context.AllAccounts)
                {
                    
                    fromAmoCRM.Update(currentAccount);
                }
            }
        }
    }
}
