﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>
using EnigmaApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnigmaApp.Model.Entities.AmoCRM;
using EnigmaApp.Model.Entities.App;
using Account = EnigmaApp.Model.Entities.App.Account;
namespace CalculateSignificativesWebJob
{

    public class UpdateFromAmoCRM
    {
        
        static DateTime _internalLastTime;
        
        static Context _context = null;

        public UpdateFromAmoCRM(Context context)
        {
            
            _context = context;
        }

        public void Update(Account account)
        {
            
            foreach (AmoCRMAccess currentAmoCRMAccess in account.AmoCRMAccesses)
            {
                
                if (currentAmoCRMAccess.AmoCRMAccount == null)
                {
                    
                    continue;
                }
                
                _internalLastTime = currentAmoCRMAccess.InternalLastModifiedTime;

                currentAmoCRMAccess.InternalLastModifiedTime = _internalLastTime;
                
                _context.Save();
            }
        }

        void UpdateDealStatus(Deal internalDeal, Lead externalDeal)
        {

        }
        void CreateDealStatusTransitions(LeadStatus startState, LeadStatus endState)
        {
        }

        void UpdateInternalLastTime(DateTime internalTime)
        {
            
            if (internalTime > _internalLastTime)
            {
                
                _internalLastTime = internalTime;
            }
        }
    }
}
