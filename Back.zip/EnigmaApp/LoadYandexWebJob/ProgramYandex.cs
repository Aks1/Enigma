﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;

using Newtonsoft.Json;
using RestSharp;

using EnigmaApp.Model;
using EnigmaApp.Model.Entities.Yandex;
using Telerik.OpenAccess;
using YandexAccess = EnigmaApp.Model.Entities.App.YandexAccess;
using YandexAccount = EnigmaApp.Model.Entities.Yandex.Account;

namespace EnigmaApp.LoadYandexWebJob
{
    internal class ProgramYandex
    {
        private static readonly Uri YandexApiUri = new Uri(@"https://api.direct.yandex.ru/live/v4/json/");
        private const string GetCampaignsMethodName = "GetCampaignsList";
        private const string GetBannersMethodName = "GetBanners";
        private const string GetBannersStatMethodName = "GetBannersStat";
        private const string GetClientInfoMethodName = "GetClientInfo";

        private static RestClient _client;
        
        private static Context _context;

        private static DateTime _externalLastTime;
        
        private static YandexAccount _currentYandAccount;
        
        private static YandexAccess _currentYandAccess;

        #region Только во время разработки. Тестовые методы для создания YandexAccess на test аккаунте Энигмы

#if DEBUG
        private const string TestToken = "e5a9578638b54909adcf73ef66587341";

        [Conditional("DEBUG")]
        private static void AddAccount()
        {
            var dataIn = new {Login = "alfatest.fr", Token = TestToken};
            var dbContext = _context;

            long accountId = 1;

            var yandexAccess = dbContext.AllYandexAccesses
                .SingleOrDefault(o => (o.AccountId == accountId)
                                      && (o.Login == dataIn.Login) && (!o.IsDeleted));
            if (yandexAccess != null)
                return; 

            var newYandexAccess = dbContext.Create<YandexAccess>();
            
            newYandexAccess.Login = dataIn.Login;
            newYandexAccess.AccountId = accountId;
            newYandexAccess.Token = dataIn.Token;

            dbContext.Save();

        }

        [Conditional("DEBUG")]
        private static void Main3()
        {
            
            Context.SetConnectionStringName("EnigmaAzureConnection");

            using (_context = new Context())
            {
                AddAccount();
            }
        }

        [Conditional("DEBUG")]
        private static void Main2()
        {
            
            _client = new RestClient { BaseUrl = YandexApiUri };
            var token = TestToken;

            var getCampaignsRequestBody = new GetCampaignsRequestRoot
            {
                token = token,
                method = GetCampaignsMethodName
            };

            var result1 = Execute<GetCampaignRoot>(getCampaignsRequestBody);

            var getBannersRequestBody = new GetBannersRequestRoot
            {
                token = token,
                method = GetBannersMethodName,
                param = new GetBannersParam
                {
                    CampaignIDS = new List<long> {result1.data.First().Id},
                    GetPhrases = "No",
                    Currency = null,
                    FieldsNames = new List<string>
                    {
                        "CampaignID",
                        "AdGroupID",
                        "AdGroupName",
                        "BannerID",
                        "Title"
                    }
                }
            };

            var result2 = Execute<GetBannersRoot>(getBannersRequestBody);

            var getBannersStatRequestBody = new GetBannersStatRequestRoot
            {
                token = token,
                method = GetBannersStatMethodName,
                param = new GetBannersStatParam
                {
                    CampaignID = 14586839,
                    StartDate = "2015-10-06",
                    EndDate = "2015-10-12",
                    GroupByColumns = new List<string> { "clDate", "clPhrase" },
                    OrderBy = new List<string> { "clBanner", "clPhrase", "clDate" },
                    Currency = null,
                    IncludeVAT = "Yes",
                    IncludeDiscount = "Yes"
                }
            };

            var result3 = Execute<GetBannersStatRoot>(getBannersStatRequestBody);
        }
#endif
        #endregion

        private static void Main()
        {
            Context.SetConnectionStringName("EnigmaAzureConnection");

            using (_context = new Context())
            {

                foreach (var yandexAccess in _context.AllYandexAccesses
                                                    .Where(o => !o.IsDeleted && o.AccountId==19)
                                                    .OrderByDescending(o => o.YandexAccountId))
                {
                    
                    _client = new RestClient
                    {
                        BaseUrl = YandexApiUri,
                        CookieContainer = new CookieContainer()
                    };

                    _currentYandAccess = yandexAccess;

                    if (!CheckTokenValid(_currentYandAccess.Token))
                    {

                        continue;
                    }

                    if (!ProcessAccount(_currentYandAccess))
                    {
                        
                        continue;
                    }

                    var campaignIds = ProcessCampaigns(_currentYandAccess);

                    var accountCampaigns = _currentYandAccess.YandexAccount.Campaings;

                    var ids = campaignIds as long[] ?? campaignIds.ToArray();
                    Debug.Assert((accountCampaigns.Count == ids.Count()) &&
                        !accountCampaigns.Select(camp => camp.Id).Except(ids).Any());

                    var accountCampaigns2 = accountCampaigns.ToList();

                    ProcessBannersAndBannerGroups(accountCampaigns2, _currentYandAccess);

                    ProcessBannerPhraseStats(accountCampaigns2, _currentYandAccess);

                }
            }
        }

        #region Проверка токена и обновление аккаунта (через GetClientInfo)

        private static bool CheckTokenValid(string token)
        {
            var request = new RestRequest();
            var bodyCheck = new GetCampaignsRequestRoot
            {
                token = token,
                method = GetCampaignsMethodName
            };

            var resultStatus = Execute(request, bodyCheck);

            return resultStatus;
        }

        private static bool ProcessAccount(YandexAccess yandexAccess)
        {
            var getClientInfoRequestBody = new GetClientInfoRequestRoot
            {
                token = yandexAccess.Token,
                method = GetClientInfoMethodName
            };

            var responseBody = Execute<GetClientInfoRoot>(getClientInfoRequestBody);
            if (responseBody?.data == null || responseBody.data.Count != 1)
            {

                return false;
            }

            var loadedRestAccount = responseBody.data[0];

            YandexAccount currentAccount;
            
            if (yandexAccess.YandexAccount != null)
                currentAccount = yandexAccess.YandexAccount;
            else 
            {

                currentAccount = _context.AllYandexAccounts
                    .SingleOrDefault(acc => acc.Login == loadedRestAccount.Login);
                if (currentAccount == null) 
                {
                    currentAccount = _context.Create<YandexAccount>();
                    currentAccount.Login = loadedRestAccount.Login;
                }

                yandexAccess.YandexAccount = currentAccount;

                _context.Save();
            }

            UpdateYandexAccount(currentAccount, loadedRestAccount);

            return true;
        }

        private static void UpdateYandexAccount(YandexAccount dbAccount, GetClientInfoData loadedRestAccount)
        {

            dbAccount.Login = loadedRestAccount.Login;

            _context.Save();

        }

        #endregion

        #region Обновление кампаний

        private static IEnumerable<long> ProcessCampaigns(YandexAccess yandexAccess)
        {
            var getCampaignsRequestBody = new GetCampaignsRequestRoot
            {
                token = yandexAccess.Token,
                method = GetCampaignsMethodName
            };

            var responseBody = Execute<GetCampaignRoot>(getCampaignsRequestBody);
            if (responseBody?.data == null || responseBody.data.Count == 0)
            {

                return null;
            }

            var loadedCampaigns = responseBody.data;

            UpdateCampaigns(loadedCampaigns, yandexAccess.YandexAccount);

            var campaignIds = loadedCampaigns.Select(campaign => campaign.Id);
            return campaignIds;
        }

        private static void UpdateCampaigns(List<Campaing> loadedCampaigns, YandexAccount yandAccount)
        {
            var dbCampaigns = _context.AllDirectCampaings;
            
            var campaignFromDBIds = dbCampaigns.Select(campaign => campaign.Id);

            var lookUpChangedUnchangedCompanies = loadedCampaigns
                .ToLookup(company => campaignFromDBIds.Contains(company.Id));

            var changedRestCampaigns = lookUpChangedUnchangedCompanies[true];
            var newCampaigns = lookUpChangedUnchangedCompanies[false];

            var changedCampaigns = changedRestCampaigns.Join(
                dbCampaigns,
                loadedCampaign => loadedCampaign.Id,
                dbCampaign => dbCampaign.Id,
                (loadedCampaign, dbCampaign) => new { loadedCampaign, dbCampaign });

            foreach (var changedCampaign in changedCampaigns)
            {
                var dbCampaign = changedCampaign.dbCampaign;
                var loadedCampaign = changedCampaign.loadedCampaign;

                dbCampaign.Name = loadedCampaign.Name;
                dbCampaign.StartDate = loadedCampaign.StartDate;

                _context.Save();
            }

            foreach (var newCampaign in newCampaigns)
            {

                var newCampaignInBd = _context.Create<Campaing>();
                newCampaignInBd.Account = yandAccount;
                newCampaignInBd.Id = newCampaign.Id;
                newCampaignInBd.StartDate = newCampaign.StartDate;
                newCampaignInBd.Login = newCampaign.Login;
                newCampaignInBd.Name = newCampaign.Name;

                _context.Save();
            }
        }

        #endregion

        #region Обновление баннеров и групп баннеров

        private static void ProcessBannersAndBannerGroups(IList<Campaing> accountCampaigns,
                                                          YandexAccess yandexAccess)
        {
            
            var getBannersRequestBody = new GetBannersRequestRoot
            {
                token = yandexAccess.Token,
                method = GetBannersMethodName,
                param = new GetBannersParam
                {
                    CampaignIDS = null,
                    GetPhrases = "No",
                    Currency = null,
                    FieldsNames = new List<string>
                        {
                            "CampaignID",
                            "AdGroupID",
                            "AdGroupName",
                            "BannerID",
                            "Title"
                        }
                }
            };

            foreach (var campaign in accountCampaigns)
            {
                
                getBannersRequestBody.param.CampaignIDS = new List<long> { campaign.Id };

                var responseBody = Execute<GetBannersRoot>(getBannersRequestBody);
                if (responseBody?.data == null || responseBody.data.Count == 0)
                {

                    continue;
                }

                var loadedBanners = responseBody.data;

                UpdateBannersAndBannerGroups(loadedBanners, campaign);
            }
        }

        private static void UpdateBannersAndBannerGroups(List<GetBannersResponseElement> loadedElements,
                                                         Campaing motherDbCampaign)
        {

            var allDbBannerGroups = _context.AllDirectBannerGroups.ToDictionary(bannerG => bannerG.Id);

            foreach (var loadedElementsByAdGroup in loadedElements.GroupBy(el => el.AdGroupID))
            {
                var adGroupId = loadedElementsByAdGroup.Key;
                var adGroupName = loadedElementsByAdGroup.ElementAt(0).AdGroupName;

                BannerGroup bannerGroup;

                if (!allDbBannerGroups.TryGetValue(adGroupId, out bannerGroup))
                {
                    bannerGroup = _context.Create<BannerGroup>();
                    bannerGroup.Id = adGroupId;
                    bannerGroup.Campaing = motherDbCampaign;
                }
                
                bannerGroup.Name = adGroupName;
                _context.Save();

                UpdateBanners(loadedElementsByAdGroup, bannerGroup);

                _context.Save();
            }
        }

        private static void UpdateBanners(IEnumerable<GetBannersResponseElement> loadedElements,
                                          BannerGroup motherDbBannerGroup)
        {
            var dbBanners = motherDbBannerGroup.Banners;
            
            var bannerFromDBIds = dbBanners.Select(banner => banner.Id);

            var lookUpChangedUnchangedCompanies = loadedElements
                .ToLookup(el => bannerFromDBIds.Contains(el.BannerID));

            var changedRestBanners = lookUpChangedUnchangedCompanies[true];
            var newBanners = lookUpChangedUnchangedCompanies[false];

            var changedBanners = changedRestBanners.Join(
                dbBanners,
                loadedBanner => loadedBanner.BannerID,
                dbBanner => dbBanner.Id,
                (loadedBanner, dbBanner) => new {loadedBanner, dbBanner});

            foreach (var changedBanner in changedBanners)
            {
                var dbBanner = changedBanner.dbBanner;
                var loadedBanner = changedBanner.loadedBanner;

                dbBanner.Title = loadedBanner.Title;

            }

            foreach (var newBannerEl in newBanners)
            {

                var newBanner = _context.Create<Banner>();
                newBanner.Id = newBannerEl.BannerID;
                newBanner.Title = newBannerEl.Title;
                newBanner.BannerGroup = motherDbBannerGroup;

            }
        }

        #endregion

        #region Загрузка и сохранение в БД статистики по паре Баннер-Фраза

        private static void ProcessBannerPhraseStats(IEnumerable<Campaing> campaigns, YandexAccess yandexAccess)
        {
            var getBannersStatRequestBody = new GetBannersStatRequestRoot
            {
                token = yandexAccess.Token,
                method = GetBannersStatMethodName,
                param = new GetBannersStatParam
                {
                    CampaignID = 0, 
                    StartDate = "", 
                    EndDate = "", 
                    GroupByColumns = new List<string> {"clDate", "clPhrase"},
                    OrderBy = new List<string> {"clBanner", "clPhrase", "clDate"},
                    Currency = null, 
                    IncludeVAT = "Yes",
                    IncludeDiscount = "Yes"
                }
            };

            foreach (var campaign in campaigns)
            {
                getBannersStatRequestBody.param.CampaignID = (int) campaign.Id;

                DateTime last = DateTime.Today.Date.AddDays(-1);

                var allPeriodStartDate = last < campaign.StartDate.Date
                                            ? campaign.StartDate.Date
                                            : last;
                
                var today = DateTime.Now.Date;
                var daysToLoad = (today - allPeriodStartDate).Days;

                var loadedBannerStat = new List<GetBannersStatElement>();

                for (int dayBegin = 0; dayBegin < daysToLoad; dayBegin += 7)
                {
                    var requestPeriodBeginDate = allPeriodStartDate.AddDays(dayBegin);
                    
                    var requestPeriodEndDate = (dayBegin+6) < daysToLoad
                        ? requestPeriodBeginDate.AddDays(6)
                        : today.AddDays(-1);

                    getBannersStatRequestBody.param.StartDate = requestPeriodBeginDate.ToString("yyyy-MM-dd");
                    getBannersStatRequestBody.param.EndDate = requestPeriodEndDate.ToString("yyyy-MM-dd");

                    var responseBody = Execute<GetBannersStatRoot>(getBannersStatRequestBody);
                    if (responseBody?.data == null)
                    {
                        
                        continue;
                    }

                    loadedBannerStat.AddRange(responseBody.data.Stat);
                }

                var elementsGroupedByAdId = campaign.BannerGroups.SelectMany(bannerG => bannerG.Banners)
                    .GroupJoin(loadedBannerStat,
                        banner => banner.Id,
                        el => el.BannerID,
                        (banner, el) => new {banner.BannerGroup, el})
                     
                     .ToList();

                foreach (var elGroup in elementsGroupedByAdId)
                {
                    var motherDbBannerGroup = elGroup.BannerGroup;
                    UpdatePhrases(elGroup.el, motherDbBannerGroup.Id);
                    AddNewBannerPhraseStats(elGroup.el);
                }

            }
        }

        private static void UpdatePhrases(IEnumerable<GetBannersStatElement> loadedElements,
                                          long motherDbBannerGroupId)
        {
            
            var uniquePhrases = loadedElements.Where(el => el.PhraseID != null)
                                              .GroupBy(el => el.PhraseID)
                                              .Select(group => new Phrase
                                                  {
                                                      Id = (long)group.Key,
                                                      Name = group.First().Phrase
                                                  })
                                              .ToList();

            var motherDbBannerGroup = _context.AllDirectBannerGroups.First(bg => bg.Id == motherDbBannerGroupId);
            _context.Refresh(RefreshMode.OverwriteChangesFromStore, motherDbBannerGroup);
            var dbPhrases = motherDbBannerGroup.Phrases.ToList();

            var phraseFromDBIds = dbPhrases.Select(banner => banner.Id).ToList();

            var lookUpChangedUnchangedPhrases = uniquePhrases
                                                .ToLookup(p => phraseFromDBIds.Contains(p.Id));
            var newPhrases = lookUpChangedUnchangedPhrases[false].ToList();

            foreach (var newPhrase in newPhrases)
            {

                try
                {
                    var newP = _context.Create<Phrase>();
                    newP.Id = newPhrase.Id;
                    newP.BannerGroupId = motherDbBannerGroupId;
                    newP.Name = newPhrase.Name;

                    _context.Save();
                }
                catch (Exception e)
                {
                    Console.WriteLine(@"Error in '_context.AttachCopy(newPhrase)'");
                    Console.WriteLine(@"BannerGroupId: {0}, Id: {1}, Name: {2}",
                                                    newPhrase.BannerGroupId, newPhrase.Id, newPhrase.Name);
                    
                    var phraseFromDBIds2 = _context.AllDirectBannerGroups
                                            .First(bg => bg.Id == motherDbBannerGroup.Id)
                                            .Phrases
                                            .Select(banner => banner.Id)
                                            .ToList();
                }

            }
            
        }

        private static void AddNewBannerPhraseStats(IEnumerable<GetBannersStatElement> bannersStat)
        {
            foreach (var stat in bannersStat.Where(st => st.PhraseID != null))
            {
                var newDbStat = new BannerPhraseStats
                {
                    BannerId = stat.BannerID,
                    
                    PhraseId = (long) stat.PhraseID,
                    Date = stat.StatDate,
                    SumSearch = stat.SumSearch,
                    SumContext = stat.SumContext,
                    ClicksSearch = stat.ClicksSearch,
                    ClicksContext = stat.ClicksContext,
                    ShowsSearch = stat.ShowsSearch,
                    ShowsContext = stat.ShowsContext
                };

                _context.AttachCopy(newDbStat);
            }

            _context.Save();
        }

        #endregion

        #region Методы, делающие запрос (Execute) и осуществляющие десериализацию ответа

        private static T Execute<T>(object dataIn) where T : new()
        {
            var request = new RestRequest
            {
                Method = Method.POST,
                RequestFormat = DataFormat.Json
            };

            if (dataIn != null)
                request.AddBody(dataIn);

            var r = _client.Execute<T>(request);
            if (r.StatusCode != HttpStatusCode.OK) return default(T);

            var deserialized = JsonConvert.DeserializeObject<T>(r.Content);

            return deserialized;
        }

        private static bool Execute(RestRequest request, object dataIn)
        {
            request.Method = Method.POST;
            request.RequestFormat = DataFormat.Json;
            if (dataIn != null)
            {
                request.AddBody(dataIn);
            }

            var r = _client.Execute(request);
            if (r.StatusCode != HttpStatusCode.OK) return false;

            return true;
        }

        static T Execute<T>(RestRequest request) where T : new()
        {
            
            Thread.Sleep(2000);

            var response = _client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                
                var deserialized = JsonConvert.DeserializeObject<T>(response.Content);

                return deserialized;
            }
            else
            {
                
                return default(T);
            }
        }
        #endregion

    }
}
