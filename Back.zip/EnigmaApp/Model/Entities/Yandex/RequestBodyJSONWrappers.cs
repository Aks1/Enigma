﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Collections.Generic;
using Newtonsoft.Json;

namespace EnigmaApp.Model.Entities.Yandex
{
    #region Объекты для запроса GetClientInfo
    public struct GetClientInfoRequestRoot
    {
        public string token;
        public string method;
    }
    #endregion

    #region Объекты для запроса GetCampaigns
    public struct GetCampaignsRequestRoot
    {
        public string token;
        public string method;
    }
    #endregion

    #region Объекты для запроса GetBanners
    [JsonObject]
    public class GetBannersRequestRoot
    {
        public string token { get; set; }
        public string method { get; set; }
        public GetBannersParam param { get; set; }
    }

    public class Filter
    {
        public List<string> StatusPhoneModerate { get; set; }
        public List<string> StatusBannerModerate { get; set; }
        public List<string> StatusPhrasesModerate { get; set; }
        public List<string> StatusActivating { get; set; }
        public List<string> StatusShow { get; set; }
        public List<string> IsActive { get; set; }
        public List<string> StatusArchive { get; set; }
        public List<int> TagIDS { get; set; }
        public List<string> Tags { get; set; }
        public List<string> StatusAdImageModerate { get; set; }
    }

    public class GetBannersParam
    {
        public List<long> CampaignIDS { get; set; }
        
        public List<string> FieldsNames { get; set; }
        public string GetPhrases { get; set; }

        public string Currency { get; set; }
        
        public string AuctionBids { get; set; }
    }
    #endregion

    #region Объекты для запроса GetBannersStat
    public class GetBannersStatRequestRoot
    {
        public string token { get; set; }
        public string method { get; set; }
        public GetBannersStatParam param { get; set; }
    }

    public class GetBannersStatParam
    {
        public int CampaignID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public List<string> GroupByColumns { get; set; }

        public List<string> OrderBy { get; set; }
        public string Currency { get; set; }
        public string IncludeVAT { get; set; }
        public string IncludeDiscount { get; set; }
    }
    #endregion

}
