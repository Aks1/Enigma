﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;

namespace EnigmaApp.Model.Entities.Yandex
{

    public class BannerPhraseStats : Entity
    {

        [JsonProperty(PropertyName = "PhraseID")]
        public long PhraseId { get; set; }

        public Phrase Phrase { get; set; }

        [JsonProperty(PropertyName = "BannerID")]
        public long BannerId { get; set; }

        public Banner Banner { get; set; }

        [JsonProperty(PropertyName = "StatDate")]
        public DateTime Date { get; set; }

        [JsonProperty(PropertyName = "SumSearch")]
        public float SumSearch { get; set; }

        [JsonProperty(PropertyName = "SumContext")]
        public float SumContext { get; set; }

        [JsonProperty(PropertyName = "ClicksSearch")]
        public int ClicksSearch { get; set; }

        [JsonProperty(PropertyName = "ClicksContext")]
        public int ClicksContext { get; set; }

        [JsonProperty(PropertyName = "ShowsSearch")]
        public int ShowsSearch { get; set; }

        [JsonProperty(PropertyName = "ShowsContext")]
        public int ShowsContext { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<BannerPhraseStats>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "Yandex"));
            m.HasProperty(pstats => pstats.Id).IsIdentity(KeyGenerator.Autoinc);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");

            m.HasAssociation(bpstats => bpstats.Phrase).ToColumn("PhraseId")
                .HasConstraint((bpstats, p) => bpstats.PhraseId == p.Id)
                .IsManaged();
            m.HasAssociation(bpstats => bpstats.Banner).ToColumn("BannerId")
                .HasConstraint((bpstats, b) => bpstats.BannerId == b.Id)
                .IsManaged();

            return m;
        }

        public BannerPhraseStats()
        {
            
            Date = new DateTime(2010, 1, 1);
        }
        
    }
}
