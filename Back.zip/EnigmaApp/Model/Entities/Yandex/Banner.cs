﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
using System.Collections.Generic;

namespace EnigmaApp.Model.Entities.Yandex
{

    public class Banner : EntityWOKey
    {

        [JsonProperty(PropertyName = "BannerID")]
        public Int64 Id { get; set; }

        [JsonProperty(PropertyName = "Title")]
        public string Title { get; set; }

        [JsonProperty(PropertyName = "AdGroupID")]
        public Int64 BannerGroupId { get; set; }

        public BannerGroup BannerGroup { get; set; }

        public IList<BannerPhraseStats> BannerPhraseStats { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<Banner>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "Yandex"));
            m.HasProperty(banner => banner.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");

            m.HasAssociation(banner => banner.BannerGroup).ToColumn("BannerGroupId")
                .HasConstraint((banner, bannerG) => banner.BannerGroupId == bannerG.Id)
                .IsManaged();

            m.HasAssociation(banner => banner.BannerPhraseStats)
                .WithOpposite(stat => stat.Banner)
                .HasConstraint((banner, stat) => banner.Id == stat.BannerId).IsManaged();

            return m;
        }

        public Banner()
        {
            
        }
    }
}
