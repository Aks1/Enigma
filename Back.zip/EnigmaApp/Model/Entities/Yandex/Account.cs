﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Collections.Generic;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;

namespace EnigmaApp.Model.Entities.Yandex
{

    public class Account : Entity
    {

        public string Login { get; set; }

        public string Token { get; set; }

        public IList<Campaing> Campaings { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<Account>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "Yandex"));
            m.HasProperty(account => account.Id).IsIdentity(KeyGenerator.Autoinc);
            m.HasVersion().ToColumn("Version");

            m.HasProperty(p => p.Login).HasLength(64);
            m.HasProperty(p => p.Token).WithVariableLength();

            m.HasAssociation(acc => acc.Campaings)
                .WithOpposite(camp => camp.Account)
                .HasConstraint((acc, camp) => acc.Id == camp.AccountId).IsManaged();

            return m;
        }
    }
}
