﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;

namespace EnigmaApp.Model.Entities.Yandex
{

    public class Campaing : EntityWOKey
    {

        [JsonProperty(PropertyName = "CampaignID")]
        public Int64 Id { get; set; }

        public string Login { get; set; }

        public long AccountId { get; set; }

        public Account Account { get; set; }

        public string Name { get; set; }

        public DateTime StartDate { get; set; }

        public IList<BannerGroup> BannerGroups { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<Campaing>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "Yandex"));
            m.HasProperty(campaing => campaing.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");

            m.HasAssociation(сamp => сamp.Account)
                .ToColumn("AccountId")
                .HasConstraint((сamp, acc) => сamp.AccountId == acc.Id).IsManaged();

            m.HasAssociation(camp => camp.BannerGroups)
                .WithOpposite(bannerG => bannerG.Campaing)
                .HasConstraint((camp, bannerG) => camp.Id == bannerG.CampaignId).IsManaged();

            return m;
        }

        public Campaing()
        {
            
            StartDate = new DateTime(2010, 1, 1);
        }
    }
}
