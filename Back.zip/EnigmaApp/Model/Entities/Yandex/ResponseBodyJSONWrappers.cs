﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace EnigmaApp.Model.Entities.Yandex
{
    #region Объекты от запроса "GetClientInfo"

    public class GetClientInfoRoot
    {
        public List<GetClientInfoData> data { get; set; }
    }

    public class GetClientInfoData
    {
        public string Login { get; set; }

    }
    #endregion

    #region Объекты от запроса "GetCampaign"

    [JsonObject]
    public class GetCampaignRoot
    {
        [JsonProperty(PropertyName = "data")]
        public List<Campaing> data { get; set; }
    }

    #endregion

    #region Объекты от запроса "GetBanners" без фраз (GetPhrases = "No") с неполными полями
    public class GetBannersRoot
    {
        public List<GetBannersResponseElement> data { get; set; }
    }

    public class GetBannersResponseElement
    {
        public int CampaignID { get; set; }
        public int BannerID { get; set; }
        public int AdGroupID { get; set; }
        public string Title { get; set; }
        public string AdGroupName { get; set; }
    }
    #endregion

    #region НЕ ИСПОЛЬЗУЕТСЯ. НЕ УДАЛЯТЬ. Объекты от запроса "GetBanners" без фраз (GetPhrases = "No") с полными полями


    #endregion

    #region НЕ ИСПОЛЬЗУЕТСЯ. НЕ УДАЛЯТЬ. Объекты от запроса "GetBanners" c фразами (GetPhrases = "Yes") с неполными полями

    #endregion

    #region Объекты от запроса "GetBannersStat"
    public class GetBannersStatRoot
    {
        public GetBannersStatData data { get; set; }
    }

    public class GetBannersStatData
    {
        public string StartDate { get; set; }
        public int CampaignID { get; set; }
        public string EndDate { get; set; }
        public List<GetBannersStatElement> Stat { get; set; }
    }

    public class GetBannersStatElement
    {
        public int BannerID { get; set; }
        public long? PhraseID { get; set; }
        public string Phrase { get; set; }

        public DateTime StatDate { get; set; }
        public float SumSearch { get; set; }
        public float SumContext { get; set; }
        public int ClicksSearch { get; set; }
        public int ClicksContext { get; set; }
        public int ShowsSearch { get; set; }
        public int ShowsContext { get; set; }

    }
    #endregion
}
