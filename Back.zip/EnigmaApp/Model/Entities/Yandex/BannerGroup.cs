﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;

namespace EnigmaApp.Model.Entities.Yandex
{

    public class BannerGroup : EntityWOKey
    {

        [JsonProperty(PropertyName = "AdGroupID")]
        public Int64 Id { get; set; }

        [JsonProperty(PropertyName = "AdGroupName")]
        public String Name { get; set; }

        [JsonProperty(PropertyName = "CampaignID")]
        public Int64 CampaignId { get; set; }

        public Campaing Campaing { get; set; }

        public IList<Banner> Banners { get; set; }

        public IList<Phrase> Phrases { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<BannerGroup>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "Yandex"));
            m.HasProperty(bannerG => bannerG.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");

            m.HasAssociation(bannerG => bannerG.Campaing)
                .ToColumn("CampaignId")
                .HasConstraint((bannerG, campaing) => bannerG.CampaignId == campaing.Id).IsManaged();

            m.HasAssociation(bannerG => bannerG.Banners)
                .WithOpposite(banner => banner.BannerGroup)
                .HasConstraint((bannerG, banner) => bannerG.Id == banner.BannerGroupId).IsManaged();
            m.HasAssociation(bannerG => bannerG.Phrases)
                .WithOpposite(phrase => phrase.BannerGroup)
                .HasConstraint((bannerG, phrase) => bannerG.Id == phrase.BannerGroupId).IsManaged();

            return m;
        }

        public BannerGroup()
        {
            
        }
    }
}
