﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;

namespace EnigmaApp.Model.Entities.Yandex
{

    public class Phrase : EntityWOKey
    {

        [JsonProperty(PropertyName = "PhraseID")]
        public long Id { get; set; }

        [JsonProperty(PropertyName = "Phrase")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "AdGroupID")]
        public long BannerGroupId { get; set; }

        public BannerGroup BannerGroup { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<Phrase>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "Yandex"));
            m.HasProperty(phrase => phrase.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");

            m.HasProperty(phrase => phrase.Name).HasColumnType("nvarchar(max)");

            m.HasAssociation(phrase => phrase.BannerGroup).ToColumn("BannerGroupId")
                .HasConstraint((phrase, bannerG) => phrase.BannerGroupId == bannerG.Id)
                .IsManaged();

            return m;
        }

        public Phrase()
        {
            
        }
    }
}
