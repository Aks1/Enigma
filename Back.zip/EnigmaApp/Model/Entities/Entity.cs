﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>
using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities
{

    public abstract class Entity
    {

        public Int64 Id { get; set; }

        public DateTime Created { get; set; }

        public DateTime Changed { get; set; }

        public Context Context
        {
            get { return OpenAccessContextBase.GetContext(this) as Context; }
        }
        
        public static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Entity> m = new MappingConfiguration<Entity>();
            
            m.MapType().Inheritance(InheritanceStrategy.Horizontal);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasDiscriminatorValue("{no}");
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.HasProperty(p => p.Created).IsCalculatedOn(DateTimeAutosetMode.Insert).WithDataAccessKind(DataAccessKind.ReadOnly);
            m.HasProperty(p => p.Changed).IsCalculatedOn(DateTimeAutosetMode.InsertAndUpdate).WithDataAccessKind(DataAccessKind.ReadOnly);
            
            return m;
        }
    }
}
