﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>
using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities
{

    public abstract class LinkEntity
    {

        public Int64 Id { get; set; }
        
        public static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<LinkEntity> m = new MappingConfiguration<LinkEntity>();
            
            m.MapType().Inheritance(InheritanceStrategy.Horizontal);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasDiscriminatorValue("{no}");
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            
            return m;
        }
    }
}
