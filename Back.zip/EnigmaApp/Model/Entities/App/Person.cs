﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.App
{

    public class Person : Entity
    {

        public string Surname { get; set; }

        public string Name { get; set; }

        public string Patronymic { get; set; }

        public DataSourceEnum DataSource { get; set; }

        public Int64 AccountId { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Person> m = new MappingConfiguration<Person>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "App"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            
            return m;
        }

        public Person()
        {
            
        }
    }
}
