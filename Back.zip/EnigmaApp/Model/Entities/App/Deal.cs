﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.App
{

    public class Deal : Entity
    {

        public decimal Value { get; set; }

        public string Currency { get; set; }

        public Int64 StateId { get; set; }

        public DealState State { get; set; }

        public DataSourceEnum DataSource { get; set; }

        public Int64 AccountId { get; set; }

        public Account Account { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Deal> m = new MappingConfiguration<Deal>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "App"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.Value).IsCurrency();
            m.HasAssociation(p => p.State).ToColumn("StateId").HasConstraint((p, o) => p.StateId == o.Id).IsManaged();
            m.HasAssociation(p => p.Account).ToColumn("AccountId").HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();

            return m;
        }

        public Deal()
        {
            
        }
    }
}
