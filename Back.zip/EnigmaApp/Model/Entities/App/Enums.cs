﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

namespace EnigmaApp.Model.Entities.App
{

    public enum DataSourceEnum : int
    {
        
        AmoCRM = 1,
        
        Yandex = 2,
    }

    public enum DealStateEnum : int
    {
        
        None = 1,
        
        Preparing = 200,
        
        Concluded = 300,
        
        Finished = 400
    }
}
