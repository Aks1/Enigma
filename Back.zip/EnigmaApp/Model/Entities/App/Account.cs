﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Collections.Generic;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.App
{

    public class Account : Entity
    {

        public string Login { get; set; }

        public string Password { get; set; }

        public IList<AmoCRMAccess> AmoCRMAccesses { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Account> m = new MappingConfiguration<Account>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "App"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.Login).WithVariableLength(64);
            m.HasProperty(p => p.Password).WithVariableLength(64);
            m.HasAssociation(p => p.AmoCRMAccesses).WithOpposite(o => o.Account).HasConstraint((p, o) => p.Id == o.AccountId).IsManaged();
            
            return m;
        }

        public Account()
        {
        }
    }
}
