﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.App
{

    public class DealState : Entity
    {

        public string Name { get; set; }

        public Int32 SequenceIndex { get; set; }

        public Int64 AccountId { get; set; }

        public Account Account { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<DealState> m = new MappingConfiguration<DealState>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "App"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.Name).WithVariableLength(64);
            m.HasAssociation(p => p.Account).ToColumn("AccountId").HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();
            
            return m;
        }

        public DealState()
        {
            
            Name = "Некорректное состояние! Сообщите в поддержку!";
        }
    }
}
