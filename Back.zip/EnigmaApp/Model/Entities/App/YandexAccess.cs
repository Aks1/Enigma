﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.App
{

    [JsonObject]
    public class YandexAccess : Entity
    {

        public string Login { get; set; }

        public string Token { get; set; }

        public Int64 AccountId { get; set; }

        public Account Account { get; set; }

        public Int64? YandexAccountId { get; set; }

        public Yandex.Account YandexAccount { get; set; }

        public DateTime InternalLastModifiedTime { get; set; }

        public DateTime ExternalLastModifiedTime { get; set; }

        public bool IsDeleted { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<YandexAccess>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "App"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.YandexAccountId).IsNullable();
            m.HasProperty(p => p.Login).WithVariableLength(64);
            m.HasProperty(p => p.Token).WithVariableLength();
            m.HasAssociation(p => p.Account).ToColumn("AccountId")
                .HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();
            m.HasAssociation(p => p.YandexAccount).ToColumn("YandexAccountId").IsManaged();
            
            return m;
        }
        public YandexAccess()
        {
            
            YandexAccount = null;
            IsDeleted = false;
            ExternalLastModifiedTime = new DateTime(2000, 1, 1);
            InternalLastModifiedTime = new DateTime(2000, 1, 1);
        }
    }
}
