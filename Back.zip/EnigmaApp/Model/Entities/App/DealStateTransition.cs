﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.App
{

    public class DealStateTransition : LinkEntity
    {

        public Int64 OldStateId { get; set; }

        public DealState OldState { get; set; }

        public Int64 NewStateId { get; set; }

        public DealState NewState { get; set; }

        public DateTime Date { get; set; }

        public Int64 AccountId { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<DealStateTransition> m = new MappingConfiguration<DealStateTransition>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "App"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            
            return m;
        }

        public DealStateTransition()
        {
            
        }
    }
}
