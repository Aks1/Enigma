﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    public class LeadStatusTransition : LinkEntity
    {

        public Int64 AccountId { get; set; }

        public Account Account { get; set; }

        public Int64? OldStatusId { get; set; }

        public LeadStatus OldStatus { get; set; }

        public Int64 NewStatusId { get; set; }

        public LeadStatus NewStatus { get; set; }

        public Int32 Direction { get; set; }

        public DateTime Date { get; set; }

        public Int64 LeadId { get; set; }

        public Lead Lead { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<LeadStatusTransition> m = new MappingConfiguration<LeadStatusTransition>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.OldStatusId).IsNullable();
            
            m.HasAssociation(p => p.NewStatus).WithOpposite(p => p.ToTransitions).HasConstraint((p, o) => p.NewStatusId == o.Id && p.AccountId == o.AccountId).IsManaged();
            m.HasAssociation(p => p.OldStatus).WithOpposite(p => p.FromTransitions).HasConstraint((p, o) => p.OldStatusId == o.Id && p.AccountId == o.AccountId).IsManaged();
            m.HasAssociation(p => p.Lead).ToColumn("LeadId").HasConstraint((p, o) => p.LeadId == o.Id).IsManaged();
            
            return m;
        }

        public LeadStatusTransition()
        {
            
        }
    }
}
