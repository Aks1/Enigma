﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    [JsonObject]
    public class LeadStatus : Entity
    {

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "color")]
        public string Color { get; set; }

        [JsonProperty(PropertyName = "sort")]
        public Int32 SequenceIndex { get; set; }

        [JsonProperty(PropertyName = "pipeline_id")]
        public Int64 PipelineId { get; set; }

        public Int64 AccountId { get; set; }

        public Account Account { get; set; }

        public bool Success { get; set; }

        public bool Failure { get; set; }

        public IList<LeadStatusTransition> ToTransitions { get; set; }

        public IList<LeadStatusTransition> FromTransitions { get; set; }

        public const Int64 LeadStatusSuccessId = 142;

        public const Int64 LeadStatusFailureId = 143;
        
        public new static MappingConfiguration GetMapping()
        {
            
            var m = new MappingConfiguration<LeadStatus>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.HasProperty(p => p.AccountId).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasAssociation(p => p.Account).ToColumn("AccountId").HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();
            
            m.HasAssociation(p => p.ToTransitions).WithOpposite(o => o.NewStatus).HasConstraint((p, o) => p.Id == o.NewStatusId).IsDependent();
            m.HasAssociation(p => p.FromTransitions).WithOpposite(o => o.OldStatus).HasConstraint((p, o) => p.Id == o.OldStatusId).IsDependent();
            
            return m;
        }

        public LeadStatus()
        {
            
            Success = false;
            Failure = false;
        }
    }
}
