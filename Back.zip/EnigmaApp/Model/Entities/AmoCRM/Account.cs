﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    [JsonObject]
    public class Account : Entity
    {

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "subdomain")]
        public string SubDomain { get; set; }

        [JsonProperty(PropertyName = "currency")]
        public string Currency { get; set; }

        [JsonProperty(PropertyName = "timezone")]
        public string TimeZone { get; set; }

        public bool IsDeleted { get; set; }

        [JsonProperty(PropertyName = "users")]
        public IList<User> Users { get; set; }

        [JsonProperty(PropertyName = "leads_statuses")]
        public IList<LeadStatus> Statuses { get; set; }

        public IList<Lead> Leads { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Account> m = new MappingConfiguration<Account>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.Currency).WithVariableLength(16);
            m.HasProperty(p => p.TimeZone).WithVariableLength(64);

            m.HasAssociation(p => p.Users).WithOpposite(o => o.Account).HasConstraint((p, o) => p.Id == o.AccountId).IsManaged();
            m.HasAssociation(p => p.Statuses).WithOpposite(o => o.Account).HasConstraint((p, o) => p.Id == o.AccountId).IsManaged();
            m.HasAssociation(p => p.Leads).WithOpposite(o => o.Account).HasConstraint((p, o) => p.Id == o.AccountId).IsManaged();
            
            return m;
        }

        public Account()
        {

        }
    }
}
