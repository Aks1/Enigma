﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Collections.Generic;
using Newtonsoft.Json;
namespace EnigmaApp.Model.Entities.AmoCRM
{
    [JsonObject]
    public class Response
    {
        
        [JsonProperty(PropertyName = "server_time")]
        public int ServerTime { get; set; }
    }

    [JsonObject]
    public class ResponseAccount : Response
    {

        [JsonProperty(PropertyName = "account")]
        public Account Account { get; set; }
    }

    [JsonObject]
    public class ResponseAccountRoot
    {

        [JsonProperty(PropertyName = "response")]
        public ResponseAccount Response { get; set; }
    }

    public class ResponseLeads : Response
    {

        [JsonProperty(PropertyName = "leads")]
        public List<Lead> Leads { get; set; }
    }

    [JsonObject]
    public class ResponseLeadsRoot
    {

        [JsonProperty(PropertyName = "response")]
        public ResponseLeads Response { get; set; }
    }

    [JsonObject]
    public class ResponseContacts : Response
    {

        [JsonProperty(PropertyName = "contacts")]
        public List<Contact> Contacts { get; set; }
    }

    [JsonObject]
    public class ResponseContactsRoot
    {

        [JsonProperty(PropertyName = "response")]
        public ResponseContacts Response { get; set; }
    }

    [JsonObject]
    public class ResponseLinks : Response
    {

        [JsonProperty(PropertyName = "links")]
        public List<LinkContactLead> Links { get; set; }
    }

    [JsonObject]
    public class ResponseLinksRoot
    {

        [JsonProperty(PropertyName = "response")]
        public ResponseLinks Response { get; set; }
    }

    [JsonObject]
    public class ResponseCompanies : Response
    {

        [JsonProperty(PropertyName = "companies")]
        public List<Company> Companies { get; set; }
    }

    [JsonObject]
    public class ResponseCompaniesRoot
    {

        [JsonProperty(PropertyName = "response")]
        public ResponseCompanies Response { get; set; }
    }
}
