﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    public class LinkContactLead : LinkEntity
    {

        public Int64 ContactId { get; set; }

        public Contact Contact { get; set; }

        public Int64 LeadId { get; set; }

        public Lead Lead { get; set; }

        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<LinkContactLead> m = new MappingConfiguration<LinkContactLead>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Autoinc);
            
            m.HasAssociation(p => p.Contact).ToColumn("ContactId").HasConstraint((p, o) => p.ContactId == o.Id).IsManaged();
            m.HasAssociation(p => p.Lead).ToColumn("LeadId").HasConstraint((p, o) => p.LeadId == o.Id).IsManaged();
            
            return m;
        }
    }
}
