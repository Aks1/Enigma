﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

namespace EnigmaApp.Model.Entities.AmoCRM
{

    public enum ContactTypeEnum : int
    {
        
        contact = 1,
        
        company = 2
    }
}
