﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    [JsonObject]
    public class Lead : Entity
    {

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "created_user_id")]
        public Int64 CreatedUserId { get; set; }

        [JsonProperty(PropertyName = "date_create")]
        public Int64 DateCreate
        {
            get {  return 0; }
            set
            {
                
                DateCreated = DateTimeOffset.FromUnixTimeSeconds(value).UtcDateTime;
            }
        }

        [JsonProperty(PropertyName = "last_modified")]
        public Int64 LastModified
        {
            get {  return 0; }
            set
            {
                
                DateModified = DateTimeOffset.FromUnixTimeSeconds(value).UtcDateTime;
            }
        }

        [JsonProperty(PropertyName = "status_id")]
        public Int64 StatusId { get; set; }

        public LeadStatus Status { get; set; }

        [JsonProperty(PropertyName = "price")]
        public string Price 
        {
            get { return null; }
            set
            {
                decimal price;
                Value = !Decimal.TryParse(value, out price) ? 0 : price;
            }
        }

        public decimal Value { get; set; }

        [JsonProperty(PropertyName = "responsible_user_id")]
        public Int64 ResponsibleUserId { get; set; }

        public User ResponsibleUser { get; set; }

        [JsonProperty(PropertyName = "account_id")]        
        public Int64 AccountId { get; set; }

        public Account Account { get; set; }

        public DateTime DateCreated { get; set; }

        public DateTime DateModified { get; set; }

        public IList<LinkContactLead> ContactLinks { get; set; }

        public IList<LeadStatusTransition> Transitions { get; set; }
        public long? BannerId { get; set; }
        public long? PhraseId { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Lead> m = new MappingConfiguration<Lead>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.Price).AsTransient();
            m.HasProperty(p => p.DateCreate).AsTransient();
            m.HasProperty(p => p.LastModified).AsTransient();
            
            m.HasProperty(p => p.Value).IsCurrency();
            m.HasAssociation(p => p.ResponsibleUser).ToColumn("ResponsibleUserId").HasConstraint((p, o) => p.ResponsibleUserId == o.Id).IsManaged();
            m.HasAssociation(p => p.Account).ToColumn("AccountId").HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();
            m.HasAssociation(p => p.Status).HasConstraint((p, o) => p.StatusId == o.Id && p.AccountId == o.AccountId).IsManaged();
            
            m.HasAssociation(p => p.ContactLinks).WithOpposite(o => o.Lead).HasConstraint((p, o) => p.Id == o.LeadId).IsDependent().IsManaged();
            m.HasAssociation(p => p.Transitions).WithOpposite(o => o.Lead).HasConstraint((p, o) => p.Id == o.LeadId).IsDependent().IsManaged();
            
            return m;
        }

        public Lead()
        {
            
            DateCreated = new DateTime(2010, 1, 1);
            DateModified = new DateTime(2010, 1, 1);
        }
    }
}
