﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    public class Company : Entity
    {

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "created_user_id")]
        public Int64 CreatedUserId { get; set; }

        [JsonProperty(PropertyName = "date_create")]
        public Int64 DateCreate
        {
            get
            {
                return 0;
            }
            set
            {
                
                DateCreated = DateTimeOffset.FromUnixTimeSeconds(value).UtcDateTime;
            }
        }

        [JsonProperty(PropertyName = "last_modified")]
        public Int64 LastModified
        {
            get
            {
                return 0;
            }
            set
            {
                
                DateModified = DateTimeOffset.FromUnixTimeSeconds(value).UtcDateTime;
            }
        }

        [JsonProperty(PropertyName = "responsible_user_id")]
        public Int64 ResponsibleUserId { get; set; }

        [JsonProperty(PropertyName = "account_id")]
        public Int64 AccountId { get; set; }

        public DateTime DateCreated { get; set; }

        public DateTime DateModified { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Company> m = new MappingConfiguration<Company>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.DateCreate).AsTransient();
            m.HasProperty(p => p.LastModified).AsTransient();
            
            return m;
        }

        public Company()
        {
            
            DateCreated = new DateTime(2010, 1, 1);
            DateModified = new DateTime(2010, 1, 1);
        }
    }
}
