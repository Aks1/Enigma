﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    [JsonObject]
    public class Pipeline : Entity
    {

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "label")]
        public string Label { get; set; }

        [JsonProperty(PropertyName = "sort")]
        public Int32 SequenceIndex { get; set; }

        [JsonProperty(PropertyName = "is_main")]
        public Boolean IsMain { get; set; }

        public Int64 AccountId { get; set; }

        public Account Account { get; set; }

        [JsonProperty(PropertyName = "statuses")]
        public IList<LeadStatus> LeadStatuses { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Pipeline> m = new MappingConfiguration<Pipeline>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasAssociation(p => p.Account).ToColumn("AccountId").HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();

            return m;
        }
    }
}
