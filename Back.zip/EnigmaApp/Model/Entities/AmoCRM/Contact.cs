﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Metadata.Fluent;
namespace EnigmaApp.Model.Entities.AmoCRM
{

    [JsonObject]
    public class Contact : Entity
    {

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "created_user_id")]
        public Int64 CreatedUserId { get; set; }

        [JsonProperty(PropertyName = "date_create")]
        public Int64 DateCreate 
        {
            get
            {
                return 0;
            }
            set
            {
                
                DateCreated = DateTimeOffset.FromUnixTimeSeconds(value).UtcDateTime;
            }
        }

        [JsonProperty(PropertyName = "last_modified")]
        public Int64 LastModified
        {
            get
            {
                return 0;
            }
            set
            {
                
                DateModified = DateTimeOffset.FromUnixTimeSeconds(value).UtcDateTime;
            }
        }

        [JsonProperty(PropertyName = "responsible_user_id")]
        public Int64 ResponsibleUserId { get; set; }

        [JsonProperty(PropertyName = "account_id")]
        public Int64 AccountId { get; set; }

        public Account Account { get; set; }

        public DateTime DateCreated { get; set; }

        public DateTime DateModified { get; set; }

        [JsonProperty(PropertyName = "linked_leads_id")]
        public List<Int64> LinkedLeadsId { get; set; }

        [JsonProperty(PropertyName = "linked_company_id")]
        public Int64? CompanyId { get; set; }

        public Company Company { get; set; }

        public IList<LinkContactLead> LeadLinks { get; set; }
        
        public new static MappingConfiguration GetMapping()
        {
            
            MappingConfiguration<Contact> m = new MappingConfiguration<Contact>();
            
            m.MapType().ToTable(new TableName(m.ConfiguredType.Name, "AmoCRM"));
            m.HasProperty(p => p.Id).IsIdentity(KeyGenerator.Default);
            m.MapType().WithConcurencyControl(OptimisticConcurrencyControlStrategy.Version);
            m.HasVersion().ToColumn("Version");
            m.HasProperty(p => p.DateCreate).AsTransient();
            m.HasProperty(p => p.LastModified).AsTransient();
            m.HasAssociation(p => p.LinkedLeadsId).AsTransient();
            m.HasProperty(p => p.CompanyId).IsNullable();
            m.HasAssociation(p => p.Account).ToColumn("AccountId").HasConstraint((p, o) => p.AccountId == o.Id).IsManaged();
            m.HasAssociation(p => p.Company).ToColumn("CompanyId").HasConstraint((p, o) => p.CompanyId == o.Id).IsManaged();
            m.HasAssociation(p => p.LeadLinks).WithOpposite(o => o.Contact).HasConstraint((p, o) => p.Id == o.ContactId).IsDependent().IsManaged();

            return m;
        }

        public Contact()
        {
            
            DateCreated = new DateTime(2010, 1, 1);
            DateModified = new DateTime(2010, 1, 1);
        }
    }
}
