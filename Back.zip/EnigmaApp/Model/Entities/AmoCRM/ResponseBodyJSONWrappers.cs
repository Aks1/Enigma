﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace EnigmaApp.Model.Entities.AmoCRM
{
    #region Объекты от запроса "/private/api/v2/json/leads/list"
    public class GetLeadsRoot
    {
        public GetLeadsResponse response { get; set; }
    }

    public class GetLeadsResponse
    {
        public List<GetLeadsResponseElement> leads { get; set; }
        public int server_time { get; set; }
    }

    public class GetLeadsResponseElement
    {
        public long id { get; set; }
        public string name { get; set; }
        public int last_modified { get; set; }
        public long status_id { get; set; }
        public string price { get; set; }
        public long responsible_user_id { get; set; }
        
        public int date_create { get; set; }
        public long account_id { get; set; }
        public long created_user_id { get; set; }
        public List<CustomFieldResponse> custom_fields { get; set; }
        
    }

    public class CustomFieldResponse
    {
        public string id { get; set; }
        public string name { get; set; }
        public List<ValueResponse> values { get; set; }
    }

    public class ValueResponse
    {
        public string value { get; set; }
    }

    public class TagResponse
    {
        public string id { get; set; }
        public string name { get; set; }
    }
    #endregion

}
