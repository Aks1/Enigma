/// <copyright>� �������� ��������� �������������, �������� ��������� ���������� 2016. 
/// ��� ����� �������� </copyright>

#pragma warning disable 1591

using System;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Common;
using System.Collections.Generic;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Data.Common;
using Telerik.OpenAccess.Metadata.Fluent;
using Telerik.OpenAccess.Metadata.Fluent.Advanced;
using Telerik.OpenAccess.Metadata.Relational;

namespace EnigmaApp.Model
{
    
	public partial class ModelMetadata : FluentMetadataSource
	{
        
        protected override MetadataContainer CreateModel()
        {
            
            MetadataContainer container = base.CreateModel();
            
            container.DefaultMapping.NullForeignKey = true;
            container.DefaultMapping.ClrMap.Add(new Telerik.OpenAccess.Metadata.Relational.DefaultTypeMapping()
                { ClrType = "System.String", SqlType = "nvarchar" });

            MetaNameGenerator metaNameGenerator = container.NameGenerator;
            
            metaNameGenerator.RemoveCamelCase = false;
            metaNameGenerator.ResolveReservedWords = false;
            metaNameGenerator.SourceStrategy = NamingSourceStrategy.Property;

            return container;
        }

        protected override IList<MappingConfiguration> PrepareMapping()
        {
            
            List<MappingConfiguration> configurations = new List<MappingConfiguration>();

            return configurations;
        }
				
		protected override void SetContainerSettings(MetadataContainer container)
		{
			container.Name = "Model";
			container.DefaultNamespace = "EnigmaApp.Model";
			container.NameGenerator.SourceStrategy = Telerik.OpenAccess.Metadata.NamingSourceStrategy.Property;
			container.NameGenerator.RemoveCamelCase = false;
		}
	}
}
#pragma warning restore 1591
