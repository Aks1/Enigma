/// <copyright>� �������� ��������� �������������, �������� ��������� ���������� 2016. 
/// ��� ����� �������� </copyright>

#pragma warning disable 1591

using System;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Common;
using System.Collections.Generic;
using EnigmaApp.Model.Entities.AmoCRM;
using EnigmaApp.Model.Entities.App;
using EnigmaApp.Model.Entities.Yandex;
using Telerik.OpenAccess;
using Telerik.OpenAccess.Metadata;
using Telerik.OpenAccess.Data.Common;
using Telerik.OpenAccess.Metadata.Fluent;
using Telerik.OpenAccess.Metadata.Fluent.Advanced;
using Account = EnigmaApp.Model.Entities.App.Account;

namespace EnigmaApp.Model
{

	public partial class Context : OpenAccessContext, IModelUnitOfWork
	{
        #region ��������� ���������

        #region ������� ������

        public IQueryable<Account> AllAccounts
        {
            get
            {
                return this.GetAll<Account>();
            }
        }
        #endregion

        #region ���

        public IQueryable<AmoCRMAccess> AllAmoCRMAccesses
        {
            get { return this.GetAll<AmoCRMAccess>(); }
        }

        public IQueryable<Deal> AllDeals
        {
            get { return this.GetAll<Deal>(); }
        }

        public IQueryable<Entities.AmoCRM.Account> AllAmoCRMAccounts
        {
            get { return this.GetAll<Entities.AmoCRM.Account>(); }
        }

        public IQueryable<Contact> AllAmoCRMContacts
        {
            get { return this.GetAll<Contact>(); }
        }

        public IQueryable<Company> AllAmoCRMCompanies
        {
            get { return this.GetAll<Company>(); }
        }

        public IQueryable<Lead> AllAmoCRMLeads
        {
            get { return this.GetAll<Lead>(); }
        }

        public IQueryable<LeadStatus> AllAmoCRMLeadStatuses
        {
            get { return this.GetAll<LeadStatus>(); }
        }

        public IQueryable<User> AllAmoCRMUsers
        {
            get { return this.GetAll<User>(); }
        }

        public IQueryable<LeadStatusTransition> AllAmoCRMLeadStatusTransitions
        {
            get { return this.GetAll<LeadStatusTransition>(); }
        }
        #endregion

        #region ������

        public IQueryable<YandexAccess> AllYandexAccesses
        {
            get { return this.GetAll<YandexAccess>(); }
        }

        public IQueryable<Entities.Yandex.Account> AllYandexAccounts
        {
            get { return this.GetAll<Entities.Yandex.Account>(); }
        }

        public IQueryable<Campaing> AllDirectCampaings
        {
            get { return this.GetAll<Campaing>(); }
        }

        public IQueryable<BannerGroup> AllDirectBannerGroups
        {
            get { return this.GetAll<BannerGroup>(); }
        }

        public IQueryable<Banner> AllDirectBanners
        {
            get { return this.GetAll<Banner>(); }
        }

        public IQueryable<Phrase> AllDirectPhrases
        {
            get { return this.GetAll<Phrase>(); }
        }

        public IQueryable<BannerPhraseStats> AllDirectBannerPhraseStats
        {
            get { return this.GetAll<BannerPhraseStats>(); }
        }

        #endregion

        #endregion ��������� ���������

        #region �������������

        public void UpdateSchema()
        {
            var handler = this.GetSchemaHandler();
            string script = null;
            try
            {
                script = handler.CreateUpdateDDLScript(null);
            }
            catch (Exception ex)
            {
                bool throwException = false;
                try
                {
                    handler.CreateDatabase();
                    script = handler.CreateDDLScript();
                }
                catch
                {
                    throwException = true;
                }
                if (throwException)
                    throw;
            }

            if (string.IsNullOrEmpty(script) == false)
            {
                handler.ForceExecuteDDLScript(script);
            }
        }

        private static string connectionStringName = "EnigmaAzureConnection";
			
		private static BackendConfiguration backend = GetBackendConfiguration();
				
		private static MetadataSource metadataSource = new ModelMetadata();
		
		public Context()
			:base(connectionStringName, backend, metadataSource)
		{ }
		
		public Context(string connection)
			:base(connection, backend, metadataSource)
		{ }
		
		public Context(BackendConfiguration backendConfiguration)
            : base(connectionStringName, backendConfiguration, metadataSource)
		{ }
			
		public Context(string connection, MetadataSource metadataSource)
			:base(connection, backend, metadataSource)
		{ }
		
		public Context(string connection, BackendConfiguration backendConfiguration, MetadataSource metadataSource)
			:base(connection, backendConfiguration, metadataSource)
		{ }

        public static void SetConnectionStringName(string name)
        {
            
            connectionStringName = name;
        }

		public static BackendConfiguration GetBackendConfiguration()
		{
            
			BackendConfiguration backend = new BackendConfiguration();
            
            backend.Backend = "Azure";
			backend.ProviderName = "System.Data.SqlClient";
            backend.SecondLevelCache.Enabled = true;
            backend.SecondLevelCache.NumberOfObjects = 100000;
            
            backend.Logging.LogEvents = LoggingLevel.Normal;
            backend.Logging.StackTrace = true;
            backend.Logging.EventStoreCapacity = 10000;
            backend.Logging.EventStoreCapacity = 10000;
            backend.Logging.MetricStoreCapacity = 3600;
            backend.Runtime.UseUTCForAutoSetValues = true;
            
			return backend;
		}

        #endregion �������������

        #region ��������� ������

        public T Create<T>() where T : class, new()
        {
            
            T newObject = null;

            var parametrizedConstructor = typeof(T).GetConstructor(new Type[] { typeof(Context) });

            if (parametrizedConstructor != null)
            {
                
                var constructorParameters = new object[] { this };
                
                newObject = parametrizedConstructor.Invoke(constructorParameters) as T;
            }
            
            else
            {
                
                newObject = new T();
            }

            this.Add(newObject);
            
            return newObject;
        }

        public Exception Save()
        {
            
            {
                
                SaveChanges();
            }

            {

            }

            return null;
        }

        #endregion ��������� ������
    }

	public interface IModelUnitOfWork : IUnitOfWork
	{
	}
}
#pragma warning restore 1591
