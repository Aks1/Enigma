﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using EnigmaApp.ExceptionsHandling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Http.ExceptionHandling;
namespace EnigmaApp.ExceptionsHandling
{
    public class ApiExceptionHandler : ExceptionHandler
    {
        public override void Handle(ExceptionHandlerContext context)
        {
            context.Result = new InternalServerErrorTextPlainResult(
                "An unhandled exception occurred; check the log for more information." + Environment.NewLine + context.Exception.ToString(),
                Encoding.UTF8, context.Request);
        }
    }
}