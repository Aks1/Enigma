﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EnigmaApp.Model;
using System.Security.Claims;
using EnigmaApp.Model.Entities.App;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
namespace EnigmaApp.Controllers
{

    public class DBContextController : ApiController
    {

        protected EnigmaApp.Model.Context DBContext { get; set; }

        public DBContextController()
        {
            
            EnigmaApp.Model.Context.SetConnectionStringName("EnigmaAzureConnection");
            
            DBContext = new EnigmaApp.Model.Context();
        }

        protected void SignIn(Account account)
        {
            
            var claims = new List<Claim> {new Claim(ClaimTypes.Name, account.Id.ToString())};
            var id = new ClaimsIdentity(claims, DefaultAuthenticationTypes.ApplicationCookie);
            
            var ctx = Request.GetOwinContext();
            var authManager = ctx.Authentication;
            
            authManager.SignIn(id);
        }

        protected Int64 GetCurrentAccountId()
        {
            
            var ctx = Request.GetOwinContext();
            var authManager = ctx.Authentication;
            
            return Int64.Parse(authManager.User.Identity.Name);
        }
    }
}
