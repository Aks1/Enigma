﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DTO.Marketing.Panel.V1;
using System.Linq;
using EnigmaApp.Model.Entities.Yandex;
using MoreLinq;

using YandexAccess = EnigmaApp.Model.Entities.App.YandexAccess;
using YandexAccount = EnigmaApp.Model.Entities.Yandex.Account;
using AMOAccount = EnigmaApp.Model.Entities.AmoCRM.Account;

namespace EnigmaApp.Controllers.Marketing.Panel.V1
{

    [Authorize]
    [RoutePrefix("API/Marketing/Panel/V1")]
    public class MarketingPanelController : DBContextController
    {

        [HttpPost]
        [Route("Get")]
        public HttpResponseMessage Get(MarketingPanelGetIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            var enigmaAccountId = GetCurrentAccountId();

            var yandexAccess = DBContext.AllYandexAccesses
                                .SingleOrDefault(access => (access.Login == dataIn.YandexAccessLogin) &&
                                                            (access.AccountId == enigmaAccountId));
            
            if (yandexAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            if (yandexAccess.Account == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NoContent);
            }

            var yandexAccount = yandexAccess.YandexAccount;

            var dataOut = new MarketingPanelGetOut
            {
                Yandex = new MarketingChanelStatistics(),
                YandexContext = new MarketingChanelStatistics(),
                YandexSearch = new MarketingChanelStatistics()
            };

            var allAccountBannersId = DBContext.AllDirectCampaings
                                             .Where(camp => camp.AccountId == yandexAccount.Id)
                                             .SelectMany(camp => camp.BannerGroups)
                                             .SelectMany(bg => bg.Banners)
                                             .Select(banner => banner.Id)
                                             .Distinct();

            var allStat = DBContext.AllDirectBannerPhraseStats
                     .Where(stat => allAccountBannersId.Contains(stat.BannerId)
                                    && stat.Date >= dataIn.DateStart 
                                    && stat.Date <= dataIn.DateEnd);

            var clicksSearchSum = allStat.Sum(stat => stat.ClicksSearch);
            var clicksContextSum = allStat.Sum(stat => stat.ClicksContext);
            var showsSearchSum = allStat.Sum(stat => stat.ShowsSearch);
            var showsContextSum = allStat.Sum(stat => stat.ShowsContext);
            var clicksYandexAll = clicksSearchSum + clicksContextSum;
            var showsYandexAll = showsSearchSum + showsContextSum;

            dataOut.Yandex.Shows.Fact = showsYandexAll;
            dataOut.Yandex.CvVisits.Fact = (double)clicksYandexAll / showsYandexAll;
            dataOut.Yandex.Clicks.Fact = clicksYandexAll;

            dataOut.YandexContext.Clicks.Fact = clicksContextSum;
            dataOut.YandexContext.CvVisits.Fact = (double)clicksContextSum / showsContextSum;
            dataOut.YandexContext.Shows.Fact = showsContextSum;

            dataOut.YandexSearch.Clicks.Fact = clicksSearchSum;
            dataOut.YandexSearch.CvVisits.Fact = (double)clicksSearchSum / showsSearchSum;
            dataOut.YandexSearch.Shows.Fact = showsSearchSum;

            return Request.CreateResponse(HttpStatusCode.OK, dataOut);
        }

        [HttpPost]
        [Route("GetPhraseStat")]
        public HttpResponseMessage GetPhraseStat(MarketingPanelGetIn dataIn)
        {
            YandexAccount yandexAccount;
            AMOAccount amoAccount;

            var message = GetAmoYandexAccounts(dataIn, out yandexAccount, out amoAccount);
            if (message != null)
                return message;

            var allAgregatedStat = GetAllBannerPhraseAgregatedLeadStats(yandexAccount, amoAccount, dataIn);

            var allPhraseAgregatedStat = allAgregatedStat
               .GroupBy(agrStat => agrStat.BannerPhraseStats.PhraseId)
               .Select(phraseGroup =>
               {
                   int requests = 0;
                   int sales = 0;
                   decimal revenue = 0;

                   double costs = 0;

                   int shows = 0;
                   int clicks = 0;

                   foreach (var groupedAgrStat in phraseGroup)
                   {
                       requests += groupedAgrStat.Requests;
                       sales += groupedAgrStat.Sales;
                       revenue += groupedAgrStat.Revenue;

                       costs += groupedAgrStat.BannerPhraseStats.CostsContext 
                                                        + groupedAgrStat.BannerPhraseStats.CostsSearch;
                       shows += groupedAgrStat.BannerPhraseStats.ShowsContext 
                                                        + groupedAgrStat.BannerPhraseStats.ShowsSearch;
                       clicks += groupedAgrStat.BannerPhraseStats.ClicksContext
                                                        + groupedAgrStat.BannerPhraseStats.ClicksSearch;
                   }

                   var cvVisits = shows == 0 ? 0 : (double)clicks / shows;
                   var cvRequests = clicks == 0 ? 0 : (double)requests / clicks;
                   var cvSales = requests == 0 ? 0 : (double)sales / requests;
                   var averageDealPrice = sales == 0 ? 0 : (double)revenue / sales;

                   return new PhraseMarketingStatistics
                   {
                       Name = phraseGroup.First().BannerPhraseStats.Phrase.Name,
                       Stat = new LeadSourceMarketingStatistics
                       {
                            Shows = shows,
                            CvVisits = cvVisits,
                            Clicks = clicks,
                            CvRequests = cvRequests,
                            Requests = requests,
                            CvSales = cvSales,
                            Sales = sales,
                            Revenue = revenue,
                            AverageDealPrice = averageDealPrice,
                            Costs = costs,
                            Marge = 0,
                            Profit = 0,
                            ROMI = 0
                        }
                   };
               })
               .Where(phraseStat => phraseStat.Stat.Shows > 0);

            var dataOut = new PhraseMarketingStatGetOut {StatList = allPhraseAgregatedStat.ToList()};
            
            return Request.CreateResponse(HttpStatusCode.OK, dataOut);
        }

        [HttpPost]
        [Route("GetCampaignStat")]
        public HttpResponseMessage GetCampaignStat(MarketingPanelGetIn dataIn)
        {
            YandexAccount yandexAccount;
            AMOAccount amoAccount;

            var errorHttpMessage = GetAmoYandexAccounts(dataIn, out yandexAccount, out amoAccount);
            if (errorHttpMessage != null)
                return errorHttpMessage;

            var allAgregatedStat = GetAllBannerPhraseAgregatedLeadStats(yandexAccount, amoAccount, dataIn);

            var allPhraseAgregatedStat = allAgregatedStat
               .Join(DBContext.AllDirectBanners,
                    stat => stat.BannerPhraseStats.BannerId,
                    banner => banner.Id,
                    (stat, banner) => new { stat, Campaign = banner.BannerGroup.Campaing })
               .GroupBy(agrStat => agrStat.Campaign.Id)
               .Select(campGroup =>
               {
                   int requests = 0;
                   int sales = 0;
                   decimal revenue = 0;

                   double costs = 0;

                   int shows = 0;
                   int clicks = 0;

                   foreach (var groupedAgrStat in campGroup)
                   {
                       requests += groupedAgrStat.stat.Requests;
                       sales += groupedAgrStat.stat.Sales;
                       revenue += groupedAgrStat.stat.Revenue;

                       var stat = groupedAgrStat.stat.BannerPhraseStats;
                       costs += stat.CostsContext + stat.CostsSearch;
                       shows += stat.ShowsContext + stat.ShowsSearch;
                       clicks += stat.ClicksContext + stat.ClicksSearch;
                   }

                   var cvVisits = shows == 0 ? 0 : (double)clicks / shows;
                   var cvRequests = clicks == 0 ? 0 : (double)requests / clicks;
                   var cvSales = requests == 0 ? 0 : (double)sales / requests;
                   var averageDealPrice = sales == 0 ? 0 : (double)revenue / sales;

                   return new CampaignMarketingStatistics
                   {
                       Name = campGroup.First().Campaign.Name,
                       Stat = new LeadSourceMarketingStatistics
                       {
                           Shows = shows,
                           CvVisits = cvVisits,
                           Clicks = clicks,
                           CvRequests = cvRequests,
                           Requests = requests,
                           CvSales = cvSales,
                           Sales = sales,
                           Revenue = revenue,
                           AverageDealPrice = averageDealPrice,
                           Costs = costs,
                           Marge = 0,
                           Profit = 0,
                           ROMI = 0
                       }
                   };
               });

            var dataOut = new CampaignMarketingStatGetOut { StatList = allPhraseAgregatedStat.ToList() };

            return Request.CreateResponse(HttpStatusCode.OK, dataOut);
        }

        [HttpPost]
        [Route("GetAllStat")]
        public HttpResponseMessage GetAllStat(MarketingPanelGetIn dataIn)
        {
            YandexAccount yandexAccount;
            AMOAccount amoAccount;

            var errorHttpMessage = GetAmoYandexAccounts(dataIn, out yandexAccount, out amoAccount);
            if (errorHttpMessage != null)
                return errorHttpMessage;

            var allAgregatedStat = GetAllBannerPhraseAgregatedLeadStats(yandexAccount, amoAccount, dataIn);

            int requests = 0;
            int sales = 0;
            decimal revenue = 0;

            double costs = 0;

            int shows = 0;
            int clicks = 0;

            foreach (var agrStat in allAgregatedStat)
            {
                requests += agrStat.Requests;
                sales += agrStat.Sales;
                revenue += agrStat.Revenue;

                var stat = agrStat.BannerPhraseStats;
                costs += stat.CostsContext + stat.CostsSearch;
                shows += stat.ShowsContext + stat.ShowsSearch;
                clicks += stat.ClicksContext + stat.ClicksSearch;
            }

            var cvVisits = shows == 0 ? 0 : (double)clicks / shows;
            var cvRequests = clicks == 0 ? 0 : (double)requests / clicks;
            var cvSales = requests == 0 ? 0 : (double)sales / requests;
            var averageDealPrice = sales == 0 ? 0 : (double)revenue / sales;

            var yandex = new MarketingChanelStatistics
            {
                Shows = new PlanFact<int> {Fact = shows},
                CvVisits = new PlanFact<double> {Fact = cvVisits},
                Clicks = new PlanFact<int> {Fact = clicks},
                CvRequests = new PlanFact<double> {Fact = cvRequests},
                Requests = new PlanFact<int> {Fact = requests},
                CvSales = new PlanFact<double> {Fact = cvSales},
                Sales = new PlanFact<int> {Fact = sales},
                Revenue = new PlanFact<decimal> {Fact = revenue},
                AverageDealPrice = new PlanFact<double> {Fact = averageDealPrice},
                Costs = new PlanFact<double> {Fact = costs},
                Marge = new PlanFact<double> {Fact = 0},
                Profit = new PlanFact<double> {Fact = 0},
                ROMI = new PlanFact<double> {Fact = 0}
            };

            var dataOut = new MarketingPanelGetOut
            {
                Yandex = yandex,
                YandexContext = new MarketingChanelStatistics(),
                YandexSearch = new MarketingChanelStatistics()
            };

            return Request.CreateResponse(HttpStatusCode.OK, dataOut);
        }

        private IEnumerable<BannerPhraseAgregatedLeadStats> 
            GetAllBannerPhraseAgregatedLeadStats(YandexAccount yandexAccount, AMOAccount amoAccount, 
                                                 MarketingPanelGetIn dataIn)
        {
            
            var allAccountBannersId = DBContext.AllDirectCampaings
                                 .Where(camp => camp.AccountId == yandexAccount.Id)
                                 .SelectMany(camp => camp.BannerGroups)
                                 .SelectMany(bg => bg.Banners)
                                 .Select(banner => banner.Id)
                                 .Distinct()
                                 .ToList();

            var allStat = DBContext.AllDirectBannerPhraseStats
                .Where(stat => allAccountBannersId.Contains(stat.BannerId)
                               && stat.Date >= dataIn.DateStart
                               && stat.Date <= dataIn.DateEnd).ToList();

            var allStat3 = allStat.GroupBy(stat => new BannerPhrase(stat.BannerId, stat.PhraseId))

                .Select(groupedBpStats => new SummedBannerPhraseStats
                {
                    BannerId = groupedBpStats.Key.BannerId,
                    PhraseId = groupedBpStats.Key.PhraseId,
                    Banner = groupedBpStats.First().Banner,
                    Phrase = groupedBpStats.First().Phrase,
                    ShowsContext = groupedBpStats.Sum(st => st.ShowsContext),
                    ShowsSearch = groupedBpStats.Sum(st => st.ShowsSearch),
                    ClicksContext = groupedBpStats.Sum(st => st.ClicksContext),
                    ClicksSearch = groupedBpStats.Sum(st => st.ClicksSearch),
                    CostsContext = groupedBpStats.Sum(st => st.SumContext)*30,
                    CostsSearch = groupedBpStats.Sum(st => st.SumSearch)*30
                }).ToList();

            var allAccountLeads = amoAccount.Leads
                                .Where(lead => lead.DateCreated >= dataIn.DateStart
                                               && lead.DateCreated <= dataIn.DateEnd);

            allAccountLeads = allAccountLeads
                .Where(lead => lead.BannerId != null && lead.PhraseId != null).ToList();

            var allAgregatedStat = allStat3
               .GroupJoin(allAccountLeads,
                    stat => new BannerPhrase(stat.BannerId, stat.PhraseId),
                    lead => new BannerPhrase((long)lead.BannerId, (long)lead.PhraseId),
                    (statKey, grLeads) => new { statKey, grLeads })
               .Select(groupedStat =>
               {
                   var agrStat = new BannerPhraseAgregatedLeadStats
                   { BannerPhraseStats = groupedStat.statKey };

                   foreach (var lead in groupedStat.grLeads)
                   {
                       agrStat.Requests++;
                       if (lead.Status.Id == 142)
                       {
                           agrStat.Sales++;
                           agrStat.Revenue += lead.Value;
                       }
                   }

                   return agrStat;
               }).ToList();

            return allAgregatedStat;
        }

        private HttpResponseMessage GetAmoYandexAccounts(
            MarketingPanelGetIn dataIn, 
            out YandexAccount yandexAccount,
            out AMOAccount amoAccount)
        {
            yandexAccount = null;
            amoAccount = null;

            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            var enigmaAccountId = GetCurrentAccountId();

            var yandexAccess = DBContext.AllYandexAccesses
                                    .SingleOrDefault(access => (access.Login == dataIn.YandexAccessLogin) &&
                                                                (access.AccountId == enigmaAccountId));
            var amoCRMAccess = DBContext.AllAmoCRMAccesses
                                .SingleOrDefault(o => (o.Id == dataIn.AmoCRMAccessId)
                                && (o.AccountId == enigmaAccountId));
            
            if (yandexAccess == null || amoCRMAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            if (yandexAccess.Account == null || amoCRMAccess.Account == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NoContent);
            }

            yandexAccount = yandexAccess.YandexAccount;
            amoAccount = amoCRMAccess.AmoCRMAccount;
            return null;
        }
    }

    internal struct BannerPhrase
    {
        public long BannerId;
        public long PhraseId;

        public BannerPhrase(long bannerId, long phraseId)
        {
            BannerId = bannerId;
            PhraseId = phraseId;
        }
    }

    internal struct BannerPhraseAgregatedLeadStats
    {
        public SummedBannerPhraseStats BannerPhraseStats;
        public int Requests;
        public int Sales;
        public decimal Revenue;
    }

    internal struct SummedBannerPhraseStats
    {
        public long BannerId;
        public long PhraseId;

        public Banner Banner;
        public Phrase Phrase;

        public int ShowsContext;
        public int ShowsSearch;
        public int ClicksContext;
        public int ClicksSearch;
        public float CostsContext;
        public float CostsSearch;
    }
}
