﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http;
using System.Web.Http.Dispatcher;

namespace EnigmaApp.Controllers.AmoCRM.SalesPanel.V1
{

    [Authorize]
    [RoutePrefix("API/AmoCRM/SalesPanel/V1")]
    public class SalesPanelController : DBContextController
    {

        [HttpPost]
        [Route("Get")]
        public HttpResponseMessage List(DTO.AmoCRM.SalesPanel.V1.GetIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            Int64 accountId = GetCurrentAccountId();

            var amoCRMAccess = DBContext.AllAmoCRMAccesses
                                .SingleOrDefault(o => (o.Id == dataIn.AmoCRMAccessId) 
                                && (o.AccountId == accountId));
            
            if (amoCRMAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            if (amoCRMAccess.AmoCRMAccount == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NoContent);
            }

            var amoCRMAccount = amoCRMAccess.AmoCRMAccount;

            var dataOut = new DTO.AmoCRM.SalesPanel.V1.GetOut
            {
                
                ManagerStatsDict = new Dictionary<string, DTO.AmoCRM.SalesPanel.V1.ManagerStats>(),
                
                CVByStatusList = new List<DTO.AmoCRM.SalesPanel.V1.StatusConversion>()
            };

            var dbManagers = amoCRMAccount.Users.OrderBy(o => o.Name).ToList();
            
            dataOut.Managers = dbManagers.Select(o => o.Name).ToList();

            var dbStatuses = amoCRMAccount.Statuses.OrderBy(o => o.SequenceIndex).ToList();
            
            dataOut.Statuses = dbStatuses.Select(o => o.Name).ToList();

            Int64 statusSuccessId = dbStatuses.Where(o => o.Success).Select(o => o.Id).First();
            
            Int64 statusFailureId = dbStatuses.Where(o => o.Failure).Select(o => o.Id).First();

            var random = new Random();

            foreach (var currentManager in dbManagers)
            {
                
                var managerStats = new DTO.AmoCRM.SalesPanel.V1.ManagerStats();

                var leadGroupsByStatus = dbStatuses.GroupJoin(
                    amoCRMAccount.Leads.Where(o => o.ResponsibleUserId == currentManager.Id &&
                                                   o.DateCreated >= dataIn.DateStart &&
                                                   o.DateCreated <= dataIn.DateEnd),
                    o => o.Id, i => i.StatusId,
                    (o, i) => new { Status = o, Leads = i }).ToList();

                managerStats.SalesByStatus = leadGroupsByStatus
                                            .Select(o => new
                                            { Status = o.Status,
                                              Summary = new DTO.AmoCRM.SalesPanel.V1.DealsSummary
                                                      {
                                                          Value = o.Leads.Sum(p => p.Value),
                                                          Quantity = o.Leads.Count()
                                                      }
                                            })
                                            .ToDictionary(k => k.Status.Name, e => e.Summary);

                var successfullLeadsCount = leadGroupsByStatus.First(o => o.Status.Id == statusSuccessId)
                                                              .Leads.Count();
                
                var successfullLeadsValue = leadGroupsByStatus.First(o => o.Status.Id == statusSuccessId)
                                                              .Leads.Sum(o => o.Value);
                
                var openLeadsCount = leadGroupsByStatus.Select(o => o.Leads).First().Count();

                if (openLeadsCount == 0)
                {
                    
                    managerStats.CVFirstToLast = 0.0;
                }
                
                else
                {
                    
                    managerStats.CVFirstToLast = (double)successfullLeadsCount / openLeadsCount;
                }
                
                managerStats.SalesFactual = successfullLeadsValue;
                
                managerStats.SalesPlan = 0.0M;
                
                if (managerStats.SalesFactual < 1.0M)
                {
                    
                    managerStats.PlanByFactual = 0.0;
                }
                
                else
                {
                    
                    managerStats.PlanByFactual = (double)managerStats.SalesPlan / (double)managerStats.SalesFactual;
                }
                
                managerStats.CPO = random.NextDouble();
                
                if (successfullLeadsCount == 0)
                {
                    
                    managerStats.AverageDealPrice = 0.0M;
                }
                
                else
                {
                    
                    managerStats.AverageDealPrice = managerStats.SalesFactual / 
                        leadGroupsByStatus.First(o => o.Status.Id == statusSuccessId).Leads.Count();
                }

                dataOut.ManagerStatsDict.Add(currentManager.Name, managerStats);
            }

            foreach (var firstStatus in dbStatuses)
            {
                
                var fromCount = firstStatus.FromTransitions
                                    .Count(o => o.Date >= dataIn.DateStart 
                                             && o.Date <= dataIn.DateEnd);

                foreach (var secondStatus in dbStatuses)
                {
                    
                    var toCount = secondStatus.ToTransitions
                                    .Count(o => o.Date >= dataIn.DateStart 
                                             && o.Date <= dataIn.DateEnd 
                                             && o.OldStatusId == firstStatus.Id);

                    double convertion = 0.0;

                    if (fromCount != 0)
                    {
                        
                        convertion = (double)toCount / fromCount;
                    }

                    dataOut.CVByStatusList.Add(
                        new DTO.AmoCRM.SalesPanel.V1.StatusConversion
                        {
                            First = firstStatus.Name,
                            Second = secondStatus.Name,
                            Convertion = convertion
                        });
                }
            }

            return Request.CreateResponse<DTO.AmoCRM.SalesPanel.V1.GetOut>(HttpStatusCode.OK, dataOut);
        }

        [HttpPost]
        [Route("Get2")]
        public HttpResponseMessage Get(DTO.AmoCRM.SalesPanel.V1.GetIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            Int64 accountId = GetCurrentAccountId();

            var amoCRMAccess = DBContext.AllAmoCRMAccesses
                                .SingleOrDefault(o => (o.Id == dataIn.AmoCRMAccessId)
                                && (o.AccountId == accountId));
            
            if (amoCRMAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            if (amoCRMAccess.AmoCRMAccount == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NoContent);
            }

            var amoCRMAccount = amoCRMAccess.AmoCRMAccount;

            var dataOut = new DTO.AmoCRM.SalesPanel.V1.GetOut
            {
                
                ManagerStatsDict = new Dictionary<string, DTO.AmoCRM.SalesPanel.V1.ManagerStats>(),
                
                CVByStatusList = new List<DTO.AmoCRM.SalesPanel.V1.StatusConversion>()
            };

            var dbManagers = amoCRMAccount.Users.OrderBy(o => o.Name).ToList();
            
            dataOut.Managers = dbManagers.Select(o => o.Name).ToList();

            var dbStatuses = amoCRMAccount.Statuses.OrderBy(o => o.SequenceIndex).ToList();
            
            dataOut.Statuses = dbStatuses.Select(o => o.Name).ToList();

            Int64 statusSuccessId = dbStatuses.Where(o => o.Success).Select(o => o.Id).First();
            
            Int64 statusFailureId = dbStatuses.Where(o => o.Failure).Select(o => o.Id).First();

            var random = new Random();

            foreach (var currentManager in dbManagers)
            {
                
                var managerStats = new DTO.AmoCRM.SalesPanel.V1.ManagerStats();

                var leadGroupsByStatus = dbStatuses.GroupJoin(
                    amoCRMAccount.Leads.Where(o => o.ResponsibleUserId == currentManager.Id &&
                                                   o.DateCreated >= dataIn.DateStart &&
                                                   o.DateCreated <= dataIn.DateEnd),
                    o => o.Id, i => i.StatusId,
                    (o, i) => new { Status = o, Leads = i }).ToList();

                managerStats.SalesByStatus = leadGroupsByStatus
                                            .Select(o => new
                                            {
                                                Status = o.Status,
                                                Summary = new DTO.AmoCRM.SalesPanel.V1.DealsSummary
                                                {
                                                    Value = o.Leads.Sum(p => p.Value),
                                                    Quantity = o.Leads.Count()
                                                }
                                            })
                                            .ToDictionary(k => k.Status.Name, e => e.Summary);

                var successfullLeadsCount = leadGroupsByStatus.First(o => o.Status.Id == statusSuccessId)
                                                              .Leads.Count();
                
                var successfullLeadsValue = leadGroupsByStatus.First(o => o.Status.Id == statusSuccessId)
                                                              .Leads.Sum(o => o.Value);
                
                var openLeadsCount = leadGroupsByStatus.Select(o => o.Leads).First().Count();

                if (openLeadsCount == 0)
                {
                    
                    managerStats.CVFirstToLast = 0.0;
                }
                
                else
                {
                    
                    managerStats.CVFirstToLast = (double)successfullLeadsCount / openLeadsCount;
                }
                
                managerStats.SalesFactual = successfullLeadsValue;
                
                managerStats.SalesPlan = 0.0M;
                
                if (managerStats.SalesFactual < 1.0M)
                {
                    
                    managerStats.PlanByFactual = 0.0;
                }
                
                else
                {
                    
                    managerStats.PlanByFactual = (double)managerStats.SalesPlan / (double)managerStats.SalesFactual;
                }
                
                managerStats.CPO = random.NextDouble();
                
                if (successfullLeadsCount == 0)
                {
                    
                    managerStats.AverageDealPrice = 0.0M;
                }
                
                else
                {
                    
                    managerStats.AverageDealPrice = managerStats.SalesFactual /
                        leadGroupsByStatus.First(o => o.Status.Id == statusSuccessId).Leads.Count();
                }

                dataOut.ManagerStatsDict.Add(currentManager.Name, managerStats);
            }

            foreach (var firstStatus in dbStatuses)
            {
                
                var fromCount = firstStatus.FromTransitions
                                    .Count(o => o.Date >= dataIn.DateStart
                                             && o.Date <= dataIn.DateEnd);

                foreach (var secondStatus in dbStatuses)
                {
                    
                    var toCount = secondStatus.ToTransitions
                                    .Count(o => o.Date >= dataIn.DateStart
                                             && o.Date <= dataIn.DateEnd
                                             && o.OldStatusId == firstStatus.Id);

                    double convertion = 0.0;

                    if (fromCount != 0)
                    {
                        
                        convertion = (double)toCount / fromCount;
                    }

                    dataOut.CVByStatusList.Add(
                        new DTO.AmoCRM.SalesPanel.V1.StatusConversion
                        {
                            First = firstStatus.Name,
                            Second = secondStatus.Name,
                            Convertion = convertion
                        });
                }
            }

            return Request.CreateResponse<DTO.AmoCRM.SalesPanel.V1.GetOut>(HttpStatusCode.OK, dataOut);
        }
    }
}
