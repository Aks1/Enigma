﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http;
using System.Web.Http.Dispatcher;
namespace EnigmaApp.Controllers.AmoCRM.LeadStatus.V1
{

    [Authorize]
    [RoutePrefix("API/AmoCRM/LeadStatus/V1")]
    public class LeadStatusController : DBContextController
    {

        [HttpPost]
        [Route("List")]
        public HttpResponseMessage List(DTO.AmoCRM.LeadStatus.V1.ListIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            
            var dataOut = new DTO.AmoCRM.LeadStatus.V1.ListOut();
            
            Int64 accountId = GetCurrentAccountId();
            
            var amoCRMAccess = DBContext.AllAmoCRMAccesses.Where(o => (o.Id == dataIn.AmoCRMAccessId) && (o.AccountId == accountId)).SingleOrDefault();
            
            if (amoCRMAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }
            
            if (amoCRMAccess.AmoCRMAccount == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NoContent);
            }
            
            var amoCRMAccount = amoCRMAccess.AmoCRMAccount;
            
            dataOut.LeadStatuses = DBContext.AllAmoCRMLeadStatuses.Where(o => o.AccountId == amoCRMAccount.Id).
                Select(o => new DTO.AmoCRM.Common.V1.LeadStatus
                {
                    Id = o.Id,
                    Name = o.Name,
                    Color = o.Color
                }).ToList();

            return Request.CreateResponse<DTO.AmoCRM.LeadStatus.V1.ListOut>(HttpStatusCode.OK, dataOut);
        }
    }
}
