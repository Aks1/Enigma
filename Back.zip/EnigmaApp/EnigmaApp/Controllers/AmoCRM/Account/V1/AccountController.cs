﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using DTO.AmoCRM.Account.V1;
using EnigmaApp.Model.Entities.App;

namespace EnigmaApp.Controllers.AmoCRM.Account.V1
{

    [Authorize]
    [RoutePrefix("API/AmoCRM/Account/V1")]
    public class AccountController : DBContextController
    {

        [HttpPost]
        [Route("List")]
        public HttpResponseMessage List()
        {
            
            var dataOut = new DTO.AmoCRM.Account.V1.ListOut();
            
            var enigmaAccId = GetCurrentAccountId();

            dataOut.AmoCRMAccesses = DBContext.AllAmoCRMAccesses
                .Where(o => (o.AccountId == enigmaAccId) && (!o.IsDeleted))
                .Select(o => new DTO.AmoCRM.Account.V1.ListOut.Access
                {
                    Id = o.Id,
                    Login = o.Login,
                    Hash = o.Hash,
                    SubDomain = o.SubDomain,
                    TimeZone = o.TimeZone
                }).ToList();

            return Request.CreateResponse(HttpStatusCode.OK, dataOut);
        }

        [HttpPost]
        [Route("Add")]
        public HttpResponseMessage Add([FromBody]AddIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            var enigmaAccId = GetCurrentAccountId();

            var amoCRMAccess = DBContext.AllAmoCRMAccesses
                .SingleOrDefault(o => (o.AccountId == enigmaAccId)
                                        && (o.SubDomain == dataIn.SubDomain)
                                        && (o.Login == dataIn.Login));
            
            if (amoCRMAccess != null)
            {
                
                if (amoCRMAccess.IsDeleted)
                    amoCRMAccess.IsDeleted = false; 
                else
                    
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable);
            }
            else 
            {
                
                var newAmoCRMAccess = DBContext.Create<AmoCRMAccess>();
                
                newAmoCRMAccess.Login = dataIn.Login;
                newAmoCRMAccess.Hash = dataIn.Hash;
                newAmoCRMAccess.SubDomain = dataIn.SubDomain;
                newAmoCRMAccess.AccountId = enigmaAccId;
            }

            DBContext.Save();

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("Delete")]
        public HttpResponseMessage Delete([FromBody]DeleteIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            var enigmaAccId = GetCurrentAccountId();

            var amoCRMAccess = DBContext.AllAmoCRMAccesses.FirstOrDefault(o => (o.Id == dataIn.AmoCRMAccountId) 
                                                                            && (o.AccountId == enigmaAccId)
                                                                            && (!o.IsDeleted));
            
            if (amoCRMAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            amoCRMAccess.IsDeleted = true;

            DBContext.Save();

            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
