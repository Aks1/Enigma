﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using DTO.Yandex.Account.V1;
using EnigmaApp.Model.Entities.App;

namespace EnigmaApp.Controllers.Yandex.Account.V1
{

    [Authorize]
    [RoutePrefix("API/Yandex/Account/V1")]
    public class YandexAccountController : DBContextController
    {

        [HttpPost]
        [Route("List")]
        public HttpResponseMessage List()
        {
            
            var dataOut = new DTO.Yandex.Account.V1.ListOut();
            
            var enigmaAccId = GetCurrentAccountId();

            dataOut.YandexAccesses = DBContext.AllYandexAccesses
                .Where(yandAcc => (yandAcc.AccountId == enigmaAccId) && (!yandAcc.IsDeleted))
                .Select(yandAcc => new DTO.Yandex.Account.V1.ListOut.Access
                {
                    Id = yandAcc.Id,
                    Login = yandAcc.Login,
                    Token = yandAcc.Token
                }).ToList();

            return Request.CreateResponse(HttpStatusCode.OK, dataOut);
        }

        [HttpPost]
        [Route("Add")]
        public HttpResponseMessage Add([FromBody]AddIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            var enigmaAccId = GetCurrentAccountId();

            var yandAccess = DBContext.AllYandexAccesses
                .SingleOrDefault(acc => (acc.AccountId == enigmaAccId)
                                        && (acc.Login == dataIn.Login));
            
            if (yandAccess != null)
            {
                
                if (yandAccess.IsDeleted)
                    yandAccess.IsDeleted = false; 
                else
                    
                    return Request.CreateResponse(HttpStatusCode.NotAcceptable);
            }
            else 
            {
                
                var newYandexAccess = DBContext.Create<YandexAccess>();
                
                newYandexAccess.Login = dataIn.Login;
                newYandexAccess.Token = dataIn.Token;
                newYandexAccess.AccountId = enigmaAccId;
            }

            DBContext.Save();

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("Delete")]
        public HttpResponseMessage Delete([FromBody]DeleteIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            var enigmaAccId = GetCurrentAccountId();

            var yandAccess = DBContext.AllYandexAccesses
                                        .FirstOrDefault(yandexAccess => (yandexAccess.Id == dataIn.YandexAccountId)
                                                                      && (yandexAccess.AccountId == enigmaAccId)
                                                                      && (!yandexAccess.IsDeleted));
            
            if (yandAccess == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            yandAccess.IsDeleted = true;

            DBContext.Save();

            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
