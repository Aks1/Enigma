﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http;
namespace EnigmaApp.Controllers.App.Account.V1
{

    [RoutePrefix("API/App/Account/V1")]
    public class AccountController : DBContextController
    {

        [AllowAnonymous]
        [HttpPost]
        [Route("Authorize")]
        public HttpResponseMessage Authorize([FromBody]DTO.App.Account.V1.AuthorizeIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            
            var account = DBContext.AllAccounts.FirstOrDefault(o => (o.Login == dataIn.Login) &&
                                                                    (o.Password == dataIn.Password));
            
            if (account == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.Unauthorized);
            }
            
            SignIn(account);
            
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("Register")]
        public HttpResponseMessage Register([FromBody]DTO.App.Account.V1.RegisterIn dataIn)
        {
            
            if (dataIn == null)
            {
                
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            
            var account = DBContext.AllAccounts.SingleOrDefault(o => o.Login == dataIn.Login);
            
            if (account != null)
            {
                
                return Request.CreateResponse(HttpStatusCode.NotAcceptable);
            }
            
            var newMainAccount = DBContext.Create<Model.Entities.App.Account>();
            
            newMainAccount.Login = dataIn.Login;
            newMainAccount.Password = dataIn.Password;
            
            DBContext.Save();
            
            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
