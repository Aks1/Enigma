﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;
using System.Web.Http.Routing;
namespace EnigmaApp
{
    public class ApiControllerSelector : IHttpControllerSelector
    {
        private const string NamespaceKey = "namespace";
        private const string ControllerKey = "controller";
        private readonly HttpConfiguration _configuration;
        private readonly Lazy<Dictionary<string, HttpControllerDescriptor>> _controllers;
        public ApiControllerSelector(HttpConfiguration config)
        {
            _configuration = config;
            _controllers = new Lazy<Dictionary<string, HttpControllerDescriptor>>(InitializeControllerDictionary);
        }
        private Dictionary<string, HttpControllerDescriptor> InitializeControllerDictionary()
        {
            var dictionary = new Dictionary<string, HttpControllerDescriptor>(StringComparer.OrdinalIgnoreCase);

            IAssembliesResolver assembliesResolver = _configuration.Services.GetAssembliesResolver();
            IHttpControllerTypeResolver controllersResolver = _configuration.Services.GetHttpControllerTypeResolver();
            
            ICollection<Type> controllerTypes = controllersResolver.GetControllerTypes(assembliesResolver);
            
            foreach (Type t in controllerTypes)
            {
                
                var segments = t.Namespace.Split(Type.Delimiter);
                
                if (segments.Length < 3)
                {
                    
                    continue;
                }
                
                var key = String.Join(".", segments, segments.Length - 3, 3);
                
                if (dictionary.Keys.Contains(key))
                {
                    
                    throw new Exception("Два контроллера с одинаковым namespace!");
                }
                
                else
                {
                    
                    dictionary[key] = new HttpControllerDescriptor(_configuration, t.Name, t);
                }
            }
            return dictionary;
        }
        public HttpControllerDescriptor SelectController(HttpRequestMessage request)
        {
            IHttpRouteData routeData = request.GetRouteData();
            if (routeData == null)
            {
                var rm = new HttpResponseMessage(HttpStatusCode.NotFound);
                rm.ReasonPhrase = "RouteData is empty";
                throw new HttpResponseException(rm);
            }
            var subRouteData = routeData.GetSubRoutes();
            if (subRouteData == null || subRouteData.DefaultIfEmpty() == null)
            {
                var rm = new HttpResponseMessage(HttpStatusCode.NotFound);
                rm.ReasonPhrase = "subRouteData is empty";
                throw new HttpResponseException(rm);
            }
            string routeTemplate = subRouteData.FirstOrDefault().Route.RouteTemplate;
            
            var segments = routeTemplate.Split('/');
            
            if (segments.Length < 4)
            {
                var rm = new HttpResponseMessage(HttpStatusCode.NotFound);
                rm.ReasonPhrase = "bad segments";
                
                throw new HttpResponseException(rm);
            }
            
            var key = String.Join(".", segments, segments.Length - 4, 3);
            
            HttpControllerDescriptor controllerDescriptor;
            if (_controllers.Value.TryGetValue(key, out controllerDescriptor))
            {
                
                return controllerDescriptor;
            }
            
            else
            {
                var rm = new HttpResponseMessage(HttpStatusCode.NotFound);
                rm.ReasonPhrase = "controller not found";
                
                throw new HttpResponseException(rm);
            }
        }
        public IDictionary<string, HttpControllerDescriptor> GetControllerMapping()
        {
            return _controllers.Value;
        }
    }
}