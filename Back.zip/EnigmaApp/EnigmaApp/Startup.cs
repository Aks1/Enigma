﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using Microsoft.AspNet.Identity;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OAuth;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Dispatcher;
using System.Web.Http.ExceptionHandling;
using EnigmaApp.ExceptionsHandling;
[assembly: OwinStartup(typeof(EnigmaApp.Startup))]
namespace EnigmaApp
{
    public class Startup
    {
        
        public void Configuration(IAppBuilder appBuilder)
        {
            HttpConfiguration httpConfiguration = new HttpConfiguration();
            
            httpConfiguration.Services.Add(typeof(IExceptionLogger), new ApiExceptionLogger());

            httpConfiguration.Services.Replace(typeof(IExceptionHandler), new ApiExceptionHandler());

            httpConfiguration.Services.Replace(typeof(IHttpControllerSelector), new ApiControllerSelector(httpConfiguration));
            ConfigureOAuth(appBuilder);
            ConfigureRoutes(httpConfiguration);
            SwaggerConfig.Register();
            appBuilder.UseWebApi(httpConfiguration);
        }
        
        public void ConfigureOAuth(IAppBuilder app)
        {
            
            app.UseCookieAuthentication(new CookieAuthenticationOptions
            {
                AuthenticationType = DefaultAuthenticationTypes.ApplicationCookie,
                CookieSecure = CookieSecureOption.SameAsRequest,
                ExpireTimeSpan = TimeSpan.FromMinutes(10),
                SlidingExpiration = true
            });
        }
        public void ConfigureRoutes(HttpConfiguration config)
        {

            config.MapHttpAttributeRoutes();
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}