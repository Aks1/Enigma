﻿/// <copyright>© Заруцкий Святослав Александрович, Власенко Екатерина Алексеевна 2016. 
/// Все права защищены </copyright>

using EnigmaApp.Model;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Deserializers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using EnigmaApp.Model.Entities.AmoCRM;
using EnigmaApp.Model.Entities.App;
using Account = EnigmaApp.Model.Entities.AmoCRM.Account;

namespace LoadAmoCRMWebJob
{
    internal class ProgramAmo
    {
        
        private static RestClient _client;

        static DateTime _externalLastTime;
        
        private static Account _currentAccount;
        
        private static AmoCRMAccess _currentAccess;

        private static Context _context;

        private static void Main(string[] args)
        {

            Context.SetConnectionStringName("EnigmaAzureConnection");

            using (_context = new Context())
            {
                
                foreach (AmoCRMAccess currentAccess in _context.AllAmoCRMAccesses.Where(o => !o.IsDeleted).OrderByDescending(o => o.AmoCRMAccountId))
                {
                    
                    _client = new RestClient();
                    
                    _client.BaseUrl = new Uri("https://" + currentAccess.SubDomain + ".amocrm.ru");
                    
                    _client.CookieContainer = new System.Net.CookieContainer();

                    _currentAccess = currentAccess;

                    if (!Authorize(_currentAccess.Login, _currentAccess.Hash))
                    {
                        
                        continue;
                    }

                    if (!ProcessAccount(currentAccess))
                    {
                        
                        continue;
                    }

                    ProcessLeads(currentAccess);

                    ProcessCompanies(currentAccess);

                    ProcessContacts(currentAccess);

                    currentAccess.ExternalLastModifiedTime = _externalLastTime;

                    _context.Save();
                }
            }
        }

        private static bool Authorize(string login, string hash)
        {
            
            var request = new RestRequest();
            request.Resource = "private/api/auth.php";

            request.Method = Method.POST;
            request.AddParameter("USER_LOGIN", login);
            request.AddParameter("USER_HASH", hash);

            var result = _client.Execute(request);

            return (result.StatusCode == System.Net.HttpStatusCode.OK);
        }

        private static bool ProcessAccount(AmoCRMAccess access)
        {
            
            ResponseAccountRoot response;

            var request = new RestRequest();
            request.Resource = "private/api/v2/json/accounts/current";

            response = Execute<ResponseAccountRoot>(request);

            if (response == null)
            {
                
                return false;
            }

            var loadedAccount = response.Response.Account;

            _externalLastTime = DateTimeOffset.FromUnixTimeSeconds(response.Response.ServerTime - 10).UtcDateTime;

            _currentAccount = access.AmoCRMAccount;
            
            if (_currentAccount == null)
            {
                
                _currentAccount = _context.AllAmoCRMAccounts.SingleOrDefault(o => o.Id == loadedAccount.Id);
                
                if (_currentAccount == null)
                {
                    
                    _currentAccount = _context.Create<Account>();
                    
                    _currentAccount.Id = loadedAccount.Id;
                }

                access.AmoCRMAccount = _currentAccount;

                _context.Save();
            }

            _currentAccess.TimeZone = IanaToWindows(loadedAccount.TimeZone);

            UpdateAccount(_currentAccount, loadedAccount);

            return true;
        }

        private static void ProcessContacts(AmoCRMAccess access)
        {
            
            ResponseContactsRoot response;

            int contactIndex = 0;
            int pageSize = 500;

            do
            {
                
                var request = new RestRequest();
                request.Resource = "private/api/v2/json/contacts/list";

                request.Method = Method.GET;
                request.AddHeader("if-modified-since", access.ExternalLastModifiedTime.ToString("ddd, dd MMM yyyy HH:mm:ss", CultureInfo.InvariantCulture));
                request.AddParameter("limit_rows", pageSize);
                request.AddParameter("limit_offset", contactIndex);

                response = Execute<ResponseContactsRoot>(request);

                if (response == null)
                {
                    
                    break;
                }

                UpdateContacts(response.Response.Contacts.Where(o => o.DateModified < _externalLastTime));

                contactIndex += pageSize;
            }
            
            while (response.Response.Contacts.Count >= pageSize);
        }

        private static void ProcessCompanies(AmoCRMAccess access)
        {
            
            ResponseCompaniesRoot response;

            int contactIndex = 0;
            int pageSize = 500;

            do
            {
                
                var request = new RestRequest();
                request.Resource = "private/api/v2/json/companies/list";

                request.Method = Method.GET;
                request.AddHeader("if-modified-since", access.ExternalLastModifiedTime.ToString("ddd, dd MMM yyyy HH:mm:ss", CultureInfo.InvariantCulture));
                request.AddParameter("limit_rows", pageSize);
                request.AddParameter("limit_offset", contactIndex);

                response = Execute<ResponseCompaniesRoot>(request);

                if (response == null)
                {
                    
                    break;
                }

                UpdateCompanies(response.Response.Companies.Where(o => o.DateModified < _externalLastTime));

                contactIndex += pageSize;
            }
            
            while (response.Response.Companies.Count >= pageSize);
        }

        private static void ProcessLeads(AmoCRMAccess access)
        {
            
            GetLeadsRoot responseJSON;
            long leadsLoaded = 0;

            int contactIndex = 0;
            int pageSize = 500;

            do
            {
                
                var request = new RestRequest
                {
                    Resource = "private/api/v2/json/leads/list",
                    Method = Method.GET
                };

                request.AddHeader("if-modified-since", access.ExternalLastModifiedTime.ToString("ddd, dd MMM yyyy HH:mm:ss", CultureInfo.InvariantCulture));
                request.AddParameter("limit_rows", pageSize);
                request.AddParameter("limit_offset", contactIndex);

                responseJSON = Execute<GetLeadsRoot>(request);

                if (responseJSON == null)
                {
                    
                    break;
                }

                var leads = responseJSON.response.leads.Select(leadRespElem =>
                {
                    var ret = new Lead
                    {
                        Id = leadRespElem.id,
                        Name = leadRespElem.name,
                        CreatedUserId = leadRespElem.created_user_id,
                        DateCreate = leadRespElem.date_create,
                        LastModified = leadRespElem.last_modified,
                        StatusId = leadRespElem.status_id,
                        Price = leadRespElem.price,
                        ResponsibleUserId = leadRespElem.responsible_user_id,
                        AccountId = leadRespElem.account_id
                    };

                    var bannerId = leadRespElem.custom_fields
                                                ?.FirstOrDefault(field => field.name == "AdId")
                                                ?.values.FirstOrDefault()
                                                ?.value;
                    if (!string.IsNullOrWhiteSpace(bannerId))
                    {
                        long parsedBannerId;
                        if (long.TryParse(bannerId, out parsedBannerId))
                            ret.BannerId = parsedBannerId;
                    }

                    var phraseId = leadRespElem.custom_fields
                                                ?.FirstOrDefault(field => field.name == "PId")
                                                ?.values.FirstOrDefault()
                                                ?.value;
                    if (!string.IsNullOrWhiteSpace(phraseId))
                    {
                        long parsedPhraseId;
                        if (long.TryParse(phraseId, out parsedPhraseId))
                            ret.PhraseId = parsedPhraseId;
                    }

                    return ret;
                }).ToList();

                UpdateLeads(_currentAccount, leads.Where(o => o.DateModified < _externalLastTime));

                contactIndex += pageSize;
                leadsLoaded = leads.Count;
            }
            
            while (leadsLoaded >= pageSize);
        }

        private static void UpdateAccount(Account dbAccount, Account loadedAccount)
        {
            
            dbAccount.Name = loadedAccount.Name;
            dbAccount.SubDomain = loadedAccount.SubDomain;
            dbAccount.Currency = loadedAccount.Currency;
            dbAccount.TimeZone = loadedAccount.TimeZone;

            _context.Save();

            UpdateUsers(dbAccount, loadedAccount);

            UpdateStatuses(dbAccount, loadedAccount);
        }

        private static void UpdateUsers(Account dbAccount, Account loadedAccount)
        {
            
            var dbUserIds = dbAccount.Users.Select(p => p.Id);

            var newUserIds = loadedAccount.Users.Select(p => p.Id).Except(dbUserIds);

            var newUsers = loadedAccount.Users.Where(p => newUserIds.Contains(p.Id));

            var changedUsers = dbAccount.Users.Join(loadedAccount.Users, o => o.Id, p => p.Id, (dbUser, loadedUser) => new { dbUser = dbUser, loadedUser = loadedUser }).ToList();

            var deletedUserIds = dbUserIds.Except(loadedAccount.Users.Select(p => p.Id));

            var deletedUsers = dbAccount.Statuses.Where(p => deletedUserIds.Contains(p.Id));

            _context.Delete(deletedUsers);

            _context.Save();

            foreach (var newUser in newUsers)
            {
                
                newUser.AccountId = dbAccount.Id;
                
                _context.AttachCopy(newUser);

                _context.Save();
            }

            foreach (var changedUser in changedUsers)
            {
                
                var dbUser = changedUser.dbUser;
                var loadedUser = changedUser.loadedUser;

                dbUser.Name = loadedUser.Name;
                dbUser.LastName = loadedUser.LastName;
                dbUser.Login = loadedUser.Login;

                _context.Save();
            }
        }

        private static void UpdateStatuses(Account dbAccount, Account loadedAccount)
        {
            
            var dbStatusIds = dbAccount.Statuses.Select(p => p.Id).ToList();

            var newStatusIds = loadedAccount.Statuses.Select(p => p.Id).Except(dbStatusIds);

            var newStatuses = loadedAccount.Statuses.Where(p => newStatusIds.Contains(p.Id));

            var changedStatuses = dbAccount.Statuses.Join(
                        loadedAccount.Statuses,
                        o => o.Id,
                        p => p.Id,
                        (dbStatus, loadedStatus) => new { dbStatus = dbStatus, LoadedStatus = loadedStatus })
                .ToList();

            var deletedStatusIds = dbStatusIds.Except(loadedAccount.Statuses.Select(p => p.Id));

            var deletedStatuses = dbAccount.Statuses.Where(p => deletedStatusIds.Contains(p.Id));

            _context.Delete(deletedStatuses);

            _context.Save();

            foreach (var newStatus in newStatuses)
            {
                
                newStatus.AccountId = dbAccount.Id;

                switch (newStatus.Id)
                {
                    
                    case LeadStatus.LeadStatusSuccessId:
                        
                        newStatus.Success = true;
                        newStatus.Failure = false;
                        break;
                    
                    case LeadStatus.LeadStatusFailureId:
                        
                        newStatus.Success = false;
                        newStatus.Failure = true;
                        break;
                    
                    default:
                        
                        newStatus.Success = false;
                        newStatus.Failure = false;
                        break;
                }
                
                _context.AttachCopy(newStatus);

                _context.Save();
            }

            foreach (var changedStatus in changedStatuses)
            {
                
                var dbStatus = changedStatus.dbStatus;
                var loadedStatus = changedStatus.LoadedStatus;

                dbStatus.Name = loadedStatus.Name;
                dbStatus.Color = loadedStatus.Color;
                dbStatus.SequenceIndex = loadedStatus.SequenceIndex;
                dbStatus.PipelineId = loadedStatus.PipelineId;

                switch (dbStatus.Id)
                {
                    
                    case LeadStatus.LeadStatusSuccessId:
                        
                        dbStatus.Success = true;
                        dbStatus.Failure = false;
                        break;
                    
                    case LeadStatus.LeadStatusFailureId:
                        
                        dbStatus.Success = false;
                        dbStatus.Failure = true;
                        break;
                    
                    default:
                        
                        dbStatus.Success = false;
                        dbStatus.Failure = false;
                        break;
                }

                _context.Save();
            }
        }

        private static void UpdateContacts(IEnumerable<Contact> contacts)
        {
            
            var contactIds = contacts.Select(contact => contact.Id).ToList();

            var changedDBContacts = _context.AllAmoCRMContacts.Where(contact => contactIds.Contains(contact.Id)).ToList();

            var changedContacts = changedDBContacts.Join(contacts, dbContact => dbContact.Id, loadedContact => loadedContact.Id,
                (dbContact, loadedContact) => new { dbContact = dbContact, LoadedContact = loadedContact }).ToList();

            var newContacts = contacts.Where(contact => !changedDBContacts.Select(p => p.Id).Contains(contact.Id));

            foreach (var changedContact in changedContacts)
            {
                
                var dbContact = changedContact.dbContact;
                var loadedContact = changedContact.LoadedContact;

                dbContact.Name = loadedContact.Name;
                dbContact.DateModified = loadedContact.DateModified;
                dbContact.ResponsibleUserId = loadedContact.ResponsibleUserId;

                UpdateContactLeadLinks(dbContact, loadedContact.LinkedLeadsId);

                _context.Save();
            }

            foreach (var newContact in newContacts)
            {
                
                _context.AttachCopy(newContact);

                UpdateContactLeadLinks(newContact, newContact.LinkedLeadsId);

                _context.Save();
            }
        }

        private static void UpdateContactLeadLinks(Contact contact, IEnumerable<Int64> leadIds)
        {
            
            var oldLeadIds = contact.LeadLinks.Select(p => p.LeadId);

            var newLeadIds = leadIds.Except(oldLeadIds);

            var deletedLeadLinks = contact.LeadLinks.Where(p => !leadIds.Contains(p.LeadId));

            _context.Delete(deletedLeadLinks);

            foreach (Int64 leadId in newLeadIds)
            {
                
                var newLink = _context.Create<LinkContactLead>();
                
                newLink.ContactId = contact.Id;
                newLink.LeadId = leadId;
            }
        }

        private static void UpdateCompanies(IEnumerable<Company> companies)
        {
            
            var companyIds = companies.Select(company => company.Id).ToList();

            var changedDBCompanies = _context.AllAmoCRMCompanies.Where(company => companyIds.Contains(company.Id)).ToList();

            var changedCompanies = changedDBCompanies.Join(companies, dbCompany => dbCompany.Id, loadedCompany => loadedCompany.Id,
                (dbCompany, loadedCompany) => new { dbCompany = dbCompany, loadedCompany = loadedCompany }).ToList();

            var newCompanies = companies.Where(company => !changedDBCompanies.Select(p => p.Id).Contains(company.Id));

            foreach (var changedCompany in changedCompanies)
            {
                
                var dbCompany = changedCompany.dbCompany;
                var loadedCompany = changedCompany.loadedCompany;

                dbCompany.Name = loadedCompany.Name;
                dbCompany.DateModified = loadedCompany.DateModified;
                dbCompany.ResponsibleUserId = loadedCompany.ResponsibleUserId;

                _context.Save();
            }

            foreach (var newCompany in newCompanies)
            {
                
                _context.AttachCopy(newCompany);

                _context.Save();
            }

        }

        private static void UpdateLeads(Account account, IEnumerable<Lead> leads)
        {
            
            var leadStatuses = _context.AllAmoCRMLeadStatuses.Where(o => o.AccountId == account.Id)
                                                             .OrderBy(o => o.SequenceIndex)
                                                             .ToArray();

            var leadIds = leads.Select(lead => lead.Id).ToList();

            var changedDBLeads = _context.AllAmoCRMLeads.Where(lead => leadIds.Contains(lead.Id)).ToList();

            var changedLeads = changedDBLeads.Join(leads,
                                                   dbLead => dbLead.Id,
                                                   loadedLead => loadedLead.Id,
                                                   (dbLead, loadedLead) => new {dbLead, loadedLead })
                                             .ToList();

            var newLeads = leads.Where(lead => !changedDBLeads.Select(p => p.Id).Contains(lead.Id));

            foreach (var changedLead in changedLeads)
            {
                
                var dbLead = changedLead.dbLead;
                var loadedLead = changedLead.loadedLead;

                dbLead.Name = loadedLead.Name;
                dbLead.Value = loadedLead.Value;
                dbLead.DateModified = loadedLead.DateModified;
                dbLead.ResponsibleUserId = loadedLead.ResponsibleUserId;

                dbLead.BannerId = loadedLead.BannerId;
                dbLead.PhraseId = loadedLead.PhraseId;

                if (dbLead.StatusId != loadedLead.StatusId)
                {
                    
                    if (UpdateLeadStatusTransition(dbLead, loadedLead, leadStatuses))
                    {
                        
                        dbLead.StatusId = loadedLead.StatusId;
                        _context.Save();
                    }
                    else
                    {
                        
                        _context.ClearChanges();
                    }
                }

                _context.Save();
            }

            foreach (var newLead in newLeads)
            {
                
                _context.AttachCopy(newLead);

                if (UpdateLeadStatusTransition(null, newLead, leadStatuses))
                {
                    
                    _context.Save();
                }
                else
                {
                    
                    _context.ClearChanges();
                }
            }
        }

        private static bool UpdateLeadStatusTransition(Lead oldLead, Lead newLead, LeadStatus[] leadStatuses)
        {
            
            if (oldLead == null)
            {
                
                int newStatusIndex = Array.FindIndex(leadStatuses, o => o.Id == newLead.StatusId);

                if (newStatusIndex < 0)
                    return false;

                for (int statusIndex = 0; statusIndex <= newStatusIndex; statusIndex += 1)
                {
                    
                    if ((newStatusIndex == (leadStatuses.Length - 1)) && (statusIndex == (leadStatuses.Length - 2)))
                    {
                        
                        continue;
                    }

                    var newStatusTransition = _context.Create<LeadStatusTransition>();
                    
                    newStatusTransition.AccountId = newLead.AccountId;
                    newStatusTransition.Date = newLead.DateModified;
                    newStatusTransition.NewStatusId = leadStatuses[statusIndex].Id;
                    newStatusTransition.LeadId = newLead.Id;
                    newStatusTransition.Direction = 1;

                    if (statusIndex == 0)
                    {
                        
                        newStatusTransition.OldStatusId = null;
                    }
                    
                    else
                    {
                        
                        if (statusIndex == (leadStatuses.Length - 1))
                        {
                            
                            newStatusTransition.OldStatusId = leadStatuses[statusIndex - 2].Id;
                        }
                        
                        else
                        {
                            
                            newStatusTransition.OldStatusId = leadStatuses[statusIndex - 1].Id;
                        }
                    }
                }
                
            }
            
            else
            {
                
                int oldStatusIndex = Array.FindIndex(leadStatuses, o => o.Id == oldLead.StatusId);
                
                int newStatusIndex = Array.FindIndex(leadStatuses, o => o.Id == newLead.StatusId);
                
                if ((oldStatusIndex < 0) || (newStatusIndex < 0))
                    return false;

                int direction = (newStatusIndex > oldStatusIndex ? 1 : -1);

                int statusIndex = oldStatusIndex;

                do
                {
                    
                    statusIndex += direction;
                    
                    if ((newStatusIndex == (leadStatuses.Length - 1)) && (statusIndex == (leadStatuses.Length - 2)))
                    {
                        
                        statusIndex += direction;
                    }

                    var newStatusTransition = _context.Create<LeadStatusTransition>();
                    
                    newStatusTransition.AccountId = newLead.AccountId;
                    newStatusTransition.Date = newLead.DateModified;
                    newStatusTransition.OldStatusId = leadStatuses[statusIndex - direction].Id;
                    newStatusTransition.NewStatusId = leadStatuses[statusIndex].Id;
                    newStatusTransition.LeadId = newLead.Id;
                    newStatusTransition.Direction = direction;
                } 
                while (statusIndex != newStatusIndex);
            }

            return true;
        }

        private static T Execute<T>(IRestRequest request) where T : new()
        {
            
            Thread.Sleep(2000);

            var response = _client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                
                var deserialized = JsonConvert.DeserializeObject<T>(response.Content);

                return deserialized;
            }
            else
            {
                
                return default(T);
            }
        }

        private static string IanaToWindows(string ianaZoneId)
        {
            if (string.IsNullOrEmpty(ianaZoneId))
                return null;

            var utcZones = new[] { "Etc/UTC", "Etc/UCT", "Etc/GMT" };
            if (utcZones.Contains(ianaZoneId, StringComparer.Ordinal))
                return "UTC";

            var tzdbSource = NodaTime.TimeZones.TzdbDateTimeZoneSource.Default;

            List<string> possibleZones = tzdbSource.CanonicalIdMap
                .Where(x => x.Value.Equals(ianaZoneId, StringComparison.Ordinal))
                .Select(x => x.Key)
                .ToList();

            string canonical;
            if (tzdbSource.CanonicalIdMap.TryGetValue(ianaZoneId, out canonical))
            {
                possibleZones.Add(canonical);
                possibleZones.Add(ianaZoneId);
            }

            var mappings = tzdbSource.WindowsMapping.MapZones;
            var item = mappings.FirstOrDefault(x => x.TzdbIds.Any(possibleZones.Contains));
            if (item == null)
                return null;

            return item.WindowsId;
        }
    }
}
